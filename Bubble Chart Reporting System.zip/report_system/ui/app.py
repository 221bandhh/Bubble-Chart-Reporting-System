"""Tkinter interface for the report generator."""

import copy
import os
import sys
import queue
import threading
import traceback
import tkinter as tk
from io import StringIO
from tkinter import filedialog, messagebox, simpledialog, ttk

import pandas as pd
from core import excel_com

from report_system.core.engine import (
    BUILT_IN_FREQ,
    BUILT_IN_ITEM_TRANS,
    BUILT_IN_TOOL_TRANS,
    DEFAULT_RULES,
    FIELD_ALIASES,
    REPORT_TYPES,
    DataProcessor,
    clean_frame,
    excel_app,
    read_source_excel,
    save_workbook_from_template,
)
from report_system.data.config_store import ConfigStore
from report_system.core.history_layout import history_origin
from report_system.core.template_preview import parse_header_cells, preview_header_cells
from core.product_info import REPORT_HEADER_FIELDS
from pathlib import Path
from core.runtime import working_directory
from report_system.data.template_library import TemplateLibrary
from report_system.data.report_presets import ensure_builtin_presets, instantiate_preset


class ReportGeneratorApp:
    def __init__(self, root, initial_source=None, embedded=False, source_provider=None, initial_snapshot=None):
        self.root = root
        self.embedded = embedded
        self.source_provider = source_provider
        if not embedded:
            root.title("产品特性报表生成器")
            root.geometry("1300x820")
        self.config_file = os.path.join(
            os.path.dirname(os.path.abspath(initial_source)) if initial_source else os.getcwd(),
            "report_generator_config.json",
        )
        self.config_store = ConfigStore(self.config_file)
        config_folder = Path(self.config_file).parent
        workspace = (config_folder.parent.parent if config_folder.parent.name == "products"
                     else working_directory())
        self.template_library = TemplateLibrary(workspace)
        self.df_source = None
        self.freq_df = clean_frame(pd.read_csv(StringIO(BUILT_IN_FREQ), sep="\t", dtype=str))
        item = clean_frame(pd.read_csv(StringIO(BUILT_IN_ITEM_TRANS), sep="\t", dtype=str))
        tools = clean_frame(pd.read_csv(StringIO(BUILT_IN_TOOL_TRANS), sep="\t", dtype=str))
        self.item_trans = dict(zip(item.iloc[:, 0], item.iloc[:, 1]))
        self.tool_ship = dict(zip(tools.iloc[:, 0], tools.iloc[:, 1]))
        self.tool_proc = dict(zip(tools.iloc[:, 0], tools.iloc[:, 2]))
        self.rules = copy.deepcopy(DEFAULT_RULES)
        for name, rule in self.rules.items():
            rule.setdefault("base_type", name)
        self.sheet_config = {
            name: {"sheet_name": name, "header": 0, "footer": 0} for name in REPORT_TYPES
        }
        self.template_profiles = {"默认模板": {"path": "", "sheet_config": self.sheet_config}}
        self.template_catalog = self.template_library.list_items()
        self.active_template_profile = "默认模板"
        self.source_path = tk.StringVar()
        self.template_path = tk.StringVar()
        self.status = tk.StringVar(value="就绪")
        self.active_rule = REPORT_TYPES[0]
        self.active_template = REPORT_TYPES[0]
        self._build_ui()
        self.load_config(silent=True)
        if initial_snapshot is not None:
            self.load_snapshot(initial_snapshot)
        elif initial_source:
            self.load_source(initial_source)
        if not embedded:
            root.protocol("WM_DELETE_WINDOW", self.on_close)

    @property
    def report_types(self):
        return list(self.rules)

    def _build_ui(self):
        if not self.embedded:
            menu = tk.Menu(self.root)
            file_menu = tk.Menu(menu, tearoff=False)
            file_menu.add_command(label="保存配置", command=self.save_config)
            file_menu.add_command(label="加载配置", command=self.choose_config)
            menu.add_cascade(label="文件", menu=file_menu)
            self.root.config(menu=menu)

        notebook = ttk.Notebook(self.root)
        notebook.pack(fill=tk.BOTH, expand=True, padx=6, pady=6)
        self.notebook = notebook
        tabs = {}
        for name in ("数据源", "报表规则", "翻译与频次", "模板设置", "数据预览"):
            tabs[name] = ttk.Frame(notebook)
            notebook.add(tabs[name], text=name)
        self.tabs = tabs
        self._build_source_tab(tabs["数据源"])
        self._build_rule_tab(tabs["报表规则"])
        self._build_dictionary_tab(tabs["翻译与频次"])
        self._build_template_tab(tabs["模板设置"])
        self.preview_tree = self._make_table(tabs["数据预览"])

        footer = ttk.Frame(self.root)
        footer.pack(fill=tk.X, padx=8, pady=(0, 8))
        ttk.Button(footer, text="预览当前报表", command=self.preview_report).pack(side=tk.LEFT, padx=3)
        ttk.Button(footer, text="生成全部报表", command=self.generate).pack(side=tk.LEFT, padx=3)
        ttk.Button(footer, text="保存配置", command=self.save_config).pack(side=tk.LEFT, padx=3)
        ttk.Label(footer, textvariable=self.status).pack(side=tk.RIGHT, padx=8)

    @staticmethod
    def _make_table(parent):
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)
        tree = ttk.Treeview(frame, show="headings")
        ybar = ttk.Scrollbar(frame, orient=tk.VERTICAL, command=tree.yview)
        xbar = ttk.Scrollbar(frame, orient=tk.HORIZONTAL, command=tree.xview)
        tree.configure(yscrollcommand=ybar.set, xscrollcommand=xbar.set)
        tree.grid(row=0, column=0, sticky="nsew")
        ybar.grid(row=0, column=1, sticky="ns")
        xbar.grid(row=1, column=0, sticky="ew")
        frame.grid_rowconfigure(0, weight=1)
        frame.grid_columnconfigure(0, weight=1)
        return tree

    @staticmethod
    def _show_frame(tree, frame):
        tree.delete(*tree.get_children())
        columns = [str(column) for column in frame.columns]
        tree["columns"] = columns
        for column in columns:
            tree.heading(column, text=column)
            tree.column(column, width=120, minwidth=65, stretch=False)
        for row in frame.head(300).itertuples(index=False, name=None):
            tree.insert("", tk.END, values=["" if pd.isna(value) else value for value in row])

    def _build_source_tab(self, parent):
        controls = ttk.Frame(parent)
        controls.pack(fill=tk.X, padx=8, pady=8)
        ttk.Label(controls, text="气泡数据源").pack(side=tk.LEFT, padx=4)
        ttk.Entry(controls, textvariable=self.source_path, state="readonly" if self.embedded else "normal").pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4)
        if self.embedded:
            ttk.Button(controls, text="刷新当前产品", command=self.refresh_product_view).pack(side=tk.LEFT)
        else:
            ttk.Button(controls, text="选择", command=self.browse_source).pack(side=tk.LEFT)
        self.source_tree = self._make_table(parent)

    def refresh_product_view(self):
        try:
            self.refresh_product_source()
        except Exception as exc:
            messagebox.showerror("刷新失败", str(exc))

    def refresh_product_source(self):
        if self.source_provider:
            path = self.source_provider()
            if path is None:
                raise ValueError("请先选择产品")
            if isinstance(path, dict):
                self.load_snapshot(path)
            else:
                self.load_source(path, raise_errors=True)

    def load_snapshot(self, snapshot):
        self.df_source = clean_frame(snapshot["frame"].copy())
        self._source_header = snapshot["header"]
        self._source_history = snapshot["history"]
        self.source_path.set("当前产品（内存数据）")
        self._show_frame(self.source_tree, self.df_source)
        self.status.set(f"已加载 {len(self.df_source)} 行")

    def browse_source(self):
        path = filedialog.askopenfilename(filetypes=[("Excel 文件", "*.xlsx *.xlsm *.xls")])
        if path:
            self.load_source(path)

    def load_source(self, path, raise_errors=False):
        try:
            frame = read_source_excel(path)
            renamed = {}
            used = set()
            for standard, aliases in FIELD_ALIASES.items():
                if standard in frame.columns:
                    used.add(standard)
                    continue
                match = next((col for col in frame.columns if col not in used
                              and str(col).strip() in aliases), None)
                if match is not None:
                    renamed[match] = standard
                    used.add(match)
            frame = frame.rename(columns=renamed)
            if "检验项目" not in frame.columns:
                raise ValueError("源表缺少检验项目列")
            self._source_header = {}
            self._source_history = []
            self.df_source = frame
            self.source_path.set(path)
            self._show_frame(self.source_tree, frame)
            self.status.set(f"已加载 {len(frame)} 行")
        except Exception as exc:
            if raise_errors:
                raise
            messagebox.showerror("数据源错误", str(exc))

    def _build_rule_tab(self, parent):
        top = ttk.Frame(parent)
        top.pack(fill=tk.X, padx=12, pady=10)
        ttk.Label(top, text="报表类型").pack(side=tk.LEFT)
        self.rule_report = tk.StringVar(value=self.active_rule)
        self.rule_selector = ttk.Combobox(top, textvariable=self.rule_report, values=self.report_types,
                                         state="readonly", width=24)
        self.rule_selector.pack(side=tk.LEFT, padx=8)
        self.rule_selector.bind("<<ComboboxSelected>>", self._on_rule_select)
        ttk.Button(top, text="新增", command=self.add_report_type).pack(side=tk.LEFT, padx=2)
        ttk.Button(top, text="从类型模板新增", command=self.add_report_from_preset).pack(side=tk.LEFT, padx=2)
        ttk.Button(top, text="保存为类型模板", command=self.save_report_preset).pack(side=tk.LEFT, padx=2)
        ttk.Button(top, text="报表类型模板库", command=self.manage_report_presets).pack(side=tk.LEFT, padx=2)
        ttk.Button(top, text="删除", command=self.delete_report_type).pack(side=tk.LEFT, padx=2)

        options = ttk.LabelFrame(parent, text="处理规则")
        options.pack(fill=tk.X, padx=12, pady=4)
        boolean_labels = {
            "add_translations": "添加翻译", "add_location": "添加检测场地",
            "add_freq": "匹配检验频次", "dedup": "同父序号去重",
            "thread_merge": "螺纹项筛选", "patrol": "生成巡检行",
            "replace_measure_tool": "替换测量器具",
        }
        self.rule_checks = {}
        for index, (key, label) in enumerate(boolean_labels.items()):
            variable = tk.BooleanVar()
            self.rule_checks[key] = variable
            ttk.Checkbutton(options, text=label, variable=variable).grid(
                row=index // 4, column=index % 4, sticky=tk.W, padx=12, pady=6
            )

        details = ttk.LabelFrame(parent, text="参数")
        details.pack(fill=tk.X, padx=12, pady=6)
        fields = {
            "translation_type": "翻译类型 (ship/process)",
            "base_type": "基础报表类型",
            "precision_categories": "精测器具 (逗号分隔)",
            "precision_tool_text": "精测替换文字",
            "field_tool_text": "现场替换文字",
            "thread_parents": "螺纹父序号",
            "thread_allowed": "螺纹保留项目",
            "special_keywords": "特殊关键词",
            "patrol_importance": "巡检重要度",
            "patrol_freq": "样件巡检频次",
            "patrol_n": "样件巡检 n",
            "patrol_mass_freq": "量产巡检频次",
            "patrol_mass_n": "量产巡检 n",
            "patrol_remark": "巡检备注",
            "source_drawings": "数据图纸（逗号分隔，多工序必须指定）",
            "report_version": "报表版本",
            "report_date": "报表修订日期",
            "report_author": "报表修订人",
            "report_reason": "报表修订原因",
        }
        self.rule_fields = {}
        for index, (key, label) in enumerate(fields.items()):
            row, side = divmod(index, 2)
            variable = tk.StringVar()
            self.rule_fields[key] = variable
            ttk.Label(details, text=label).grid(row=row, column=side * 2, sticky=tk.W, padx=8, pady=5)
            field_widget = (ttk.Combobox(details, textvariable=variable, values=REPORT_TYPES,
                                         state="readonly", width=35)
                            if key == "base_type" else ttk.Entry(details, textvariable=variable, width=38))
            field_widget.grid(
                row=row, column=side * 2 + 1, sticky=tk.EW, padx=8, pady=5
            )
        details.grid_columnconfigure(1, weight=1)
        details.grid_columnconfigure(3, weight=1)
        ttk.Button(details, text="选择来源图纸", command=self.choose_drawings).grid(row=11, column=0, padx=8, pady=5)
        self._load_rule_form()

    def choose_drawings(self):
        if self.df_source is None or "图纸" not in self.df_source:
            messagebox.showwarning("提示", "请先加载包含图纸字段的数据源")
            return
        dialog = tk.Toplevel(self.root)
        dialog.title("选择当前报表的来源图纸")
        box = tk.Listbox(dialog, selectmode=tk.MULTIPLE, exportselection=False, width=65)
        box.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        names = list(dict.fromkeys(self.df_source["图纸"].astype(str).str.strip()))
        chosen = self.rule_fields["source_drawings"].get().replace("，", ",").split(",")
        for index, name in enumerate(names):
            box.insert(tk.END, name)
            if name in [value.strip() for value in chosen]:
                box.selection_set(index)
        def apply():
            self.rule_fields["source_drawings"].set(", ".join(names[i] for i in box.curselection()))
            dialog.destroy()
        ttk.Button(dialog, text="应用", command=apply).pack(pady=8)

    def _store_rule_form(self):
        rule = self.rules[self.active_rule]
        for key, variable in self.rule_checks.items():
            rule[key] = variable.get()
        list_keys = {"precision_categories", "thread_parents", "thread_allowed",
                     "special_keywords", "patrol_importance", "source_drawings"}
        for key, variable in self.rule_fields.items():
            value = variable.get().strip()
            if key in list_keys:
                rule[key] = [part.strip() for part in value.replace("，", ",").split(",") if part.strip()]
            elif key in ("patrol_n", "patrol_mass_n"):
                if not value:
                    rule[key] = 4 if key == "patrol_n" else 5
                    continue
                try:
                    rule[key] = int(value)
                except ValueError as exc:
                    raise ValueError(f"{key} 必须是整数") from exc
            else:
                rule[key] = value

    def _load_rule_form(self):
        rule = self.rules[self.active_rule]
        for key, variable in self.rule_checks.items():
            variable.set(bool(rule.get(key, False)))
        for key, variable in self.rule_fields.items():
            value = rule.get(key, "")
            variable.set(", ".join(map(str, value)) if isinstance(value, list) else str(value))

    def _on_rule_select(self, _event):
        try:
            self._store_rule_form()
        except ValueError as exc:
            messagebox.showerror("规则错误", str(exc))
            self.rule_report.set(self.active_rule)
            return
        self.active_rule = self.rule_report.get()
        self._load_rule_form()

    def save_report_preset(self):
        try:
            self._store_rule_form()
            self._store_profile()
            report = self.active_rule
            profile = self.template_profiles[self.active_template_profile]
            config = {"rules": {report: copy.deepcopy(self.rules[report])},
                      "sheet_config": {report: copy.deepcopy(profile["sheet_config"][report])},
                      "templates": {"path": profile["path"]},
                      "active_template_profile": "保存的模板"}
            config["template_profiles"] = {"保存的模板": {"path": profile["path"], "sheet_config": config["sheet_config"]}}
            instantiate_preset(config, report, report, [])
            name = simpledialog.askstring("保存报表类型模板", "模板名称（所有产品共享）：",
                                          initialvalue=report + " 类型模板", parent=self.root)
            if not name or not name.strip():
                return
            self.template_library.add({"name": name.strip(), "kind": "report_type", "config": config},
                                      Path(self.config_file).parent)
            self.status.set(f"已保存类型模板：{name.strip()}，其他产品可直接套用")
        except (ValueError, OSError, KeyError) as exc:
            messagebox.showerror("保存类型模板失败", str(exc), parent=self.root)

    def manage_report_presets(self):
        try:
            ensure_builtin_presets(self.template_library)
        except (OSError, ValueError) as exc:
            messagebox.showerror("模板库错误", str(exc), parent=self.root)
            return
        dialog = tk.Toplevel(self.root)
        dialog.title("报表类型模板库（所有产品共享）")
        dialog.geometry("900x480")
        dialog.transient(self.root)
        ttk.Label(dialog, text="在任意产品保存的类型模板，都可在这里查看和套用；Excel 文件已复制到共享库。").pack(anchor=tk.W, padx=10, pady=10)
        search = tk.StringVar()
        ttk.Entry(dialog, textvariable=search).pack(fill=tk.X, padx=10)
        frame = ttk.Frame(dialog)
        frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=8)
        tree = ttk.Treeview(frame, columns=("name", "reports", "description"), show="headings")
        for column, title, width in (("name", "模板名称", 240), ("reports", "报表类型", 220), ("description", "说明", 350)):
            tree.heading(column, text=title)
            tree.column(column, width=width)
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = ttk.Scrollbar(frame, command=tree.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        tree.configure(yscrollcommand=scrollbar.set)
        items = {}

        def refresh(*_args):
            items.clear()
            tree.delete(*tree.get_children())
            query = search.get().strip().casefold()
            for item in self.template_library.list_items():
                if item.get("kind") != "report_type":
                    continue
                values = (item["name"], "、".join(item.get("config", {}).get("rules", {})), item.get("requirement", ""))
                if query and query not in " ".join(values).casefold():
                    continue
                items[item["id"]] = item
                tree.insert("", tk.END, iid=item["id"], values=values)

        def selected():
            selection = tree.selection()
            return items.get(selection[0]) if selection else None

        def use():
            item = selected()
            if item:
                dialog.destroy()
                self.add_report_from_preset(item["id"])

        def rename():
            item = selected()
            if not item:
                return
            name = simpledialog.askstring("模板改名", "共享模板名称：", initialvalue=item["name"], parent=dialog)
            if name and name.strip():
                try:
                    self.template_library.update_metadata(item["id"], {"name": name.strip()})
                    refresh()
                except (OSError, ValueError) as exc:
                    messagebox.showerror("改名失败", str(exc), parent=dialog)

        def delete():
            item = selected()
            if item and messagebox.askyesno("删除共享模板", f"从共享库删除“{item['name']}”？已套用的产品仍可使用。", parent=dialog):
                try:
                    self.template_library.delete(item["id"])
                    refresh()
                except OSError as exc:
                    messagebox.showerror("删除失败", str(exc), parent=dialog)

        buttons = ttk.Frame(dialog)
        buttons.pack(fill=tk.X, padx=10, pady=10)
        ttk.Button(buttons, text="刷新", command=refresh).pack(side=tk.LEFT, padx=3)
        ttk.Button(buttons, text="改名", command=rename).pack(side=tk.LEFT, padx=3)
        ttk.Button(buttons, text="删除", command=delete).pack(side=tk.LEFT, padx=3)
        ttk.Button(buttons, text="套用到当前产品", command=use).pack(side=tk.RIGHT, padx=3)
        tree.bind("<Double-1>", lambda _event: use())
        search.trace_add("write", refresh)
        refresh()

    def add_report_from_preset(self, preset_id=None):
        try:
            self._store_rule_form()
            self._store_profile()
            ensure_builtin_presets(self.template_library)
        except (ValueError, OSError) as exc:
            messagebox.showerror("类型模板错误", str(exc), parent=self.root)
            return
        choices = []
        for item in self.template_library.list_items():
            if preset_id is not None and item["id"] != preset_id:
                continue
            config = item.get("config", {})
            for report in config.get("rules", {}):
                try:
                    instantiate_preset(config, report, report, [])
                except (ValueError, KeyError):
                    continue
                choices.append((f"{item['name']} / {report}", config, report))
        if not choices:
            messagebox.showwarning("提示", "该模板已删除或配置不完整，请刷新模板库", parent=self.root)
            return
        dialog = tk.Toplevel(self.root)
        dialog.title("从报表类型模板新增")
        dialog.transient(self.root)
        dialog.grab_set()
        ttk.Label(dialog, text="套用后自动带入规则、列映射、Excel模板和表头表尾位置。").pack(padx=12, pady=8)
        selected = tk.StringVar(value=choices[0][0] if choices else "")
        selector = ttk.Combobox(dialog, textvariable=selected, values=[c[0] for c in choices], state="readonly", width=65)
        selector.pack(padx=12, pady=6)
        def available_name(base):
            result, number = base, 2
            while result in self.rules:
                result = f"{base}-{number}"
                number += 1
            return result

        name = tk.StringVar(value=available_name(choices[0][2]) if choices else "")
        ttk.Label(dialog, text="新报表名称（已有同名报表时，请换个名称）").pack(anchor=tk.W, padx=12)
        ttk.Entry(dialog, textvariable=name, width=65).pack(padx=12, pady=6, fill=tk.X)
        selector.bind("<<ComboboxSelected>>", lambda _e: name.set(available_name(choices[selector.current()][2])))
        ttk.Label(dialog, text="选择当前产品的来源工序（可多选）").pack(anchor=tk.W, padx=12)
        box = tk.Listbox(dialog, selectmode=tk.MULTIPLE, exportselection=False, width=65, height=8)
        box.pack(padx=12, pady=6, fill=tk.BOTH, expand=True)
        drawings = list(dict.fromkeys(self.df_source["图纸"].dropna().astype(str))) if self.df_source is not None else []
        for drawing in drawings:
            box.insert(tk.END, drawing)
        if len(drawings) == 1:
            box.selection_set(0)

        def create():
            report_name = name.get().strip()
            if not report_name or report_name in self.rules:
                messagebox.showwarning("提示", "请填写一个尚未使用的报表名称", parent=dialog)
                return
            sources = [drawings[index] for index in box.curselection()]
            if not sources:
                messagebox.showwarning("提示", "请先加载产品数据并选择来源工序", parent=dialog)
                return
            try:
                _, config, source_report = choices[selector.current()]
                preset = instantiate_preset(config, source_report, report_name, sources)
                self._install_report_preset(preset)
                dialog.destroy()
            except (ValueError, OSError, KeyError) as exc:
                messagebox.showerror("套用失败", str(exc), parent=dialog)

        ttk.Button(dialog, text="创建并套用", command=create).pack(pady=10)

    def _install_report_preset(self, preset):
        name = preset["name"]
        if name in self.rules:
            raise ValueError("报表名称已存在")
        if not Path(preset["path"]).is_file():
            raise FileNotFoundError("类型模板文件不存在，请重新保存该模板")
        self.rules[name] = copy.deepcopy(preset["rule"])
        for profile in self.template_profiles.values():
            profile.setdefault("sheet_config", {})[name] = {"sheet_name": name, "header": 0, "footer": 0}
        profile_name = f"类型模板-{name}"
        while profile_name in self.template_profiles:
            profile_name += "-新"
        settings = {report: {"sheet_name": report, "header": 0, "footer": 0} for report in self.rules}
        settings[name] = copy.deepcopy(preset["settings"])
        self.template_profiles[profile_name] = self._own_template_profile(profile_name, {"path": preset["path"], "sheet_config": settings})
        self.active_template_profile = profile_name
        self.sheet_config = settings
        self.template_path.set(self.template_profiles[profile_name]["path"])
        self.profile_selector["values"] = list(self.template_profiles)
        self.profile_var.set(profile_name)
        self.rule_selector["values"] = self.report_types
        self.template_selector["values"] = self.report_types
        self.active_rule = self.active_template = name
        self.rule_report.set(name)
        self.template_report.set(name)
        self._load_rule_form()
        self._load_template_form()
        self.status.set(f"已套用类型模板：{name}，可直接预览和生成；模板方案：{profile_name}")

    def add_report_type(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("新增报表")
        dialog.transient(self.root)
        dialog.grab_set()
        name = tk.StringVar()
        base = tk.StringVar(value=self.active_rule)
        ttk.Label(dialog, text="报表名称").grid(row=0, column=0, padx=10, pady=8, sticky=tk.W)
        ttk.Entry(dialog, textvariable=name, width=34).grid(row=0, column=1, padx=10, pady=8)
        ttk.Label(dialog, text="复制规则自").grid(row=1, column=0, padx=10, pady=8, sticky=tk.W)
        ttk.Combobox(dialog, textvariable=base, values=self.report_types, state="readonly", width=31).grid(
            row=1, column=1, padx=10, pady=8
        )

        def create():
            report_name = name.get().strip()
            if not report_name or report_name in self.rules:
                messagebox.showwarning("提示", "报表名称为空或已存在", parent=dialog)
                return
            try:
                self._store_rule_form()
                self._store_profile()
            except ValueError as exc:
                messagebox.showerror("配置错误", str(exc), parent=dialog)
                return
            source_name = base.get().strip()
            if source_name not in self.rules:
                messagebox.showerror("配置错误", "复制规则必须选择已有报表类型", parent=dialog)
                return
            if source_name == report_name:
                messagebox.showerror("配置错误", "不能复制自身", parent=dialog)
                return
            self.rules[report_name] = copy.deepcopy(self.rules[source_name])
            self.rules[report_name]["base_type"] = self.rules[source_name].get("base_type", source_name)
            # 新报表不继承来源报表的图纸范围，避免误把图片一数据带入图片二报表。
            self.rules[report_name]["source_drawings"] = []
            for key in ("report_version", "report_date", "report_author", "report_reason"):
                self.rules[report_name][key] = ""
            for profile in self.template_profiles.values():
                profile.setdefault("sheet_config", {})[report_name] = {
                    "sheet_name": report_name, "header": 0, "footer": 0,
                }
            self.sheet_config = self.template_profiles[self.active_template_profile]["sheet_config"]
            self.rule_selector["values"] = self.report_types
            self.template_selector["values"] = self.report_types
            self.active_rule = report_name
            self.active_template = report_name
            self.rule_report.set(report_name)
            self.template_report.set(report_name)
            self._load_rule_form()
            self._load_template_form()
            dialog.destroy()

        ttk.Button(dialog, text="创建", command=create).grid(row=2, column=0, columnspan=2, pady=10)
        dialog.wait_window()

    def delete_report_type(self):
        if len(self.rules) <= 1:
            messagebox.showwarning("提示", "至少保留一个报表")
            return
        name = self.active_rule
        if not messagebox.askyesno("删除报表", f"删除报表配置“{name}”？"):
            return
        self.rules.pop(name, None)
        for profile in self.template_profiles.values():
            profile.get("sheet_config", {}).pop(name, None)
        self.active_rule = self.report_types[0]
        self.active_template = self.active_rule
        self.sheet_config = self.template_profiles[self.active_template_profile]["sheet_config"]
        self.rule_selector["values"] = self.report_types
        self.template_selector["values"] = self.report_types
        self.rule_report.set(self.active_rule)
        self.template_report.set(self.active_template)
        self._load_rule_form()
        self._load_template_form()

    def _build_dictionary_tab(self, parent):
        notebook = ttk.Notebook(parent)
        notebook.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)
        definitions = {
            "item": ("项目翻译", ("检验项目", "检验项目翻译")),
            "ship": ("出货器具翻译", ("测量器具", "出货检验翻译")),
            "process": ("过程器具翻译", ("测量器具", "过程检验翻译")),
            "freq": ("检验频次", tuple(self.freq_df.columns)),
        }
        self.dict_trees = {}
        self.dict_columns = {}
        for key, (title, columns) in definitions.items():
            tab = ttk.Frame(notebook)
            notebook.add(tab, text=title)
            toolbar = ttk.Frame(tab)
            toolbar.pack(fill=tk.X, padx=8, pady=5)
            ttk.Button(toolbar, text="添加", command=lambda k=key: self.edit_dictionary_row(k, True)).pack(side=tk.LEFT, padx=2)
            ttk.Button(toolbar, text="编辑", command=lambda k=key: self.edit_dictionary_row(k, False)).pack(side=tk.LEFT, padx=2)
            ttk.Button(toolbar, text="删除", command=lambda k=key: self.delete_dictionary_row(k)).pack(side=tk.LEFT, padx=2)
            tree = self._make_table(tab)
            tree["columns"] = columns
            for column in columns:
                tree.heading(column, text=column)
                tree.column(column, width=145, stretch=True)
            tree.bind("<Double-1>", lambda _event, k=key: self.edit_dictionary_row(k, False))
            self.dict_trees[key] = tree
            self.dict_columns[key] = columns
        self.refresh_dictionaries()

    def refresh_dictionaries(self):
        sources = {
            "item": self.item_trans.items(), "ship": self.tool_ship.items(),
            "process": self.tool_proc.items(),
            "freq": self.freq_df.itertuples(index=False, name=None),
        }
        for key, rows in sources.items():
            tree = self.dict_trees[key]
            tree.delete(*tree.get_children())
            for row in rows:
                tree.insert("", tk.END, values=tuple(row))

    def sync_dictionaries(self):
        for key, target in (
            ("item", "item_trans"), ("ship", "tool_ship"), ("process", "tool_proc")
        ):
            tree = self.dict_trees[key]
            setattr(self, target, {
                tree.item(item, "values")[0]: tree.item(item, "values")[1]
                for item in tree.get_children() if tree.item(item, "values")[0]
            })
        tree = self.dict_trees["freq"]
        rows = [tree.item(item, "values") for item in tree.get_children()]
        self.freq_df = pd.DataFrame(rows, columns=self.dict_columns["freq"])

    def edit_dictionary_row(self, key, adding):
        tree = self.dict_trees[key]
        selection = tree.selection()
        if not adding and not selection:
            messagebox.showwarning("提示", "请先选择一行")
            return
        old = tree.item(selection[0], "values") if selection else ()
        dialog = tk.Toplevel(self.root)
        dialog.title("添加数据" if adding else "编辑数据")
        dialog.transient(self.root)
        dialog.grab_set()
        variables = []
        for index, column in enumerate(self.dict_columns[key]):
            ttk.Label(dialog, text=column).grid(row=index, column=0, padx=10, pady=6, sticky=tk.W)
            variable = tk.StringVar(value=old[index] if index < len(old) else "")
            variables.append(variable)
            ttk.Entry(dialog, textvariable=variable, width=42).grid(row=index, column=1, padx=10, pady=6)

        def save():
            values = [variable.get().strip() for variable in variables]
            if not values[0]:
                messagebox.showwarning("提示", "首列不能为空", parent=dialog)
                return
            if adding:
                tree.insert("", tk.END, values=values)
            else:
                tree.item(selection[0], values=values)
            dialog.destroy()

        ttk.Button(dialog, text="确定", command=save).grid(row=len(variables), column=0, columnspan=2, pady=10)
        dialog.wait_window()

    def delete_dictionary_row(self, key):
        tree = self.dict_trees[key]
        selection = tree.selection()
        if selection and messagebox.askyesno("删除", "确定删除选中的记录？"):
            tree.delete(*selection)

    def _build_template_tab(self, parent):
        profiles = ttk.Frame(parent)
        profiles.pack(fill=tk.X, padx=10, pady=6)
        self.profile_var = tk.StringVar(value=self.active_template_profile)
        self.profile_selector = ttk.Combobox(profiles, textvariable=self.profile_var,
                                            values=list(self.template_profiles), state="readonly")
        self.profile_selector.pack(side=tk.LEFT)
        self.profile_selector.bind("<<ComboboxSelected>>", self.switch_profile)
        ttk.Button(profiles, text="新增模板方案", command=self.add_profile).pack(side=tk.LEFT, padx=4)
        ttk.Button(profiles, text="复制为产品模板", command=self.copy_profile_template).pack(side=tk.LEFT, padx=4)
        ttk.Button(profiles, text="删除模板方案", command=self.delete_profile).pack(side=tk.LEFT)
        path_bar = ttk.Frame(parent)
        path_bar.pack(fill=tk.X, padx=10, pady=10)
        ttk.Label(path_bar, text="Excel 模板").pack(side=tk.LEFT, padx=4)
        template_entry = ttk.Entry(path_bar, textvariable=self.template_path)
        template_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4)
        template_entry.bind("<FocusOut>", lambda _e: self.refresh_template_sheets())
        template_entry.bind("<Return>", lambda _e: self.refresh_template_sheets())
        ttk.Button(path_bar, text="选择", command=self.browse_template).pack(side=tk.LEFT)
        ttk.Button(path_bar, text="模板档案库", command=self.manage_template_catalog).pack(side=tk.LEFT, padx=4)
        ttk.Button(path_bar, text="报表类型模板库", command=self.manage_report_presets).pack(side=tk.LEFT, padx=4)

        ttk.Button(parent, text="查看报表格式引用数量 / 工作表对应关系", command=self.manage_sheet_mapping).pack(fill=tk.X, padx=10, pady=4)
        config = ttk.LabelFrame(parent, text="工作表定位")
        config.pack(fill=tk.X, padx=10, pady=8)
        self.template_report = tk.StringVar(value=self.active_template)
        ttk.Label(config, text="报表类型").grid(row=0, column=0, padx=8, pady=8)
        selector = ttk.Combobox(config, textvariable=self.template_report, values=self.report_types,
                                state="readonly", width=24)
        selector.grid(row=0, column=1, sticky=tk.W, padx=8)
        selector.bind("<<ComboboxSelected>>", self._on_template_select)
        self.template_selector = selector
        self.sheet_name_var = tk.StringVar()
        self.header_var = tk.StringVar()
        self.footer_var = tk.StringVar()
        self.history_sheet_var = tk.StringVar()
        self.history_start_var = tk.StringVar()
        self.header_cells_var = tk.StringVar()
        for row, (label, variable) in enumerate((
            ("工作表名", self.sheet_name_var),
            ("表头行", self.header_var),
            ("表尾起始行 (可空)", self.footer_var),
            ("修改记录工作表（空为当前表）", self.history_sheet_var),
            ("最新三条起始单元格（空为不显示）", self.history_start_var),
            ("产品信息单元格（字段=单元格，逗号分隔）", self.header_cells_var),
        ), 1):
            ttk.Label(config, text=label).grid(row=row, column=0, sticky=tk.W, padx=8, pady=7)
            widget = (ttk.Combobox(config, textvariable=variable, width=40, state="readonly",
                                  postcommand=self.refresh_template_sheets)
                      if variable is self.sheet_name_var else ttk.Entry(config, textvariable=variable, width=40))
            widget.grid(row=row, column=1, sticky=tk.W, padx=8)
            if variable is self.sheet_name_var:
                self.sheet_selector = widget
        tools = ttk.Frame(config)
        tools.grid(row=7, column=0, columnspan=3, sticky=tk.W, padx=8, pady=10)
        ttk.Button(tools, text="预览并选行", command=self.preview_template_sheet).pack(side=tk.LEFT, padx=3)
        ttk.Button(tools, text="列映射", command=self.edit_column_mapping).pack(side=tk.LEFT, padx=3)
        ttk.Button(tools, text="固定列", command=self.edit_fixed_columns).pack(side=tk.LEFT, padx=3)
        ttk.Button(tools, text="条件规则", command=self.edit_conditional_rules).pack(side=tk.LEFT, padx=3)
        ttk.Button(tools, text="产品信息位置预览", command=self.preview_product_cells).pack(side=tk.LEFT, padx=3)
        self.header_cells_hint = tk.StringVar(value="输入字段及单元格后，可预览具体位置，例如：产品名=B2，版本=F2")
        ttk.Label(config, textvariable=self.header_cells_hint, wraplength=900).grid(row=8, column=0, columnspan=3, sticky=tk.W, padx=8, pady=5)
        def update_hint(*_args):
            try:
                mapping = self._header_cell_mapping()
                sheet = self.sheet_name_var.get()
                self.header_cells_hint.set("；".join(f"{field} → '{sheet}'!{address}" for field, address in mapping.items())
                                           or "尚未设置产品信息位置，例如：产品名=B2，版本=F2")
            except ValueError as exc:
                self.header_cells_hint.set(str(exc))
        self.header_cells_var.trace_add("write", update_hint)
        self.sheet_name_var.trace_add("write", update_hint)
        self._load_template_form()

    def manage_sheet_mapping(self):
        try:
            self._store_template_form()
            names = self.template_sheet_names()
        except Exception as exc:
            messagebox.showerror('工作表对应关系', str(exc), parent=self.root)
            return
        dialog = tk.Toplevel(self.root)
        dialog.title('工作表与报表类型对应关系')
        summary = tk.StringVar()
        ttk.Label(dialog, textvariable=summary).pack(padx=12, pady=10)
        tree = ttk.Treeview(dialog, columns=('sheet', 'report', 'status'), show='headings', height=12)
        for key, title in (('sheet', '工作表'), ('report', '报表类型'), ('status', '填充状态')):
            tree.heading(key, text=title)
            tree.column(key, width=220)
        tree.pack(fill=tk.BOTH, expand=True, padx=12)
        def refresh():
            tree.delete(*tree.get_children())
            active = {n: c for n, c in self.sheet_config.items() if c.get('header', 0) > 0}
            for i, sheet in enumerate(names):
                reports = [n for n, c in active.items() if c['sheet_name'] == sheet]
                tree.insert('', 'end', iid=str(i), values=(sheet, '、'.join(reports) or '不填充',
                            '冲突：请选择一个类型' if len(reports) > 1 else ('填充数据' if reports else '保留原表')))
            count = len({c['sheet_name'] for c in active.values()} & set(names))
            missing = [n for n, c in active.items() if c['sheet_name'] not in names]
            summary.set(f'当前引用 {len(active)} 种报表格式 · 已配置 {count}/{len(names)} 个工作表'
                        + (f" · 工作表不存在：{'、'.join(missing)}" if missing else ''))
        bar = ttk.Frame(dialog)
        bar.pack(fill=tk.X, padx=12, pady=12)
        choice = ttk.Combobox(bar, state='readonly', values=['不填充'] + list(self.report_types), width=28)
        choice.pack(side=tk.LEFT)
        choice.current(0)
        def select(_event=None):
            if tree.selection():
                sheet = names[int(tree.selection()[0])]
                reports = [n for n, c in self.sheet_config.items() if c.get('header', 0) > 0 and c['sheet_name'] == sheet]
                choice.set(reports[0] if len(reports) == 1 else '不填充')
        tree.bind('<<TreeviewSelect>>', select)
        def assign():
            if not tree.selection():
                return
            sheet = names[int(tree.selection()[0])]
            report = choice.get()
            header = self.sheet_config[report]['header'] if report != '不填充' else 0
            for cfg in self.sheet_config.values():
                if cfg['sheet_name'] == sheet:
                    cfg['header'] = 0
            if report != '不填充':
                self.sheet_config[report].update(sheet_name=sheet, header=max(1, header))
            self._load_template_form()
            self._store_profile()
            refresh()
        ttk.Button(bar, text='设置对应关系', command=assign).pack(side=tk.LEFT, padx=8)
        ttk.Label(dialog, text='每张工作表选择一个报表类型或不填充。新启用类型的表头行默认为 1，请在主界面核对。').pack(padx=12, pady=8)
        refresh()

    def _own_template_profile(self, name, profile):
        path = str(profile.get("path", "")).strip()
        if not path:
            return profile
        source = Path(path).resolve()
        if not source.is_file():
            raise FileNotFoundError(f"模板文件不存在：{source}")
        config_file = getattr(self, "config_file", "")
        product_dir = Path(config_file).resolve().parent if config_file else source.parent
        target_dir = product_dir / "templates"
        target_dir.mkdir(parents=True, exist_ok=True)
        if source.parent == target_dir.resolve():
            owned = copy.deepcopy(profile)
            owned['path'] = str(source)
            return owned
        extension = source.suffix.lower()
        if extension not in ('.xlsx', '.xlsm', '.xls'):
            raise ValueError('请选择 Excel 模板文件')
        import re
        import uuid
        import shutil
        safe_name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', str(name)).strip(' .')[:48] or '模板'
        target = target_dir / f"{safe_name}_{uuid.uuid4().hex[:8]}{extension}"
        shutil.copy2(source, target)
        owned = copy.deepcopy(profile)
        owned["path"] = str(target)
        return owned

    def _store_profile(self):
        self._store_template_form()
        profile = {
            "path": self.template_path.get().strip(), "sheet_config": self.sheet_config,
        }
        self.template_profiles[self.active_template_profile] = self._own_template_profile(self.active_template_profile, profile)
        self.template_path.set(self.template_profiles[self.active_template_profile]['path'])
        self.sheet_config = self.template_profiles[self.active_template_profile]['sheet_config']

    def switch_profile(self, _event=None):
        try:
            self._store_profile()
        except (OSError, ValueError) as exc:
            self.profile_var.set(self.active_template_profile)
            messagebox.showerror("模板设置错误", str(exc))
            return
        self.active_template_profile = self.profile_var.get()
        profile = self.template_profiles[self.active_template_profile]
        self.sheet_config = profile["sheet_config"]
        self.template_path.set(profile["path"])
        self._load_template_form()

    def add_profile(self):
        name = simpledialog.askstring("新增模板方案", "方案名称：", parent=self.root)
        if not name or not name.strip():
            return
        name = name.strip()
        if name in self.template_profiles:
            messagebox.showerror("提示", "方案名称已存在")
            return
        try:
            self._store_profile()
        except (OSError, ValueError) as exc:
            messagebox.showerror("模板设置错误", str(exc))
            return
        self.template_profiles[name] = {"path": "", "sheet_config": {
            report: {"sheet_name": report, "header": 0, "footer": 0} for report in self.report_types
        }}
        self.profile_selector["values"] = list(self.template_profiles)
        self.profile_var.set(name)
        self.switch_profile()

    def copy_profile_template(self):
        try:
            self._store_profile()
            owned = self._own_template_profile(self.active_template_profile,
                                               self.template_profiles[self.active_template_profile])
            self.template_profiles[self.active_template_profile] = owned
            self.template_path.set(owned["path"])
            self.status.set("已复制并切换到产品专属模板")
        except (OSError, ValueError) as exc:
            messagebox.showerror("复制模板失败", str(exc), parent=self.root)

    def delete_profile(self):
        if len(self.template_profiles) == 1:
            messagebox.showwarning("提示", "至少保留一个模板方案")
            return
        if not messagebox.askyesno("删除模板方案", f"删除“{self.active_template_profile}”配置？"):
            return
        del self.template_profiles[self.active_template_profile]
        self.active_template_profile = next(iter(self.template_profiles))
        profile = self.template_profiles[self.active_template_profile]
        self.sheet_config = profile["sheet_config"]
        self.template_path.set(profile["path"])
        self.profile_var.set(self.active_template_profile)
        self.profile_selector["values"] = list(self.template_profiles)
        self._load_template_form()

    def browse_template(self):
        path = filedialog.askopenfilename(filetypes=[("Excel 文件", "*.xlsx *.xlsm *.xls")])
        if path:
            try:
                owned = self._own_template_profile(self.active_template_profile,
                    {'path': path, 'sheet_config': self.sheet_config})
                self.template_profiles[self.active_template_profile] = owned
                self.template_path.set(owned['path'])
                self.refresh_template_sheets()
                self.status.set('已另存为当前产品的专属模板')
            except (OSError, ValueError) as exc:
                messagebox.showerror('复制模板失败', str(exc), parent=self.root)

    def import_catalog_config(self, path):
        config = ConfigStore(path).load()
        if not config or not isinstance(config.get("rules"), dict):
            raise ValueError("请选择已配置好的 report_generator_config.json")
        base = os.path.dirname(os.path.abspath(path))
        config = copy.deepcopy(config)
        config.pop("template_catalog", None)
        for profile in config.get("template_profiles", {}).values():
            value = profile.get("path", "")
            if value and not os.path.isabs(value):
                profile["path"] = os.path.normpath(os.path.join(base, value))
        value = config.get("templates", {}).get("path", "")
        if value and not os.path.isabs(value):
            config["templates"]["path"] = os.path.normpath(os.path.join(base, value))
        item = {"name": os.path.basename(base) + " 配置模板",
                "path": os.path.abspath(path), "config": config}
        self.template_library.add(item, base)
        self.template_catalog = self.template_library.list_items()

    def apply_catalog_item(self, item):
        if "config" not in item:
            owned = self._own_template_profile(self.active_template_profile,
                {'path': item.get('path', ''), 'sheet_config': self.sheet_config})
            self.template_profiles[self.active_template_profile] = owned
            self.template_path.set(owned['path'])
            self.refresh_template_sheets()
            return
        destination = self.config_file
        catalog = copy.deepcopy(self.template_catalog)
        self.load_config(config_value=copy.deepcopy(item["config"]))
        self.config_file = destination
        self.template_catalog = catalog
        self.template_profiles = {name: self._own_template_profile(name, profile)
                                  for name, profile in self.template_profiles.items()}
        active = self.template_profiles[self.active_template_profile]
        self.sheet_config = active['sheet_config']
        self.template_path.set(active['path'])

    def upload_current_template(self, metadata):
        if not self.save_config():
            raise ValueError("当前产品配置未能保存，请检查报表及模板设置")
        item = {**metadata, "config": ConfigStore(self.config_file).load()}
        self.template_library.add(item, Path(self.config_file).parent)
        self.template_catalog = self.template_library.list_items()

    def manage_template_catalog(self):
        self.template_catalog = self.template_library.list_items()
        dialog = tk.Toplevel(self.root)
        dialog.title("报表模板档案库（所有产品共享）")
        dialog.geometry("1000x480")
        ttk.Label(dialog, text="所有产品共享；点击新增上传 Excel、已配置 JSON 或当前产品配置。").pack(anchor=tk.W, padx=8, pady=6)
        columns = ("name", "process", "material", "requirement", "path")
        tree = ttk.Treeview(dialog, columns=columns, show="headings")
        labels = {"name": "模板名称", "process": "工序", "material": "材料", "requirement": "材料技术要求", "path": "模板文件"}
        for key in columns:
            tree.heading(key, text=labels[key])
            tree.column(key, width=150 if key != "path" else 260)
        tree.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)

        def refresh():
            tree.delete(*tree.get_children())
            for index, item in enumerate(self.template_catalog):
                tree.insert("", tk.END, iid=str(index), values=tuple(item.get(key, "") for key in columns))

        def edit(index=None):
            current = self.template_catalog[index] if index is not None else {}
            form = tk.Toplevel(dialog)
            form.title("编辑模板档案" if index is not None else "新增并上传模板")
            variables = {key: tk.StringVar(value=str(current.get(key, ""))) for key in columns}
            for row, key in enumerate(columns):
                ttk.Label(form, text=labels[key]).grid(row=row, column=0, sticky=tk.W, padx=8, pady=6)
                ttk.Entry(form, textvariable=variables[key], width=70,
                          state="readonly" if key == "path" else "normal").grid(row=row, column=1, padx=8, pady=6)
            mode = tk.StringVar(value="选择文件上传")
            if index is None:
                ttk.Combobox(form, textvariable=mode, state="readonly",
                             values=("选择文件上传", "上传当前产品配置"), width=28).grid(row=5, column=1, sticky=tk.W, padx=8)
                def browse():
                    path = filedialog.askopenfilename(parent=form, title="选择 Excel 模板或报表配置 JSON",
                        filetypes=[("Excel 或配置文件", "*.xlsx *.xlsm *.xls *.json"), ("所有文件", "*.*")])
                    if path:
                        variables["path"].set(path)
                        mode.set("选择文件上传")
                        if not variables["name"].get().strip():
                            variables["name"].set(Path(path).stem)
                ttk.Button(form, text="选择文件…", command=browse).grid(row=4, column=2, padx=8)
            def save():
                item = {key: variables[key].get().strip() for key in columns}
                try:
                    if index is not None:
                        self.template_library.update_metadata(current["id"], item)
                    elif mode.get() == "上传当前产品配置":
                        self.upload_current_template(item)
                    elif item["path"].lower().endswith(".json"):
                        config = ConfigStore(item["path"]).load()
                        if not config or not isinstance(config.get("rules"), dict):
                            raise ValueError("请选择已配置好的报表 JSON 文件")
                        item["config"] = config
                        self.template_library.add(item, Path(item["path"]).parent)
                    else:
                        self.template_library.add(item)
                    self.template_catalog = self.template_library.list_items()
                except (OSError, ValueError, TypeError) as exc:
                    messagebox.showerror("上传或保存失败", str(exc), parent=form)
                    return
                refresh()
                form.destroy()
            ttk.Button(form, text="保存" if index is not None else "上传到共享档案库", command=save).grid(row=6, column=0, columnspan=2, pady=10)

        def selected_index():
            selected = tree.selection()
            return int(selected[0]) if selected else None

        def use_selected():
            index = selected_index()
            if index is None:
                return
            try:
                self.apply_catalog_item(self.template_catalog[index])
                dialog.destroy()
            except (OSError, ValueError) as exc:
                messagebox.showerror("使用模板失败", str(exc), parent=dialog)

        def delete_selected():
            index = selected_index()
            if index is not None and messagebox.askyesno("删除模板档案", "确定删除选中的模板档案？", parent=dialog):
                try:
                    self.template_library.delete(self.template_catalog[index]["id"])
                    self.template_catalog = self.template_library.list_items()
                    refresh()
                except OSError as exc:
                    messagebox.showerror("删除失败", str(exc), parent=dialog)

        def import_config():
            path = filedialog.askopenfilename(parent=dialog, filetypes=[("报表配置 JSON", "*.json")])
            if path:
                try:
                    self.import_catalog_config(path)
                    refresh()
                except Exception as exc:
                    messagebox.showerror("导入失败", str(exc), parent=dialog)
        buttons = ttk.Frame(dialog)
        buttons.pack(fill=tk.X, padx=8, pady=(0, 8))
        ttk.Button(buttons, text="导入已配置 JSON", command=import_config).pack(side=tk.LEFT, padx=3)
        ttk.Button(buttons, text="新增", command=lambda: edit()).pack(side=tk.LEFT, padx=3)
        ttk.Button(buttons, text="编辑", command=lambda: edit(selected_index())).pack(side=tk.LEFT, padx=3)
        ttk.Button(buttons, text="删除", command=delete_selected).pack(side=tk.LEFT, padx=3)
        ttk.Button(buttons, text="使用选中模板", command=use_selected).pack(side=tk.RIGHT, padx=3)
        refresh()

    def _store_template_form(self):
        try:
            header = int(self.header_var.get() or 0)
            footer = int(self.footer_var.get() or 0)
        except ValueError as exc:
            raise ValueError("表头行和表尾行必须是整数") from exc
        if header < 0 or footer < 0 or (footer and footer <= header):
            raise ValueError("表尾行必须位于表头行下方")
        start = self.history_start_var.get().strip().upper()
        if start:
            history_origin(start)
        header_cells = self._header_cell_mapping()
        self.sheet_config[self.active_template] = {
            "sheet_name": self.sheet_name_var.get().strip() or self.active_template,
            "header": header, "footer": footer,
            "history_sheet": self.history_sheet_var.get().strip(), "history_start": start,
            "header_cells": header_cells,
        }

    def _load_template_form(self):
        config = self.sheet_config[self.active_template]
        self.sheet_name_var.set(config["sheet_name"])
        self.header_var.set(str(config["header"]))
        self.footer_var.set(str(config["footer"] or ""))
        self.history_sheet_var.set(config.get("history_sheet", ""))
        self.history_start_var.set(config.get("history_start", ""))
        self.header_cells_var.set(", ".join(f"{k}={v}" for k, v in config.get("header_cells", {}).items()))
        self.refresh_template_sheets()

    def _on_template_select(self, _event):
        try:
            self._store_template_form()
        except ValueError as exc:
            messagebox.showerror("模板设置错误", str(exc))
            self.template_report.set(self.active_template)
            return
        self.active_template = self.template_report.get()
        self._load_template_form()

    def template_sheet_names(self):
        path = self.template_path.get().strip()
        if not os.path.isfile(path):
            raise FileNotFoundError("请先选择有效的模板文件")
        if path.lower().endswith((".xlsx", ".xlsm")):
            workbook = excel_com.load_workbook(path, read_only=True, data_only=True)
            try:
                return workbook.sheetnames
            finally:
                workbook.close()
        with excel_app() as app:
            workbook = app.Workbooks.Open(os.path.abspath(path))
            try:
                return [workbook.Sheets(i).Name for i in range(1, workbook.Sheets.Count + 1)]
            finally:
                workbook.Close(SaveChanges=False)

    def refresh_template_sheets(self):
        try:
            names = self.template_sheet_names()
            self.sheet_selector["values"] = names
            if names and self.sheet_name_var.get() not in names:
                self.sheet_name_var.set(names[0])
        except Exception:
            self.sheet_selector["values"] = []

    def _header_cell_mapping(self):
        return parse_header_cells(self.header_cells_var.get(),
            (*REPORT_HEADER_FIELDS, "报表版本", "报表修订日期", "报表修订人", "报表修订原因"))

    def preview_product_cells(self):
        try:
            self.refresh_template_sheets()
            mapping = self._header_cell_mapping()
            if not mapping:
                raise ValueError("请先填写产品信息单元格，例如：产品名=B2，版本=F2")
            path = self.template_path.get().strip()
            sheet = self.sheet_name_var.get()
            if not path.lower().endswith((".xlsx", ".xlsm")):
                raise ValueError("产品信息位置预览支持 xlsx / xlsm，请先将旧版 xls 另存为 xlsx")
            previews = preview_header_cells(path, sheet, mapping)
        except (OSError, ValueError, KeyError) as exc:
            messagebox.showerror("位置预览失败", str(exc), parent=self.root)
            return
        dialog = tk.Toplevel(self.root)
        dialog.title(f"产品信息位置预览 — {Path(path).name} / {sheet}")
        dialog.geometry("1000x600")
        dialog.transient(self.root)
        dialog.grab_set()
        ttk.Label(dialog, text="选择字段查看单元格及周围位置；【目标】标出写入位置。合并单元格须使用左上角地址。").pack(anchor=tk.W, padx=10, pady=8)
        fields = ttk.Treeview(dialog, columns=("field", "address", "value", "anchor"), show="headings", height=6)
        for key, title in (("field", "产品信息字段"), ("address", "具体位置"), ("value", "模板现有内容"), ("anchor", "合并区域左上角")):
            fields.heading(key, text=title)
            fields.column(key, width=220)
        fields.pack(fill=tk.X, padx=10)
        for index, entry in enumerate(previews):
            fields.insert("", tk.END, iid=str(index), values=(entry["field"], f"'{sheet}'!{entry['address']}",
                          "" if entry["value"] is None else str(entry["value"]), entry["anchor"]))
        detail = tk.StringVar()
        ttk.Label(dialog, textvariable=detail).pack(anchor=tk.W, padx=10, pady=10)
        grid = self._make_table(dialog)
        grid.tag_configure("target", background="#fff2cc")
        def show(_event=None):
            selection = fields.selection()
            if not selection:
                return
            entry = previews[int(selection[0])]
            detail.set(f"{entry['field']} → '{sheet}'!{entry['address']}（第 {entry['row']} 行，第 {entry['column']} 列）")
            grid.delete(*grid.get_children())
            grid["columns"] = ["行号"] + entry["columns"]
            for column in grid["columns"]:
                grid.heading(column, text=column)
                grid.column(column, width=145, stretch=False)
            for row, values in entry["rows"]:
                display = []
                for column, value in zip(entry["columns"], values):
                    text = "" if value is None else str(value)
                    display.append(("【目标】" if f"{column}{row}" == entry["address"] else "") + text)
                grid.insert("", tk.END, values=[row] + display, tags=("target",) if row == entry["row"] else ())
        fields.bind("<<TreeviewSelect>>", show)
        fields.selection_set("0")
        show()
        ttk.Button(dialog, text="关闭", command=dialog.destroy).pack(pady=8)

    def template_preview_rows(self):
        path = self.template_path.get().strip()
        if not os.path.isfile(path):
            raise FileNotFoundError("请先选择有效的模板文件")
        name = self.sheet_name_var.get().strip()
        if path.lower().endswith((".xlsx", ".xlsm")):
            workbook = excel_com.load_workbook(path, read_only=True, data_only=True)
            try:
                worksheet = workbook[name]
                return [list(row) for row in worksheet.iter_rows(
                    max_row=min(worksheet.max_row, 300), max_col=min(worksheet.max_column, 60), values_only=True)]
            finally:
                workbook.close()
        with excel_app() as app:
            workbook = app.Workbooks.Open(os.path.abspath(path))
            try:
                worksheet = workbook.Sheets(name)
                rows = min(worksheet.UsedRange.Rows.Count, 40)
                cols = min(worksheet.UsedRange.Columns.Count, 20)
                return [
                    [worksheet.Cells(row, col).Value for col in range(1, cols + 1)]
                    for row in range(1, rows + 1)
                ]
            finally:
                workbook.Close(SaveChanges=False)

    def preview_template_sheet(self):
        try:
            names = self.template_sheet_names()
            if self.sheet_name_var.get() not in names:
                self.sheet_name_var.set(names[0])
            rows = self.template_preview_rows()
            if not rows:
                raise ValueError("工作表没有内容")
        except Exception as exc:
            messagebox.showerror("模板预览失败", str(exc))
            return
        dialog = tk.Toplevel(self.root)
        dialog.title("选择表头和表尾")
        dialog.geometry("900x550")
        dialog.transient(self.root)
        dialog.grab_set()
        controls = ttk.Frame(dialog)
        controls.pack(fill=tk.X, padx=8, pady=8)
        sheet_choice = ttk.Combobox(controls, textvariable=self.sheet_name_var,
                                    values=names, state="readonly", width=26)
        sheet_choice.pack(side=tk.LEFT, padx=4)
        def change_sheet(_event=None):
            try:
                new_rows = self.template_preview_rows()
                table.delete(*table.get_children())
                new_columns = ["行号"] + [f"列{i}" for i in range(1, len(new_rows[0]) + 1)] if new_rows else ["行号"]
                table["columns"] = new_columns
                for column in new_columns:
                    table.heading(column, text=column)
                    table.column(column, width=90, stretch=False)
                for index, row in enumerate(new_rows, 1):
                    table.insert("", tk.END, values=[index] + ["" if v is None else str(v) for v in row])
            except Exception as exc:
                messagebox.showerror("预览失败", str(exc), parent=dialog)
        sheet_choice.bind("<<ComboboxSelected>>", change_sheet)
        columns = ["行号"] + [f"列{index}" for index in range(1, len(rows[0]) + 1)]
        table = self._make_table(dialog)
        table["columns"] = columns
        for column in columns:
            table.heading(column, text=column)
            table.column(column, width=90, stretch=False)
        for index, row in enumerate(rows, 1):
            table.insert("", tk.END, values=[index] + ["" if value is None else str(value) for value in row])

        def mark(variable):
            selection = table.selection()
            if selection:
                variable.set(str(table.item(selection[0], "values")[0]))

        ttk.Button(controls, text="设为表头", command=lambda: mark(self.header_var)).pack(side=tk.LEFT, padx=4)
        ttk.Button(controls, text="设为表尾", command=lambda: mark(self.footer_var)).pack(side=tk.LEFT, padx=4)
        ttk.Button(controls, text="清除表尾", command=lambda: self.footer_var.set("")).pack(side=tk.LEFT, padx=4)
        ttk.Button(controls, text="完成", command=dialog.destroy).pack(side=tk.RIGHT, padx=4)
        dialog.wait_window()

    def edit_column_mapping(self):
        self._edit_records(
            "列映射", ("数据字段", "模板列号"), "column_mapping",
            [(key, value) for key, value in
             self.rules[self.active_template].get("column_mapping", {}).items()],
        )

    def edit_fixed_columns(self):
        self._edit_records(
            "固定列", ("模板列号", "固定值"), "fixed_columns",
            [(key, value) for key, value in
             self.rules[self.active_template].get("fixed_columns", {}).items()],
        )

    def edit_conditional_rules(self):
        fields = ("数据字段", "匹配方式", "匹配值", "目标列号", "填充值")
        rules = self.rules[self.active_template].get("conditional_rules", [])
        records = [
            (rule.get("match_df_col", ""), rule.get("match_type", "等于"),
             rule.get("match_value", ""), rule.get("target_col", ""),
             rule.get("fill_value", ""))
            for rule in rules
        ]
        self._edit_records("条件规则", fields, "conditional_rules", records)

    def _edit_records(self, title, fields, key, initial):
        dialog = tk.Toplevel(self.root)
        dialog.title(f"{self.active_template} - {title}")
        dialog.geometry("750x480")
        dialog.transient(self.root)
        dialog.grab_set()
        table = self._make_table(dialog)
        table["columns"] = fields
        for field in fields:
            table.heading(field, text=field)
            table.column(field, width=135, stretch=True)
        for values in initial:
            table.insert("", tk.END, values=values)
        controls = ttk.Frame(dialog)
        controls.pack(fill=tk.X, padx=8, pady=8)
        variables = []
        known_fields = list(self.df_source.columns) if self.df_source is not None else list(FIELD_ALIASES)
        for index, field in enumerate(fields):
            block = ttk.Frame(controls)
            block.grid(row=index // 3, column=index % 3, padx=5, pady=4, sticky=tk.W)
            ttk.Label(block, text=field).pack(anchor=tk.W)
            variable = tk.StringVar()
            variables.append(variable)
            if field == "数据字段":
                widget = ttk.Combobox(block, textvariable=variable, values=known_fields, width=20)
            elif field == "匹配方式":
                widget = ttk.Combobox(block, textvariable=variable,
                                      values=("等于", "包含", "为空", "非空"), state="readonly", width=20)
                variable.set("等于")
            else:
                widget = ttk.Entry(block, textvariable=variable, width=23)
            widget.pack()

        def select(_event=None):
            selection = table.selection()
            if selection:
                for variable, value in zip(variables, table.item(selection[0], "values")):
                    variable.set(value)

        table.bind("<<TreeviewSelect>>", select)
        buttons = ttk.Frame(dialog)
        buttons.pack(fill=tk.X, padx=8, pady=6)

        def upsert():
            values = tuple(variable.get().strip() for variable in variables)
            if not values[0]:
                messagebox.showwarning("提示", "首列不能为空", parent=dialog)
                return
            numeric_index = 0 if key == "fixed_columns" else (3 if key == "conditional_rules" else 1)
            try:
                if int(values[numeric_index]) < 1:
                    raise ValueError
            except ValueError:
                messagebox.showwarning("提示", "模板列号必须是正整数", parent=dialog)
                return
            selection = table.selection()
            if selection:
                table.item(selection[0], values=values)
            else:
                table.insert("", tk.END, values=values)

        def remove():
            selection = table.selection()
            if selection:
                table.delete(*selection)

        def save():
            rows = [table.item(item, "values") for item in table.get_children()]
            if key == "column_mapping":
                self.rules[self.active_template][key] = {
                    row[0]: int(row[1]) for row in rows
                }
            elif key == "fixed_columns":
                self.rules[self.active_template][key] = {
                    int(row[0]): row[1] for row in rows
                }
            else:
                self.rules[self.active_template][key] = [
                    {
                        "match_df_col": row[0], "match_type": row[1],
                        "match_value": row[2], "target_col": int(row[3]),
                        "fill_value": row[4],
                    }
                    for row in rows
                ]
            dialog.destroy()

        ttk.Button(buttons, text="添加或更新", command=upsert).pack(side=tk.LEFT, padx=3)
        ttk.Button(buttons, text="删除选中", command=remove).pack(side=tk.LEFT, padx=3)
        ttk.Button(buttons, text="保存", command=save).pack(side=tk.RIGHT, padx=3)
        dialog.wait_window()

    def _processor(self):
        if getattr(self, "source_provider", None):
            self.refresh_product_source()
        if self.df_source is None or self.df_source.empty:
            raise ValueError("请先加载产品特性表")
        self._store_rule_form()
        self.sync_dictionaries()
        return DataProcessor(
            self.df_source, self.freq_df, self.item_trans, self.tool_ship, self.tool_proc
        )

    def preview_report(self):
        try:
            report = self.active_rule
            processor = self._processor()
            processor.validate_drawings(self.rules[report])
            frame = processor.build(report, self.rules[report])
            self._show_frame(self.preview_tree, frame)
            self.notebook.select(self.tabs["数据预览"])
            self.status.set(f"{report}: 预览 {min(len(frame), 300)} 行")
        except Exception as exc:
            messagebox.showerror("预览失败", str(exc))

    def generate(self):
        if getattr(self, "_generating", False):
            messagebox.showinfo("正在生成", "报表仍在生成，请查看底部进度。")
            return
        try:
            processor = self._processor()
            self._store_template_form()
            template = self.template_path.get().strip()
            if not os.path.isfile(template):
                raise FileNotFoundError("请先选择有效的 Excel 模板")
            selected = [name for name in self.report_types if self.sheet_config[name]["header"] > 0]
            if not selected:
                raise ValueError("请为至少一个需要生成的报表设置表头行")
            targets = [self.sheet_config[name]["sheet_name"].casefold() for name in selected]
            if len(targets) != len(set(targets)):
                raise ValueError("不同报表不能写入同一 Sheet，请分别配置目标工作表")
            for name in selected:
                processor.validate_drawings(self.rules[name])
            output = filedialog.asksaveasfilename(
                title="生成报表", defaultextension=".xlsx", filetypes=[("Excel 工作簿", "*.xlsx")]
            )
            if not output:
                return
            if os.path.normcase(os.path.abspath(output)) == os.path.normcase(os.path.abspath(template)):
                raise ValueError("输出文件不能与模板文件相同")
            source = self.source_path.get().strip()
            if source and os.path.normcase(os.path.abspath(output)) == os.path.normcase(os.path.abspath(source)):
                raise ValueError("输出文件不能覆盖数据源文件")
            sheet_data = [(name, processor.build(name, self.rules[name])) for name in selected]
            configs = {
                name: (item["sheet_name"], item["header"], item["footer"] or None)
                for name, item in self.sheet_config.items()
            }
            self.status.set("正在生成...")
            self.root.update_idletasks()
            report_header = getattr(self, "_source_header", {})
            report_history = getattr(self, "_source_history", [])
            if source.lower().endswith((".xlsx", ".xlsm")):
                workbook = excel_com.load_workbook(source, read_only=True, data_only=True)
                try:
                    if "报表表头" in workbook.sheetnames:
                        report_header = {row[0]: row[1] or "" for row in
                                         workbook["报表表头"].iter_rows(min_col=1, max_col=2, values_only=True)
                                         if row[0]}
                    if "修改历史" in workbook.sheetnames:
                        rows = workbook["修改历史"].iter_rows(values_only=True)
                        fields = next(rows, ())
                        report_history = [dict(zip(fields, row)) for row in rows]
                finally:
                    workbook.close()
            if not report_history and report_header:
                report_history = [report_header]
            self._start_generation(
                template, output, sheet_data, configs,
                {name: self.rules[name].get("column_mapping", {}) for name in selected},
                {name: self.rules[name].get("fixed_columns", {}) for name in selected},
                {name: self.rules[name].get("conditional_rules", []) for name in selected},
                report_header=report_header,
                report_metadata={name: {field: self.rules[name].get(key, "") for field, key in (
                    ("报表版本", "report_version"), ("报表修订日期", "report_date"),
                    ("报表修订人", "report_author"), ("报表修订原因", "report_reason"))}
                    for name in selected},
                report_history=report_history,
                history_layouts={name: {"start": self.sheet_config[name].get("history_start", ""),
                                       "sheet": self.sheet_config[name].get("history_sheet", "")}
                                 for name in selected},
                report_header_cells={name: self.sheet_config[name].get("header_cells", {})
                                     for name in selected},
            )
        except Exception as exc:
            self.status.set("生成失败")
            messagebox.showerror("生成失败", str(exc))

    def _start_generation(self, template, output, *args, **kwargs):
        events = queue.Queue()
        # Snapshot settings before the UI becomes available for further edits.
        args, kwargs = copy.deepcopy(args), copy.deepcopy(kwargs)
        self._generating = True

        def worker():
            com = None
            try:
                if not template.lower().endswith(".xlsx"):
                    import pythoncom
                    pythoncom.CoInitialize()
                    com = pythoncom
                save_workbook_from_template(template, output, *args, **kwargs,
                                            progress=lambda message: events.put(("progress", message)))
                events.put(("success", output))
            except Exception as exc:
                traceback.print_exc()
                events.put(("error", str(exc)))
            finally:
                if com is not None:
                    com.CoUninitialize()

        def poll():
            try:
                while True:
                    kind, value = events.get_nowait()
                    if kind == "progress":
                        self.status.set(value)
                    else:
                        self._generating = False
                        if kind == "success":
                            self.status.set("生成成功")
                            messagebox.showinfo("完成", f"报表已保存至\n{value}")
                        else:
                            self.status.set("生成失败")
                            messagebox.showerror("生成失败", value)
                        return
            except queue.Empty:
                pass
            try:
                if self.root.winfo_exists():
                    self.root.after(100, poll)
            except tk.TclError:
                pass

        threading.Thread(target=worker, daemon=True, name="report-export").start()
        self.root.after(100, poll)

    def save_config(self, silent=False):
        try:
            self._store_rule_form()
            self._store_template_form()
            self.sync_dictionaries()
            self._store_profile()
            self.template_profiles = {name: self._own_template_profile(name, profile)
                                      for name, profile in self.template_profiles.items()}
            config = {
                "rules": self.rules,
                "template_profiles": self.template_profiles,
                "active_template_profile": self.active_template_profile,
                "templates": {"path": self.template_path.get()},
                "sheet_config": self.sheet_config,
                "item_trans": self.item_trans,
                "tool_ship": self.tool_ship,
                "tool_proc": self.tool_proc,
                "freq": self.freq_df.to_dict("records"),
                "template_catalog": getattr(self, "_unmigrated_catalog", []),
            }
            ConfigStore(self.config_file).save(config)
            self.status.set("配置已保存")
            return True
        except (OSError, ValueError, TypeError) as exc:
            if not silent:
                messagebox.showerror("保存配置失败", str(exc))
            return False

    def choose_config(self):
        path = filedialog.askopenfilename(filetypes=[("JSON 配置", "*.json")])
        if path:
            self.load_config(path)

    def load_config(self, path=None, silent=False, config_value=None):
        path = path or self.config_file
        if config_value is None and not os.path.isfile(path):
            return
        try:
            config = config_value if config_value is not None else ConfigStore(path).load()
            if not isinstance(config, dict):
                raise ValueError("配置文件格式错误")
            saved_rules = config.get("rules", {})
            if saved_rules:
                self.rules = {name: {**copy.deepcopy(DEFAULT_RULES.get(
                    rule.get("base_type", name), DEFAULT_RULES[REPORT_TYPES[0]])),
                    "base_type": rule.get("base_type", name), **rule}
                    for name, rule in saved_rules.items() if isinstance(rule, dict)}
                if not self.rules:
                    raise ValueError("配置至少需要一个报表")
            self.active_rule = self.report_types[0]
            self.active_template = self.active_rule
            self.sheet_config = {name: {"sheet_name": name, "header": 0, "footer": 0}
                                 for name in self.report_types}
            for name, item in config.get("sheet_config", {}).items():
                if name in self.sheet_config and isinstance(item, dict):
                    self.sheet_config[name].update({
                        "sheet_name": str(item.get("sheet_name", name)),
                        "header": int(item.get("header", 0)),
                        "footer": int(item.get("footer", 0)),
                        "history_sheet": item.get("history_sheet", ""),
                        "history_start": item.get("history_start", ""),
                        "header_cells": item.get("header_cells", {}),
                    })
            self.template_path.set(config.get("templates", {}).get("path", ""))
            legacy_items = [item for item in config.get("template_catalog", []) if isinstance(item, dict)]
            self._unmigrated_catalog = legacy_items
            if legacy_items:
                try:
                    self.template_library.migrate_legacy(path, legacy_items)
                    self._unmigrated_catalog = []
                except (OSError, ValueError) as exc:
                    messagebox.showwarning("旧档案未能全部迁移", f"产品配置仍可使用，请修复旧模板路径后重新导入。\n{exc}")
            self.template_catalog = self.template_library.list_items()
            profiles = config.get("template_profiles") or {"默认模板": {
                "path": self.template_path.get(), "sheet_config": self.sheet_config}}
            for profile in profiles.values():
                for name in self.report_types:
                    profile.setdefault("sheet_config", {}).setdefault(name, {
                        "sheet_name": name, "header": 0, "footer": 0})
            self.template_profiles = profiles
            self.active_template_profile = config.get("active_template_profile", "")
            if self.active_template_profile not in profiles:
                self.active_template_profile = next(iter(profiles))
            profile = profiles[self.active_template_profile]
            self.sheet_config = profile["sheet_config"]
            self.template_path.set(profile.get("path", ""))
            self.profile_selector["values"] = list(profiles)
            self.profile_var.set(self.active_template_profile)
            self.rule_selector["values"] = self.report_types
            self.template_selector["values"] = self.report_types
            self.rule_report.set(self.active_rule)
            self.template_report.set(self.active_template)
            for key in ("item_trans", "tool_ship", "tool_proc"):
                value = config.get(key)
                if isinstance(value, dict):
                    setattr(self, key, value)
            if isinstance(config.get("freq"), list):
                self.freq_df = clean_frame(pd.DataFrame(config["freq"], columns=self.dict_columns["freq"]))
            self._load_rule_form()
            self._load_template_form()
            self.refresh_dictionaries()
            self.config_file = path
            self.status.set("配置已加载")
        except (OSError, ValueError, TypeError, KeyError) as exc:
            if not silent:
                messagebox.showerror("加载配置失败", str(exc))

    def on_close(self):
        try:
            if not self.save_config(silent=True):
                if not messagebox.askyesno("关闭", "配置未能保存。放弃本次配置修改并关闭？"):
                    return
        except Exception as exc:
            if not messagebox.askyesno("关闭", f"配置保存失败：{exc}\n仍然关闭？"):
                return
        self.df_source = None
        self.root.destroy()


def run(initial_source=None):
    root = tk.Tk()
    ReportGeneratorApp(root, initial_source=initial_source)
    root.mainloop()


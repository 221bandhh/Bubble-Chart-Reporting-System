"""Shared template catalog and managed copies of uploaded workbook assets."""

import copy
import os
import re
import shutil
import uuid
from pathlib import Path

from report_system.data.config_store import ConfigStore


class TemplateLibrary:
    def __init__(self, workspace):
        self.root = Path(workspace).resolve() / "template_library"
        self.store = ConfigStore(self.root / "catalog.json")
        self.migrate_readable_folders()

    @staticmethod
    def folder_name(item):
        # Leave room for workbook names within Windows' path length limits.
        name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', item['name']).strip(' .')[:48].rstrip(' .')
        name = name or '模板'
        return f"{name}_{item['id'][:8]}"

    def migrate_readable_folders(self):
        """Rename old ID directories and update saved references together."""
        data = self.store.load()
        if not data:
            return
        moves = []
        for item in data.get('items', []):
            item_id = item.get('id', '')
            if not re.fullmatch(r'[0-9a-f]{32}', item_id):
                continue
            old = self.root / 'files' / item_id
            new = old.with_name(self.folder_name(item))
            if old.is_dir():
                if new.exists():
                    raise FileExistsError(f'模板目录已存在：{new}')
                moves.append((old, new))
        if not moves:
            return

        def rewrite(value):
            if isinstance(value, dict):
                return {key: rewrite(part) for key, part in value.items()}
            if isinstance(value, list):
                return [rewrite(part) for part in value]
            if isinstance(value, str):
                for old, new in moves:
                    for before, after in ((str(old), str(new)), (old.as_posix(), new.as_posix()),
                                          (f'library://files/{old.name}', f'library://files/{new.name}')):
                        if value == before or value.startswith(before + '/') or value.startswith(before + '\\'):
                            value = after + value[len(before):]
                return value
            return value

        paths = {self.store.path, *self.root.rglob('*.json'),
                 *self.root.parent.rglob('report_generator_config.json')}
        updates = []
        for path in paths:
            original = ConfigStore(path).load()
            updated = rewrite(original)
            if original != updated:
                target = Path(rewrite(str(path)))
                updates.append((path, target, original, updated))
        renamed, saved = [], []
        try:
            for old, new in moves:
                # Both resolved targets must remain in this library's files directory.
                if old.resolve().parent != (self.root / 'files').resolve() or new.resolve().parent != old.resolve().parent:
                    raise ValueError('非法模板目录')
                old.rename(new)
                renamed.append((old, new))
            for old_path, target, original, updated in updates:
                saved.append((old_path, target, original))
                ConfigStore(target).save(updated)
        except Exception:
            for old_path, target, original in reversed(saved):
                ConfigStore(target).save(original)
            for old, new in reversed(renamed):
                new.rename(old)
            raise

    def _data(self):
        data = self.store.load() or {"version": 1, "items": [], "migrated_sources": []}
        return self._map_paths(data, encode=False)

    def _map_paths(self, value, encode):
        if isinstance(value, list):
            return [self._map_paths(item, encode) for item in value]
        if not isinstance(value, dict):
            return value
        result = {}
        for key, item in value.items():
            if key == "path" and isinstance(item, str) and item:
                if not encode and item.startswith("library://"):
                    target = (self.root / item[len("library://"):]).resolve()
                    if not target.is_relative_to(self.root):
                        raise ValueError("非法模板档案路径")
                    item = str(target)
                elif encode and Path(item).is_absolute() and Path(item).is_relative_to(self.root):
                    item = "library://" + Path(item).relative_to(self.root).as_posix()
                result[key] = item
            else:
                result[key] = self._map_paths(item, encode)
        return result

    def _save_data(self, data):
        self.store.save(self._map_paths(data, encode=True))

    def list_items(self):
        return copy.deepcopy(self._data().get("items", []))

    def add(self, item, base_dir=None):
        item = copy.deepcopy(item)
        if not item.get("name", "").strip():
            raise ValueError("模板名称不能为空")
        base = Path(base_dir or os.getcwd())
        config = item.get("config")
        paths = []
        if config is not None:
            config.pop("template_catalog", None)
            paths.extend(profile for profile in config.get("template_profiles", {}).values())
            paths.append(config.setdefault("templates", {}))
        else:
            paths.append(item)
        sources = {}
        for entry in paths:
            value = entry.get("path", "")
            if not value:
                continue
            source = Path(value)
            source = (base / source).resolve() if not source.is_absolute() else source.resolve()
            if source.suffix.lower() not in (".xlsx", ".xlsm", ".xls"):
                raise ValueError(f"请选择 Excel 模板文件：{source}")
            if not source.is_file():
                raise FileNotFoundError(f"模板文件不存在：{source}")
            sources[str(source)] = source
        if not sources:
            raise ValueError("请先选择 Excel 模板文件，再上传档案库")
        item["id"] = uuid.uuid4().hex
        folder = self.root / "files" / self.folder_name(item)
        folder.mkdir(parents=True, exist_ok=True)
        try:
            copies = {}
            for index, (key, source) in enumerate(sources.items(), 1):
                target = folder / f"{index}_{source.name}"
                shutil.copy2(source, target)
                copies[key] = str(target)
            for entry in paths:
                if entry.get("path"):
                    source = Path(entry["path"])
                    source = (base / source).resolve() if not source.is_absolute() else source.resolve()
                    entry["path"] = copies[str(source)]
            if config is not None:
                path = folder / "report_generator_config.json"
                ConfigStore(path).save(config)
                item["path"] = str(path)
            data = self._data()
            data.setdefault("items", []).append(item)
            self._save_data(data)
        except Exception:
            # Only this newly created upload directory is removed on failure.
            shutil.rmtree(folder)
            raise
        return copy.deepcopy(item)

    def update_metadata(self, item_id, metadata):
        data = self._data()
        item = next((item for item in data.get("items", []) if item["id"] == item_id), None)
        if item is None:
            raise ValueError("模板档案已被删除，请重新打开档案库")
        for key in ("name", "process", "material", "requirement"):
            if key in metadata:
                item[key] = metadata[key]
        if not item.get("name", "").strip():
            raise ValueError("模板名称不能为空")
        self._save_data(data)

    def delete(self, item_id):
        data = self._data()
        data["items"] = [item for item in data.get("items", []) if item["id"] != item_id]
        self._save_data(data)
        # Keep assets so products already using this template continue to work.

    def migrate_legacy(self, source, items):
        key = str(Path(source).resolve())
        if key in self._data().get("migrated_sources", []):
            return
        for item in items:
            legacy_key = str(item.get("path", "")) + "|" + str(item.get("name", ""))
            if any(entry.get("legacy_source") == key and entry.get("legacy_key") == legacy_key
                   for entry in self.list_items()):
                continue
            self.add({**item, "legacy_source": key, "legacy_key": legacy_key}, Path(source).parent)
        data = self._data()
        data.setdefault("migrated_sources", []).append(key)
        self._save_data(data)

"""Product-scoped storage with migration from the legacy project.json."""

from __future__ import annotations

from datetime import date
import json
import os
import re
import shutil
import uuid
from pathlib import Path

from core.bubble_engine import normalize_bubble, BubbleEngine


class ProductRepository:
    def __init__(self, workspace):
        self.workspace = Path(workspace).resolve()
        self.products_dir = self.workspace / "products"
        self.index_file = self.products_dir / "index.json"
        self.products_dir.mkdir(parents=True, exist_ok=True)
        self._migrate_product_folders()
        self._migrate_legacy_project()

    def product_dir(self, product):
        entry = next((item for item in self.list_products() if item["id"] == product["id"]), product)
        folder = (self.products_dir / entry.get("folder", entry["id"])).resolve()
        if folder.parent != self.products_dir.resolve():
            raise ValueError("非法产品路径")
        return folder

    def _available_folder(self, name):
        base = self._safe_name(name)
        candidate = base
        number = 2
        while (self.products_dir / candidate).exists():
            candidate = f"{base} ({number})"
            number += 1
        return candidate

    def _migrate_product_folders(self):
        entries = self.list_products()
        for entry in entries:
            if entry.get("folder"):
                continue
            source = self.product_dir(entry)
            target_name = self._available_folder(entry["name"])
            target = (self.products_dir / target_name).resolve()
            if target.parent != self.products_dir.resolve():
                raise ValueError("非法产品路径")
            if source.is_dir():
                source.rename(target)
            entry["folder"] = target_name
            # Commit each move so an interrupted migration can resume safely.
            self._save_index(entries)

    @staticmethod
    def _safe_name(name):
        cleaned = re.sub(r'[<>:"/\\|?*]+', "_", str(name)).strip(" .")
        if cleaned.split(".")[0].upper() in {"CON", "PRN", "AUX", "NUL", *[f"COM{i}" for i in range(1, 10)], *[f"LPT{i}" for i in range(1, 10)]}:
            cleaned = "_" + cleaned
        return cleaned or "未命名产品"

    def _read_json(self, path, default):
        try:
            with open(path, encoding="utf-8-sig") as stream:
                return json.load(stream)
        except FileNotFoundError:
            return default

    def _write_json(self, path, value):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(path.suffix + ".tmp")
        with open(temporary, "w", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2)
        os.replace(temporary, path)

    def list_products(self):
        data = self._read_json(self.index_file, {"products": []})
        products = data.get("products", []) if isinstance(data, dict) else []
        return sorted(products, key=lambda item: (str(item.get("name", "")).casefold(), item["id"]))

    def _save_index(self, products):
        self._write_json(self.index_file, {"version": 1, "products": products})

    def create(self, name):
        product_id = uuid.uuid4().hex[:12]
        folder_name = self._available_folder(name)
        product = {
            "version": 1, "id": product_id, "name": self._safe_name(name), "folder": folder_name,
            "active_drawing": 0, "bubble_radius": 18, "font_size": 14,
            "drawings": [], "report_rules": {},
        }
        folder = self.products_dir / folder_name
        (folder / "drawings").mkdir(parents=True)
        self._write_json(folder / "product.json", product)
        products = self.list_products()
        products.append({"id": product_id, "name": product["name"], "folder": folder_name})
        self._save_index(products)
        return product

    def load(self, product_id):
        path = self.product_dir({"id": product_id}) / "product.json"
        product = self._read_json(path, None)
        if not isinstance(product, dict):
            raise FileNotFoundError(f"产品配置不存在或内容无效：{path}")
        product = self._normalize_product(product, path.parent)
        product["id"] = product_id
        product.setdefault("name", path.parent.name)
        product["folder"] = path.parent.name
        for drawing in product.get("drawings", []):
            drawing["bubbles"] = [normalize_bubble(item) for item in drawing.get("bubbles", [])]
        return product

    def save(self, product):
        product_id = product["id"]
        path = self.product_dir(product) / "product.json"
        original = self._read_json(path, None)
        if isinstance(original, dict) and self._single_drawing(original) is not None and not original.get("drawings"):
            backup = path.with_name("product.legacy.bak.json")
            if not backup.exists():
                shutil.copy2(path, backup)
        self._write_json(path, product)
        products = self.list_products()
        changed = False
        for item in products:
            if item["id"] == product_id and item.get("name") != product.get("name"):
                item["name"] = product["name"]
                changed = True
        if changed:
            self._save_index(products)

    def add_drawing(self, product, source_path):
        source = Path(source_path).resolve()
        if not source.is_file():
            raise FileNotFoundError(source)
        drawing_id = uuid.uuid4().hex[:12]
        suffix = source.suffix.lower() or ".png"
        relative = Path("drawings") / f"{drawing_id}{suffix}"
        target = self.product_dir(product) / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        drawing = {"id": drawing_id, "name": self._safe_name(source.stem),
                   "path": relative.as_posix(), "bubbles": []}
        product.setdefault("drawings", []).append(drawing)
        self.save(product)
        return drawing

    @staticmethod
    def _single_drawing(product):
        descriptor = product.get("drawing")
        descriptor = descriptor if isinstance(descriptor, dict) else {}
        for data in (descriptor, product):
            for key in ("image_path", "drawing_path", "image_file", "path", "image", "drawing"):
                value = data.get(key)
                if isinstance(value, str) and value.strip():
                    return {"id": "legacy-drawing", "name": product.get("drawing_name") or descriptor.get("name") or Path(value).stem,
                            "path": value, "bubbles": data.get("bubbles", product.get("bubbles", []))}
        return None

    def _resolve_drawing_source(self, value, base):
        path = Path(value)
        candidates = ([path] if path.is_absolute() else [base / path, self.workspace / path])
        # A product copied from another computer may retain an obsolete absolute path.
        candidates.extend([base / path.name, base / "drawings" / path.name])
        return next((candidate.resolve() for candidate in candidates if candidate.is_file()), None)

    def _normalize_product(self, raw, base):
        import copy
        product = copy.deepcopy(raw)
        drawings = product.get("drawings")
        if not drawings:
            single = self._single_drawing(product)
            if single is not None:
                drawings = [single]
            elif product.get("bubbles"):
                raise FileNotFoundError("单图纸文件包含气泡但缺少图片路径，请使用导入产品并选择对应图纸")
            else:
                drawings = []
        if not isinstance(drawings, list):
            raise ValueError("图纸数据必须是列表")
        for index, drawing in enumerate(drawings):
            if not isinstance(drawing, dict) or not drawing.get("path"):
                raise ValueError("图纸缺少有效路径")
            drawing.setdefault("id", f"drawing-{index + 1}")
            drawing.setdefault("name", Path(drawing["path"]).stem)
            bubbles = drawing.get("bubbles", [])
            if not isinstance(bubbles, list) or any(not isinstance(bubble, dict) for bubble in bubbles):
                raise ValueError("气泡数据必须是对象列表")
            drawing["bubbles"] = BubbleEngine(bubbles).bubbles
            # Keep local relative paths; repair old workspace-relative/absolute paths when found.
            source = self._resolve_drawing_source(drawing["path"], base)
            if source is not None:
                drawing["path"] = source.relative_to(base).as_posix() if source.is_relative_to(base) else str(source)
        product["drawings"] = drawings
        if len({drawing["id"] for drawing in drawings}) != len(drawings):
            raise ValueError("图纸 ID 重复，无法安全导入")
        product.setdefault("name", product.get("product_name", base.name))
        product.setdefault("bubble_radius", 18)
        product.setdefault("font_size", 14)
        product["active_drawing"] = max(0, min(int(product.get("active_drawing", 0)), len(drawings) - 1))
        return product

    def import_product_folders(self, folder):
        """Import product/project JSON files recursively; isolate individual failures."""
        root = Path(folder).resolve()
        if not root.is_dir():
            raise ValueError("请选择有效的旧产品文件夹")
        candidates = []
        for directory, subdirs, filenames in os.walk(root):
            base = Path(directory).resolve()
            subdirs[:] = sorted(name for name in subdirs
                                if name not in {'.git', '.cache', '__pycache__', 'drawings'}
                                and (base / name).resolve() != self.products_dir.resolve())
            names = {name.casefold(): name for name in filenames}
            # Prefer current product data over a stale project in the same folder.
            for name in ('product.json', 'project.json'):
                if name in names:
                    candidates.append(base / names[name])
                    break
        imported, errors = [], []
        for path in sorted(candidates):
            try:
                imported.append(self.import_product(path))
            except (OSError, ValueError, TypeError, KeyError) as exc:
                errors.append(f"{path.relative_to(root)}: {exc}")
        return imported, errors

    def import_product(self, config_path, image_path=None, name=None, target_product=None, drawing_name=None):
        """Import legacy single-drawing or current product JSON without altering the source."""
        import copy
        path = Path(config_path).resolve()
        raw = self._read_json(path, None)
        if not isinstance(raw, dict):
            raise ValueError("请选择有效的产品 JSON 文件")
        if image_path is not None:
            if raw.get("drawings") and len(raw["drawings"]) != 1:
                raise ValueError("多图纸产品不能用单张图片替换全部图纸")
            raw = copy.deepcopy(raw)
            if raw.get("drawings"):
                raw["drawings"][0]["path"] = str(Path(image_path).resolve())
            else:
                single = self._single_drawing(raw) or {"bubbles": raw.get("bubbles", [])}
                single["path"] = str(Path(image_path).resolve())
                raw["drawings"] = [single]
        product = self._normalize_product(raw, path.parent)
        if not product["drawings"]:
            raise FileNotFoundError("文件中没有图纸，请选择对应图片后重试")
        sources = []
        for drawing in product["drawings"]:
            source = self._resolve_drawing_source(drawing["path"], path.parent)
            if source is None:
                raise FileNotFoundError(f"找不到图纸：{drawing['path']}，请将图纸与 JSON 一起复制，或重新选择对应图片")
            sources.append(source)
        if target_product is not None:
            added, copied = [], []
            try:
                for index, (drawing, source) in enumerate(zip(product["drawings"], sources)):
                    drawing["id"] = uuid.uuid4().hex[:12]
                    if drawing_name:
                        drawing["name"] = drawing_name if len(sources) == 1 else f"{drawing_name}-{index + 1}"
                    relative = Path("drawings") / f"{drawing['id']}{source.suffix.lower()}"
                    destination = self.product_dir(target_product) / relative
                    copied.append(destination)
                    shutil.copy2(source, destination)
                    drawing["path"] = relative.as_posix()
                    added.append(drawing)
                target_product.setdefault("drawings", []).extend(added)
                self.save(target_product)
            except Exception:
                target_product["drawings"] = [d for d in target_product.get("drawings", []) if d not in added]
                for destination in copied:
                    destination.unlink(missing_ok=True)
                raise
            return target_product
        product["id"] = uuid.uuid4().hex[:12]
        product["name"] = self._safe_name(name if name is not None else product["name"])
        product["folder"] = self._available_folder(product["name"])
        folder = self.products_dir / product["folder"]
        try:
            (folder / "drawings").mkdir(parents=True)
            for drawing, source in zip(product["drawings"], sources):
                drawing["id"] = uuid.uuid4().hex[:12]
                relative = Path("drawings") / f"{drawing['id']}{source.suffix.lower()}"
                shutil.copy2(source, folder / relative)
                drawing["path"] = relative.as_posix()
            self._write_json(folder / "product.json", product)
            shutil.copy2(path, folder / "imported_product.original.json")
            self._save_index([*self.list_products(), {key: product[key] for key in ("id", "name", "folder")}])
        except Exception:
            if folder.resolve().parent == self.products_dir.resolve() and folder.exists():
                shutil.rmtree(folder)
            raise
        return product

    def drawing_path(self, product, drawing):
        return self.product_dir(product) / drawing["path"]

    def thumbnail_path(self, product, drawing):
        return self.product_dir(product) / ".cache" / f"{drawing['id']}.png"

    def delete(self, product_id):
        folder = self.product_dir({"id": product_id})
        if folder.parent != self.products_dir.resolve():
            raise ValueError("非法产品路径")
        if folder.exists():
            shutil.rmtree(folder)
        self._save_index([item for item in self.list_products() if item["id"] != product_id])

    def export_path(self, product):
        return self.product_dir(product) / f"bubble_export（{date.today():%Y-%m-%d}）.xlsx"

    def _migrate_legacy_project(self):
        if self.list_products():
            return
        legacy = self.workspace / "project.json"
        if not legacy.is_file():
            return
        data = self._read_json(legacy, {})
        drawings = data.get("drawings", []) if isinstance(data, dict) else []
        if not drawings:
            return
        product = self.create("历史项目")
        for item in drawings:
            source = Path(item.get("path", ""))
            if not source.is_absolute():
                source = self.workspace / source
            if not source.is_file():
                continue
            drawing = self.add_drawing(product, source)
            drawing["name"] = item.get("name") or drawing["name"]
            drawing["bubbles"] = [normalize_bubble(bubble) for bubble in item.get("bubbles", [])]
        product["active_drawing"] = min(int(data.get("active_drawing", 0)),
                                        max(0, len(product["drawings"]) - 1))
        product["bubble_radius"] = int(data.get("bubble_radius", 18))
        product["font_size"] = int(data.get("font_size", 14))
        self.save(product)


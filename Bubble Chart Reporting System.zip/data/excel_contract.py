"""Stable Excel contract shared by bubble and report applications."""

from __future__ import annotations

from pathlib import Path

from core import excel_com
from core.product_info import REPORT_HEADER_FIELDS, report_header, revision_history

from core.bubble_engine import sequence_label


CONTRACT_SHEET = "气泡数据"
CONTRACT_VERSION = "1.0"
CONTRACT_COLUMNS = (
    "产品", "图纸", "序号", "检验项目", "检验要求", "测量器具",
    "内控要求", "重要度", "现场定制量具", "备注", "X", "Y",
)

FIELD_MAP = {
    "seq": "序号", "item": "检验项目", "req": "检验要求", "tool": "测量器具",
    "internal": "内控要求", "importance": "重要度", "measure_method": "现场定制量具",
    "remark": "备注", "x": "X", "y": "Y",
}


def product_rows(product):
    """Build contract rows without starting WPS."""
    for drawing in product.get("drawings", []):
        for bubble in sorted(drawing.get("bubbles", []), key=lambda item: float(item["seq"])):
            values = {FIELD_MAP[key]: (sequence_label(value) if key == "seq" else value)
                      for key, value in bubble.items() if key in FIELD_MAP}
            yield [product.get("name", ""), drawing.get("name", "")] + [
                values.get(column, "") for column in CONTRACT_COLUMNS[2:]]


def export_product(product, output_path):
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    workbook = excel_com.Workbook()
    try:
        return _write_product(workbook, product, output)
    finally:
        workbook.close()


def _write_product(workbook, product, output):
    sheet = workbook.active
    sheet.title = CONTRACT_SHEET
    sheet.append_rows([CONTRACT_COLUMNS, *product_rows(product)])
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = sheet.dimensions
    meta = workbook.create_sheet("契约说明")
    meta.append(["contract", "bubble_export"])
    meta.append(["version", CONTRACT_VERSION])
    meta.append(["product_id", product.get("id", "")])
    header = workbook.create_sheet("报表表头")
    header.append_rows(report_header(product).items())
    history_sheet = workbook.create_sheet("修改历史")
    history_sheet.append(list(REPORT_HEADER_FIELDS) + ["记录时间"])
    history_sheet.append_rows([record.get(field, "") for field in (*REPORT_HEADER_FIELDS, "记录时间")]
                              for record in revision_history(product))
    temporary = output.with_suffix(output.suffix + ".tmp")
    workbook.save(temporary)
    workbook.close()
    temporary.replace(output)
    return output


def is_contract_workbook(path):
    workbook = excel_com.load_workbook(path, read_only=True, data_only=True)
    try:
        return CONTRACT_SHEET in workbook.sheetnames
    finally:
        workbook.close()


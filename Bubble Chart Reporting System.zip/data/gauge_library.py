"""Workspace-wide history of inspection gauges."""

import json
import os
from pathlib import Path


class GaugeLibrary:
    FIELDS = ("name", "spec", "part_no")

    def __init__(self, workspace):
        self.path = Path(workspace).resolve() / "gauge_library.json"

    def list_items(self):
        try:
            with self.path.open(encoding="utf-8-sig") as stream:
                data = json.load(stream)
        except FileNotFoundError:
            return []
        items = data.get("items", []) if isinstance(data, dict) else []
        return [self._normalize(item) for item in items if isinstance(item, dict)]

    @classmethod
    def _normalize(cls, item):
        return {key: str(item.get(key, "")).strip() for key in cls.FIELDS}

    def remember(self, items):
        known = {tuple(item[key].casefold() for key in self.FIELDS): item
                 for item in self.list_items()}
        for value in items:
            item = self._normalize(value)
            if item["name"]:
                known[tuple(item[key].casefold() for key in self.FIELDS)] = item
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(".json.tmp")
        with temporary.open("w", encoding="utf-8") as stream:
            json.dump({"version": 1, "items": list(known.values())}, stream,
                      ensure_ascii=False, indent=2)
        os.replace(temporary, self.path)

    def search(self, query=''):
        terms = str(query).casefold().split()
        return [item for item in self.list_items()
                if all(term in ' '.join(item.values()).casefold() for term in terms)]

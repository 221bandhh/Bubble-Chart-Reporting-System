"""Bubble CRUD rules independent from Tkinter and image rendering."""

from __future__ import annotations

import copy
import math
from decimal import Decimal, InvalidOperation


BUBBLE_FIELDS = (
    "seq", "item", "req", "tool", "internal", "importance",
    "measure_method", "remark", "x", "y",
)


class BubbleError(ValueError):
    """Raised when a bubble mutation violates the data contract."""


def sequence_label(value) -> str:
    try:
        number = Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise BubbleError("序号必须是数字") from exc
    if not number.is_finite() or number < 0:
        raise BubbleError("序号必须是非负有限数字")
    normalized = format(number.normalize(), "f")
    return normalized.rstrip("0").rstrip(".") if "." in normalized else normalized


def sequence_number(value):
    label = sequence_label(value)
    number = Decimal(label)
    return int(number) if number == number.to_integral() else float(number)


def normalize_bubble(raw: dict) -> dict:
    bubble = {field: "" for field in BUBBLE_FIELDS}
    bubble.update({key: raw.get(key, "") for key in BUBBLE_FIELDS})
    bubble["seq"] = sequence_number(bubble["seq"])
    bubble["gauges"] = [dict(item) for item in raw.get("gauges", []) if isinstance(item, dict)]
    try:
        bubble["x"] = int(bubble["x"])
        bubble["y"] = int(bubble["y"])
    except (TypeError, ValueError) as exc:
        raise BubbleError("气泡坐标必须是整数") from exc
    return bubble


class BubbleEngine:
    """Owns bubble mutations and a bounded snapshot history."""

    def __init__(self, bubbles=None, history_limit=100):
        self.history_limit = max(1, int(history_limit))
        self._history: list[list[dict]] = []
        self.bubbles = [normalize_bubble(item) for item in (bubbles or [])]
        self._validate_unique()

    @staticmethod
    def root_sequence(seq):
        return int(Decimal(sequence_label(seq)))

    @staticmethod
    def _child_position(anchor, index, bounds=None):
        x = anchor['x'] + 24 * ((index - 1) % 3 + 1)
        y = anchor['y'] + 24 * ((index - 1) // 3 + 1)
        if bounds is not None:
            x = max(0, min(int(bounds[0]) - 1, x))
            y = max(0, min(int(bounds[1]) - 1, y))
        return x, y

    def _validate_unique(self):
        labels = [sequence_label(item["seq"]) for item in self.bubbles]
        if len(labels) != len(set(labels)):
            raise BubbleError("气泡序号存在冲突")

    def _remember(self):
        self._history.append(copy.deepcopy(self.bubbles))
        if len(self._history) > self.history_limit:
            del self._history[0]

    def sorted(self):
        return sorted(self.bubbles, key=lambda item: Decimal(sequence_label(item["seq"])))

    def visible_bubbles(self):
        groups = {}
        for bubble in self.sorted():
            groups.setdefault(self.root_sequence(bubble['seq']), bubble)
        return list(groups.values())

    def get(self, seq):
        label = sequence_label(seq)
        return next((item for item in self.bubbles if sequence_label(item["seq"]) == label), None)

    def copy_contents_from(self, source, bounds=None):
        source = BubbleEngine(source)
        changes = []
        additions = []
        for target in self.bubbles:
            origin = source.get(target['seq'])
            if origin is not None:
                values = {k: origin[k] for k in BUBBLE_FIELDS if k not in ('seq', 'x', 'y')}
                values['gauges'] = copy.deepcopy(origin.get('gauges', []))
                if any(target.get(k) != v for k, v in values.items()):
                    changes.append((target, values))
        for origin in source.sorted():
            if self.get(origin['seq']) is not None:
                continue
            root = self.root_sequence(origin['seq'])
            if origin['seq'] == root:
                continue
            anchor = next((item for item in self.sorted()
                           if self.root_sequence(item['seq']) == root), None)
            # A missing group uses the source position until the user moves it.
            added = copy.deepcopy(origin)
            if anchor is not None:
                index = sum(self.root_sequence(item['seq']) == root and item['seq'] != root
                            for item in [*self.bubbles, *additions]) + 1
                added['x'], added['y'] = self._child_position(anchor, index, bounds)
            additions.append(added)
        if changes or additions:
            self._remember()
            for target, values in changes:
                target.update(values)
            self.bubbles.extend(additions)
        return len(changes) + len(additions)

    def next_sequence(self) -> int:
        integers = [self.root_sequence(item['seq']) for item in self.bubbles]
        return max(integers, default=0) + 1

    def add(self, x, y, seq=None):
        number = self.next_sequence() if seq is None else sequence_number(seq)
        if self.get(number) is not None:
            raise BubbleError(f"序号 {sequence_label(number)} 已存在")
        self._remember()
        bubble = normalize_bubble({"seq": number, "x": int(x), "y": int(y)})
        self.bubbles.append(bubble)
        return bubble

    def add_child(self, parent_seq, x=None, y=None):
        parent = self.get(parent_seq)
        if parent is None:
            raise BubbleError("父序号不存在")
        root = int(Decimal(sequence_label(parent["seq"])))
        occupied = {sequence_label(item["seq"]) for item in self.bubbles}
        child = next((Decimal(root) + Decimal(index) / 10 for index in range(1, 10)
                      if sequence_label(Decimal(root) + Decimal(index) / 10) not in occupied), None)
        if child is None:
            raise BubbleError("每个父序号最多支持 9 个子序号")
        anchor = self.get(root) or parent
        position = self._child_position(anchor, int((child - root) * 10))
        return self.add(position[0] if x is None else x, position[1] if y is None else y, child)

    def update(self, seq, changes: dict):
        bubble = self.get(seq)
        if bubble is None:
            raise BubbleError("气泡不存在")
        updated = dict(bubble)
        updated.update(changes)
        updated = normalize_bubble(updated)
        conflict = self.get(updated["seq"])
        if conflict is not None and conflict is not bubble:
            raise BubbleError(f"序号 {sequence_label(updated['seq'])} 已存在")
        if updated == bubble:
            return bubble
        self._remember()
        old_x, old_y = bubble['x'], bubble['y']
        bubble.clear()
        bubble.update(updated)
        root = self.root_sequence(bubble['seq'])
        if bubble['seq'] == root and ('x' in changes or 'y' in changes):
            for sibling in self.bubbles:
                if sibling is not bubble and self.root_sequence(sibling['seq']) == root:
                    sibling['x'] += bubble['x'] - old_x
                    sibling['y'] += bubble['y'] - old_y
        return bubble

    def delete(self, seq):
        bubble = self.get(seq)
        if bubble is None:
            raise BubbleError("气泡不存在")
        self._remember()
        self.bubbles.remove(bubble)
        return bubble

    def hit_test(self, x, y, radius):
        return next((item for item in reversed(self.visible_bubbles())
                     if math.hypot(x - item["x"], y - item["y"]) <= radius + 3), None)

    def undo(self) -> bool:
        if not self._history:
            return False
        self.bubbles = self._history.pop()
        return True

    @property
    def history_size(self):
        return len(self._history)


﻿"""Excel workbook operations implemented exclusively with pywin32 COM."""
import os
import re
from types import SimpleNamespace


def coordinate_to_tuple(address):
    match = re.fullmatch(r'([A-Z]+)([1-9][0-9]*)', str(address).upper())
    if not match:
        raise ValueError('Invalid cell address')
    column = 0
    for char in match[1]:
        column = column * 26 + ord(char) - 64
    return int(match[2]), column


def get_column_letter(column):
    result = ''
    while column:
        column, digit = divmod(column - 1, 26)
        result = chr(65 + digit) + result
    return result


def Font(**kwargs):
    return SimpleNamespace(**kwargs)


def PatternFill(pattern=None, fgColor=None):
    return SimpleNamespace(fgColor=fgColor)


def _color(value):
    value = value[-6:]
    return int(value[0:2], 16) + (int(value[2:4], 16) << 8) + (int(value[4:6], 16) << 16)


class Cell:
    def __init__(self, raw):
        self.raw = raw

    @property
    def value(self):
        return self.raw.Value

    @value.setter
    def value(self, value):
        self.raw.Value = value

    @property
    def coordinate(self):
        return self.raw.Address(False, False)

    @property
    def column_letter(self):
        return get_column_letter(self.raw.Column)

    @property
    def font(self):
        return self.raw.Font

    @font.setter
    def font(self, style):
        for key, target in [('size', 'Size'), ('bold', 'Bold'), ('color', 'Color')]:
            if hasattr(style, key):
                value = getattr(style, key)
                setattr(self.raw.Font, target, _color(value) if key == 'color' else value)

    @property
    def fill(self):
        return self.raw.Interior

    @fill.setter
    def fill(self, style):
        self.raw.Interior.Color = _color(style.fgColor)


class Dimensions:
    def __init__(self, raw):
        self.raw = raw

    def __getitem__(self, column):
        raw = self.raw.Columns(column)
        class Dimension:
            @property
            def width(self):
                return raw.ColumnWidth
            @width.setter
            def width(self, value):
                raw.ColumnWidth = value
        return Dimension()


class Sheet:
    def __init__(self, raw):
        self.raw = raw
        self._append_row = 0
        self.column_dimensions = Dimensions(raw)
        self.auto_filter = SimpleNamespace(ref=None)

    @property
    def title(self):
        return self.raw.Name

    @title.setter
    def title(self, name):
        self.raw.Name = name

    @property
    def max_row(self):
        used = self.raw.UsedRange
        return used.Row + used.Rows.Count - 1

    @property
    def max_column(self):
        used = self.raw.UsedRange
        return used.Column + used.Columns.Count - 1

    @property
    def dimensions(self):
        return f'A1:{get_column_letter(self.max_column)}{self.max_row}'

    def cell(self, row, column, value=None):
        cell = Cell(self.raw.Cells(row, column))
        if value is not None:
            cell.value = value
        return cell

    def __getitem__(self, address):
        return Cell(self.raw.Range(address))

    def __setitem__(self, address, value):
        self.raw.Range(address).Value = value

    def append(self, values):
        self._append_row += 1
        values = list(values)
        if values:
            self.raw.Range(self.raw.Cells(self._append_row, 1), self.raw.Cells(self._append_row, len(values))).Value = (tuple(values),)

    def append_rows(self, rows):
        rows = [tuple(row) for row in rows]
        if not rows:
            return
        width = max(map(len, rows))
        if not width:
            return
        data = tuple(row + (None,) * (width - len(row)) for row in rows)
        start, end = self._append_row + 1, self._append_row + len(rows)
        self.raw.Range(f'A{start}:{get_column_letter(width)}{end}').Value = data
        self._append_row = end

    def iter_rows(self, min_row=1, max_row=None, min_col=1, max_col=None, values_only=False):
        bottom, right = max_row or self.max_row, max_col or self.max_column
        if bottom < min_row or right < min_col:
            return
        if values_only:
            data = self.raw.Range(self.raw.Cells(min_row, min_col), self.raw.Cells(bottom, right)).Value
            if bottom == min_row and right == min_col:
                data = ((data,),)
            yield from data
        else:
            for row in range(min_row, bottom + 1):
                yield tuple(self.cell(row, col) for col in range(min_col, right + 1))

    def merge_cells(self, address):
        self.raw.Range(address).Merge()

    @property
    def freeze_panes(self):
        return None

    @freeze_panes.setter
    def freeze_panes(self, address):
        self.raw.Activate()
        window = self.raw.Application.ActiveWindow
        row, column = coordinate_to_tuple(address)
        window.SplitRow, window.SplitColumn = row - 1, column - 1
        window.FreezePanes = True


class Workbook:
    def __init__(self, path=None, read_only=False):
        import pythoncom
        import win32com.client
        self._pythoncom = pythoncom
        pythoncom.CoInitialize()
        self.app = None
        self.raw = None
        self._sheets = {}
        self._remove = []
        self._closed = False
        try:
            for progid in ('KET.Application', 'ET.Application'):
                try:
                    self.app = win32com.client.DispatchEx(progid)
                    break
                except Exception:
                    continue
            if self.app is None:
                raise RuntimeError('请安装支持 COM 的 WPS 表格以及 pywin32')
            self.app.Visible = False
            self.app.DisplayAlerts = False
            self.app.ScreenUpdating = False
            for option, value in (("EnableEvents", False), ("AutomationSecurity", 3)):
                try:
                    setattr(self.app, option, value)
                except Exception:
                    pass
            self.raw = self.app.Workbooks.Open(os.path.abspath(path), UpdateLinks=0, ReadOnly=read_only) if path else self.app.Workbooks.Add()
        except Exception:
            self.close()
            raise

    @property
    def sheetnames(self):
        return [self.raw.Worksheets(i).Name for i in range(1, self.raw.Worksheets.Count + 1) if self.raw.Worksheets(i).Name not in self._remove]

    def __getitem__(self, name):
        if name not in self._sheets:
            self._sheets[name] = Sheet(self.raw.Worksheets(name))
        return self._sheets[name]

    @property
    def active(self):
        return self[self.raw.ActiveSheet.Name]

    def create_sheet(self, name):
        sheet = self.raw.Worksheets.Add(After=self.raw.Worksheets(self.raw.Worksheets.Count))
        sheet.Name = name
        return self[name]

    def remove(self, sheet):
        # Excel requires one visible sheet; defer removal until saving.
        self._remove.append(sheet.title)

    def save(self, path):
        for name in self._remove:
            self.raw.Worksheets(name).Delete()
        self._remove.clear()
        for sheet in self._sheets.values():
            if sheet.auto_filter.ref:
                sheet.raw.Range(sheet.auto_filter.ref).AutoFilter()
        self.raw.SaveAs(os.path.abspath(path), FileFormat=51)

    def close(self):
        if self._closed:
            return
        self._closed = True
        try:
            if self.raw is not None:
                self.raw.Close(SaveChanges=False)
        finally:
            try:
                if self.app is not None:
                    self.app.Quit()
            finally:
                self._sheets.clear()
                self.raw = self.app = None
                self._pythoncom.CoUninitialize()


def load_workbook(path, read_only=False, data_only=False):
    return Workbook(path, read_only=read_only)

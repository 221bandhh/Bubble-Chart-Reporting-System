@echo off
cd /d "%~dp0\..\.."
python -m report_system.main "%~dp0bubble_export.xlsx"
if errorlevel 1 pause

﻿"""Compatibility entry point for workbooks backed by win32 COM."""
from core.excel_com import Workbook as ComWorkbook


class Workbook(ComWorkbook):
    @property
    def Sheets(self):
        return self.raw.Sheets

    @property
    def Worksheets(self):
        return self.raw.Worksheets

    def SaveAs(self, Filename, FileFormat=51):
        self.raw.SaveAs(Filename, FileFormat=FileFormat)

    def Close(self, SaveChanges=False):
        self.close()

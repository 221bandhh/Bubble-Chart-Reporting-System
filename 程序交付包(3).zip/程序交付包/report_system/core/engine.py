# -*- coding: utf-8 -*-
"""
产品特性报表生成器。
支持六类报表、条件规则、频次匹配、翻译和多工作表模板。
依赖：pip install pandas pywin32
"""

import os
from contextlib import contextmanager
from typing import Dict, List, Optional, Tuple

from core import excel_com
import pandas as pd
from report_system.core.history_layout import write_history_block

try:
    import win32com.client
    HAS_WIN32COM = True
except ImportError:
    HAS_WIN32COM = False

# ======================== 路径与配置 ========================
def get_config_path() -> str:
    return os.path.join(os.getcwd(), "report_generator_config.json")

# ======================== WPS / Excel COM 封装 ========================
def get_excel_app(visible=False):
    if not HAS_WIN32COM:
        raise RuntimeError("请安装 pywin32: pip install pywin32")
    for progid in ["KET.Application", "ET.Application", "Excel.Application"]:
        app = None
        try:
            app = win32com.client.DispatchEx(progid)
            app.Visible = visible
            app.DisplayAlerts = False
            return app
        except Exception:
            if app is not None:
                try:
                    app.Quit()
                except Exception:
                    pass
            continue
    raise RuntimeError("未找到 WPS 或 Microsoft Excel")

@contextmanager
def excel_app(visible=False):
    import pythoncom
    pythoncom.CoInitialize()
    app = None
    try:
        app = get_excel_app(visible)
        yield app
    finally:
        try:
            if app:
                app.Quit()
        except Exception:
            pass
        pythoncom.CoUninitialize()


@contextmanager
def open_workbook(path):
    with excel_app() as app:
        workbook = app.Workbooks.Open(os.path.abspath(path))
        try:
            yield workbook
        finally:
            workbook.Close(SaveChanges=False)

def read_excel_via_com(filepath: str) -> pd.DataFrame:
    with open_workbook(filepath) as wb:
        ws = wb.ActiveSheet
        data = ws.UsedRange.Value
        if data is None:
            raise ValueError("工作表为空")
        if isinstance(data, (tuple, list)):
            rows = list(data) if data and isinstance(data[0], (tuple, list)) else [data]
        else:
            rows = [[data]]
        header = [str(c).strip() if c is not None else "" for c in rows[0]]
        data_rows = rows[1:] if len(rows) > 1 else []
        max_cols = len(header)
        norm_rows = []
        for r in data_rows:
            if r is None:
                r = []
            if not isinstance(r, (list, tuple)):
                r = [r]
            r = list(r)
            if len(r) < max_cols:
                r.extend([""] * (max_cols - len(r)))
            elif len(r) > max_cols:
                r = r[:max_cols]
            norm_rows.append(r)
        df = pd.DataFrame(norm_rows, columns=header)
    return clean_frame(df)


def read_source_excel(filepath: str) -> pd.DataFrame:
    """Read the bubble contract using win32 COM."""
    extension = os.path.splitext(filepath)[1].lower()
    if extension == ".xls":
        return read_excel_via_com(filepath)
    workbook = excel_com.load_workbook(filepath, read_only=True, data_only=True)
    try:
        sheet_name = "气泡数据" if "气泡数据" in workbook.sheetnames else workbook.sheetnames[0]
        rows = workbook[sheet_name].iter_rows(values_only=True)
        header = next(rows, ())
        if not header:
            return pd.DataFrame()
        columns = [str(value).strip() if value is not None else f"__empty_{index}"
                   for index, value in enumerate(header)]
        frame = pd.DataFrame.from_records(rows, columns=columns)
        return clean_frame(frame)
    finally:
        workbook.close()

def apply_rules_to_worksheet(ws, header_row, footer_row, df, col_map, fixed_cols_by_col, cond_rules_by_dfcol):
    used = ws.UsedRange
    last_used_row = used.Row + used.Rows.Count - 1 if used else header_row
    max_col = used.Column + used.Columns.Count - 1 if used else 20
    data_rows = len(df)
    
    if footer_row and footer_row > header_row:
        reserved_rows = footer_row - header_row - 1
    else:
        reserved_rows = last_used_row - header_row
    if reserved_rows < 0:
        reserved_rows = 0
    
    ref_row = header_row + 1
    ref_row_exists = ref_row <= last_used_row
    
    if data_rows > reserved_rows:
        insert_count = data_rows - reserved_rows
        if footer_row and footer_row > header_row:
            insert_pos = footer_row
        else:
            insert_pos = header_row + reserved_rows + 1
        if ref_row_exists:
            for _ in range(insert_count):
                ws.Rows(ref_row).Copy()
                ws.Rows(insert_pos).Insert(Shift=-4162)
                clear_range = ws.Range(ws.Cells(insert_pos, 1), ws.Cells(insert_pos, max_col))
                clear_range.ClearContents()
                insert_pos += 1
        else:
            for _ in range(insert_count):
                ws.Rows(insert_pos).Insert(Shift=-4162)
                insert_pos += 1
        if footer_row and footer_row > header_row:
            footer_row += insert_count
    elif data_rows < reserved_rows:
        start_clear = header_row + data_rows + 1
        end_clear = header_row + reserved_rows
        if start_clear <= end_clear:
            ws.Range(f"{start_clear}:{end_clear}").ClearContents()
    
    fill_map = [{} for _ in range(data_rows)]
    for rule in cond_rules_by_dfcol:
        match_df_col = rule.get("match_df_col")
        match_type = rule.get("match_type", "等于")
        match_value = rule.get("match_value", "")
        target_col = rule.get("target_col")
        fill_value = rule.get("fill_value", "")
        if not match_df_col or target_col is None:
            continue
        if match_df_col not in df.columns:
            print(f"警告：规则中的DataFrame列 '{match_df_col}' 不存在，已跳过")
            continue
        for idx, (_, row) in enumerate(df.iterrows()):
            val = row[match_df_col]
            if pd.isna(val):
                cell_str = ""
            else:
                cell_str = str(val).strip()
            matched = False
            if match_type == "等于":
                matched = (cell_str == str(match_value).strip())
            elif match_type == "包含":
                matched = (str(match_value) in cell_str)
            elif match_type == "为空":
                matched = (cell_str == "")
            elif match_type == "非空":
                matched = (cell_str != "")
            if matched:
                fill_map[idx][int(target_col)] = fill_value
    
    for i, (_, row) in enumerate(df.iterrows()):
        rn = header_row + 1 + i
        for col_name, col_idx in col_map.items():
            if col_name not in df.columns:
                continue
            val = row[col_name]
            if pd.isna(val):
                val = ""
            ws.Cells(rn, int(col_idx)).Value = val
        for col_idx, value in fill_map[i].items():
            ws.Cells(rn, col_idx).Value = value
        for col_idx, fixed_val in fixed_cols_by_col.items():
            ws.Cells(rn, int(col_idx)).Value = fixed_val

def smart_column_mapping(df_columns, template_headers, user_mapping=None):
    mapping = {key: int(value) for key, value in (user_mapping or {}).items()}
    used_template_cols = set(mapping.values())
    
    rules = {
        "产品": ["产品", "产品名称"],
        "图纸": ["图纸", "图纸名称"],
        "序号": ["序号", "编号"],
        "GY序号": ["GY序号", "GY"],
        "检验项目": ["检验项目", "项目"],
        "内控要求": ["内控要求", "内控标准"],
        "检验要求": ["检验要求", "要求", "标准"],
        "测量器具": ["测量器具", "量具"],
        "重要度": ["重要度", "等级", "特性符号"],
        "备注": ["备注", "Remark"],
        "现场定制量具": ["现场定制量具", "定制"],
        "检验项目翻译": ["检验项目翻译"],
        "测量器具翻译": ["测量器具翻译"],
        "检测场地": ["检测场地"],
        "样件频次": ["样件频次", "样件检验频次"],
        "样件n": ["样件n"],
        "量产检验频次": ["量产检验频次", "量产频次"],
        "量产n": ["量产n"],
        "方案": ["方案", "抽样方案"],
        "频次": ["频次", "检验频次"],
        "n": ["n", "样本数"],
        "首检": ["首检"],
        "判定_1": ["判定", "判定1"],
        "1": ["1"],
        "2": ["2"],
        "3": ["3"],
        "4": ["4"],
        "5": ["5"],
        "判定_2": ["判定", "判定2"],
        "末检": ["末检"],
        "判定_3": ["判定", "判定3"]
    }
    
    for df_col in df_columns:
        if df_col in mapping:
            continue
        if df_col in rules:
            keywords = rules[df_col]
            for kw in keywords:
                for col_idx, template_header in enumerate(template_headers, 1):
                    if col_idx not in used_template_cols and kw in template_header:
                        mapping[df_col] = col_idx
                        used_template_cols.add(col_idx)
                        break
                if df_col in mapping:
                    break
        else:
            for col_idx, header in enumerate(template_headers, 1):
                if header == df_col and col_idx not in used_template_cols:
                    mapping[df_col] = col_idx
                    used_template_cols.add(col_idx)
                    break
    return mapping

def save_workbook_from_template(template_path: str, output_path: str, sheet_data,
                                sheet_config: Dict[str, Tuple[str, int, Optional[int]]],
                                column_mappings: Dict[str, Dict[str, int]],
                                fixed_cols_rules: Dict[str, Dict[int, str]],
                                cond_rules_list: Dict[str, List[Dict]], report_header=None,
                                report_history=None, history_layouts=None,
                                report_header_cells=None, report_metadata=None, progress=None):
    written = 0
    if progress:
        progress("正在打开模板...")
    with open_workbook(template_path) as wb:
        items = sheet_data.items() if hasattr(sheet_data, "items") else sheet_data
        for sheet_name, df in items:
            if progress:
                progress(f"正在写入 {sheet_name}（{len(df)} 行）...")
            if df.empty:
                continue
            # A shallow copy protects column additions without copying every cell.
            df = df.copy(deep=False)
            sname, header_row, footer_row = sheet_config.get(sheet_name, (sheet_name, 1, None))
            try:
                ws = wb.Sheets(sname)
            except Exception as exc:
                raise ValueError(f"模板缺少工作表：{sname}") from exc
            sheet_header = {**(report_header or {}), **(report_metadata or {}).get(sheet_name, {})}
            if sheet_header:
                for row in range(1, header_row):
                    for column in range(1, min(ws.UsedRange.Column + ws.UsedRange.Columns.Count, 101)):
                        cell = ws.Cells(row, column)
                        value = cell.Value
                        if isinstance(value, str) and "{{" in value:
                            updated = value
                            for field, text in sheet_header.items():
                                updated = updated.replace("{{" + field + "}}", str(text))
                            if updated != value:
                                cell.Value = updated
            try:
                ws.Unprotect()
            except Exception:
                pass
            if sheet_header:
                for field, address in (report_header_cells or {}).get(sheet_name, {}).items():
                    if field in sheet_header and address:
                        ws.Range(str(address)).Value = sheet_header[field]
            
            print(f"\n处理工作表: {sname} (DataFrame行数: {len(df)})")
            
            # 获取模板表头（原始，用于后续强制填充判断）
            used = ws.UsedRange
            max_col = used.Column + used.Columns.Count - 1 if used else 20
            raw_headers = []
            for c in range(1, max_col + 1):
                val = ws.Cells(header_row, c).Value
                raw_headers.append(str(val).strip() if val else "")
            if not any(raw_headers):
                raise ValueError(f"{sname} 的第 {header_row} 行没有表头")
            
            # 处理重复列名（仅用于内部列映射，不改变实际表头）
            headers = []
            header_count = {}
            for idx, h in enumerate(raw_headers):
                if not h:
                    headers.append(f"__empty_{idx+1}")
                    continue
                if h in header_count:
                    header_count[h] += 1
                    new_h = f"{h}_{header_count[h]}"
                else:
                    header_count[h] = 1
                    new_h = h
                headers.append(new_h)
            print(f"  处理后的唯一表头: {headers}")
            
            # ========== 第一阶段：正常数据写入 ==========
            # 构建列映射（包含用户映射和自动匹配）
            user_mapping = column_mappings.get(sheet_name, {}).copy()
            col_map = smart_column_mapping(df.columns, headers, user_mapping)
            if not col_map:
                raise ValueError(f"{sname} 没有匹配的数据列，请设置列映射")
            print(f"  最终列映射: {col_map}")
            
            # 补充缺失列
            for df_col in col_map.keys():
                if df_col not in df.columns:
                    df[df_col] = ""
                    print(f"  自动添加缺失的列: {df_col}")
            
            unmapped = set(df.columns) - set(col_map.keys())
            if unmapped:
                print(f"  警告：以下数据列未映射到模板: {unmapped}")
            
            fixed = fixed_cols_rules.get(sheet_name, {})
            cond_rules = cond_rules_list.get(sheet_name, [])
            # 转换旧格式规则
            new_rules = []
            for rule in cond_rules:
                if "match_df_col" in rule:
                    new_rules.append(rule)
                elif "match_col" in rule:
                    match_col_template = rule["match_col"]
                    found_df_col = None
                    for df_col, tcol in col_map.items():
                        if tcol == match_col_template:
                            found_df_col = df_col
                            break
                    if found_df_col:
                        rule["match_df_col"] = found_df_col
                        del rule["match_col"]
                        new_rules.append(rule)
                        print(f"  自动转换旧规则：模板列 {match_col_template} -> DataFrame列 '{found_df_col}'")
                    else:
                        print(f"  警告：无法将模板列号 {match_col_template} 转换为DataFrame列名，规则已忽略")
                else:
                    print(f"  警告：规则缺少 match_df_col 或 match_col，已忽略")
            apply_rules_to_worksheet(ws, header_row, footer_row, df, col_map, fixed, new_rules)
            written += 1
            
            # ========== 第二阶段：强制后处理填充频次/n列（仅指导书）==========
            if sheet_name in ["出货检验指导书", "过程检验指导书"]:
                # 再次扫描模板中所有频次和n列（基于原始表头）
                exclude_freq = ["样件频次", "量产频次"]
                exclude_n = ["样件n", "量产n"]
                # 获取当前数据区域的行数
                data_rows = len(df)
                for col_idx, h in enumerate(raw_headers, 1):
                    if not h:
                        continue
                    # 频次列
                    if any(kw in h for kw in ["频次", "检验频次"]) and not any(ex in h for ex in exclude_freq):
                        print(f"  强制后处理：频次列 {col_idx} ({h}) 填充 'L'")
                        for r in range(header_row + 1, header_row + 1 + data_rows):
                            ws.Cells(r, col_idx).Value = "L"
                    # n列
                    if (h.lower() == "n" or "样本数" in h) and not any(ex in h for ex in exclude_n):
                        print(f"  强制后处理：n列 {col_idx} ({h}) 填充 5")
                        for r in range(header_row + 1, header_row + 1 + data_rows):
                            ws.Cells(r, col_idx).Value = 5
            
            print(f"  {sheet_name} 处理完成")
            layout = (history_layouts or {}).get(sheet_name, {})
            if layout.get("start"):
                target_name = layout.get("sheet") or sname
                if target_name.casefold() == sname.casefold():
                    target = ws
                else:
                    try:
                        target = wb.Sheets(target_name)
                    except Exception:
                        target = wb.Worksheets.Add()
                        target.Name = target_name
                write_history_block(target, layout["start"], report_history or [],
                                    header_row if target_name.casefold() == sname.casefold() else None, len(df))
        
        if not written:
            raise ValueError("没有可生成的报表数据")
        if report_header:
            try:
                header_sheet = wb.Sheets("报表表头")
            except Exception:
                header_sheet = wb.Worksheets.Add()
                header_sheet.Name = "报表表头"
            for row, (field, value) in enumerate(report_header.items(), 1):
                header_sheet.Cells(row, 1).Value = field
                header_sheet.Cells(row, 2).Value = value
        if report_metadata:
            try:
                versions = wb.Sheets("报表版本信息")
            except Exception:
                versions = wb.Sheets.Add()
                versions.Name = "报表版本信息"
            fields = ("报表名称", "报表版本", "报表修订日期", "报表修订人", "报表修订原因")
            for col, field in enumerate(fields, 1):
                versions.Cells(1, col).Value = field
            for row, (name, metadata) in enumerate(report_metadata.items(), 2):
                for col, field in enumerate(fields, 1):
                    versions.Cells(row, col).Value = name if col == 1 else metadata.get(field, "")
        if progress:
            progress("正在保存报表...")
        wb.SaveAs(Filename=os.path.abspath(output_path), FileFormat=51)
    return written

# ======================== 内置数据 ========================
BUILT_IN_FREQ = """特性符号\t分类\t样件检验频次\t样件n\t量产检验频次\t量产n
▲SPC\t现场\t首中末检\t5\t首中末检\t5
▲SPC\t精测\t首中末检\t2\t首中末检\t1
▲\t现场\t首中末检\t5\t首中末检\t5
▲\t精测\t首中末检\t2\t首中末检\t1
★\t现场\t首中末检\t5\t首中末检\t5
★\t精测\t首中末检\t2\t首末检\t1
☆\t现场\t首中末检\t5\t首中末检\t3
☆\t精测\t首末检\t1\t首检\t1
/\t现场\t首中末检\t5\t首中末检\t3
/\t精测\t首末检\t1\t调试检\t1
/\t外观\t首中末检\t5\t首中末检\t5"""

BUILT_IN_ITEM_TRANS = """检验项目\t检验项目翻译
外径\t外径Outer Diameter
槽径\t槽径Groove Diameter
孔径\t孔径aperture
长度\t长度Length
角度\t角度Angle
圆角\t圆角Round
倒角\t倒角Chamfer
垂直度\t垂直度Perpendicularity
同心度\t同心度Concentricity
同轴度\t同轴度Coaxiality
平面度\t平面度Flatness
粗糙度\t粗糙度roughness
ES\tES
FG\tFG
直径\t直径diameter
位置度\t位置度positional
螺纹\t螺纹thread
螺纹中径\t螺纹中径Pitch Diameter
螺纹大径\t螺纹大径Major Diameter
牙型角\t牙型角Thread Angle
牙半角\t牙半角Half Angle of Thread
牙距\t牙距pitch
圆跳动\t圆跳动Circular Runout
槽宽\t槽宽Groove Width"""

BUILT_IN_TOOL_TRANS = """测量器具\t出货检验翻译\t过程检验翻译
三坐标\t三坐标three-dimensional\t三坐标three-dimensional/检测员inspector
投影仪\t投影仪projector\t投影仪projector/检测员inspector
轮廓仪\t轮廓仪contourgraph\t轮廓仪contourgraph/检测员inspector
粗糙度仪\t粗糙度仪roughness tester\t粗糙度仪roughness tester/检测员inspector
卡尺\t卡尺caliper\t卡尺caliper/操作员operator
外径千分尺\t外径千分尺outside micrometer\t外径千分尺outside micrometer/操作员operator
内径千分尺\t内径千分尺inside micrometer\t内径千分尺inside micrometer/操作员operator
槽径千分尺\t槽径千分尺Micrometer for groove diameter\t槽径千分尺Micrometer for groove diameter/操作员operator
中径千分尺\t中径千分尺Medium diameter micrometer\t中径千分尺Medium diameter micrometer/操作员operator
塞规\t塞规plug gauge\t塞规plug gauge/操作员operator
螺纹环规\t螺纹环规thread ring gage\t螺纹环规thread ring gage/操作员operator
高度规\t高度规height master\t高度规height master/操作员operator
气动测量仪\t气动测量仪pneumatic measuring instrument\t气动测量仪pneumatic measuring instrument/操作员operator
专用检具\t专用检具special gauge\t专用检具special gauge/操作员operator
螺纹塞规\t螺纹塞规screw plug gauge\t螺纹塞规screw plug gauge/操作员operator
目视\t目视visual\t目视visual/操作员operator
粗糙仪\t粗糙仪roughness tester\t粗糙仪roughness tester/检测员inspector
测高仪\t测高仪Digital Height Gauge\t测高仪Digital Height Gauge/检测员inspector
孔径千分尺\t孔径千分尺inside micrometer\t孔径千分尺inside micrometer/操作员operator
气动量仪\t气动量仪pneumatic measuring instrument\t气动量仪pneumatic measuring instrument/操作员operator"""

REPORT_TYPES = ["全尺寸检验表", "出货检验表", "过程检验表", "出货检验指导书", "过程检验指导书", "首件检验报表"]
IMPORTANCE_OPTIONS = ["▲SPC", "▲", "★", "☆", "/"]

FIELD_ALIASES = {
    "序号": ["序号", "编号", "No"],
    "产品": ["产品", "产品名称"],
    "图纸": ["图纸", "图纸名称"],
    "检验项目": ["检验项目", "项目"],
    "检验要求": ["检验要求", "要求", "标准"],
    "测量器具": ["测量器具", "量具"],
    "重要度": ["重要度", "等级", "特性符号"],
    "内控要求": ["内控要求", "内控标准"],
    "检测场地": ["检测场地"],
    "样件频次": ["样件频次", "样件检验频次"],
    "样件n": ["样件n"],
    "量产检验频次": ["量产检验频次"],
    "量产n": ["量产n"],
    "检验项目翻译": ["检验项目翻译"],
    "测量器具翻译": ["测量器具翻译"],
    "特性分类": ["特性分类"],
    "GY序号": ["GY序号"],
    "备注": ["备注", "Remark"],
    "现场定制量具": ["现场定制量具", "定制"]
}

# ======================== 默认规则 ========================
DEFAULT_RULES = {
    "全尺寸检验表": {
        "translation_type": "ship",
        "add_translations": True,
        "dedup": False,
        "thread_merge": False,
        "thread_parents": [],
        "thread_allowed": [],
        "special_keywords": [],
        "patrol": False,
        "patrol_importance": [],
        "patrol_n": 4,
        "add_freq": True,
        "add_location": True,
        "replace_measure_tool": False,
        "precision_tool_text": "精测专用检具",
        "field_tool_text": "现场尺寸",
        "precision_categories": ["三坐标", "轮廓仪", "投影仪", "粗糙度仪", "粗糙仪"],
        "fixed_columns": {},
        "conditional_rules": [],
        "column_mapping": {}
    },
    "出货检验表": {
        "translation_type": "ship",
        "add_translations": True,
        "dedup": True,
        "thread_merge": True,
        "thread_parents": ["4"],
        "thread_allowed": ["螺纹", "螺纹中径"],
        "special_keywords": ["gn", "gx"],
        "patrol": False,
        "patrol_importance": [],
        "patrol_n": 4,
        "add_freq": True,
        "add_location": True,
        "replace_measure_tool": False,
        "precision_tool_text": "精测专用检具",
        "field_tool_text": "现场尺寸",
        "precision_categories": ["三坐标", "轮廓仪", "投影仪", "粗糙度仪", "粗糙仪"],
        "fixed_columns": {},
        "conditional_rules": [],
        "column_mapping": {}
    },
    "过程检验表": {
        "translation_type": "process",
        "add_translations": True,
        "dedup": False,
        "thread_merge": False,
        "thread_parents": [],
        "thread_allowed": [],
        "special_keywords": [],
        "patrol": True,
        "patrol_importance": ["▲SPC", "▲", "★"],
        "patrol_n": 4,
        "add_freq": True,
        "add_location": True,
        "replace_measure_tool": False,
        "precision_tool_text": "精测专用检具",
        "field_tool_text": "现场尺寸",
        "precision_categories": ["三坐标", "轮廓仪", "投影仪", "粗糙度仪", "粗糙仪"],
        "fixed_columns": {},
        "conditional_rules": [
            {"match_df_col": "样件n", "match_type": "等于", "match_value": "1", "target_col": 1, "fill_value": "/"},
            {"match_df_col": "样件n", "match_type": "等于", "match_value": "1", "target_col": 2, "fill_value": "/"},
            {"match_df_col": "样件n", "match_type": "等于", "match_value": "1", "target_col": 3, "fill_value": "/"},
            {"match_df_col": "样件n", "match_type": "等于", "match_value": "1", "target_col": 4, "fill_value": "/"},
            {"match_df_col": "样件n", "match_type": "等于", "match_value": "1", "target_col": 5, "fill_value": "/"},
            {"match_df_col": "样件n", "match_type": "等于", "match_value": "1", "target_col": 6, "fill_value": "/"},
            {"match_df_col": "样件n", "match_type": "等于", "match_value": "2", "target_col": 1, "fill_value": "/"},
            {"match_df_col": "样件n", "match_type": "等于", "match_value": "2", "target_col": 3, "fill_value": "/"},
            {"match_df_col": "样件n", "match_type": "等于", "match_value": "2", "target_col": 5, "fill_value": "/"}
        ],
        "column_mapping": {}
    },
    "出货检验指导书": {
        "translation_type": "ship",
        "add_translations": True,
        "dedup": False,
        "thread_merge": False,
        "thread_parents": [],
        "thread_allowed": [],
        "special_keywords": [],
        "patrol": False,
        "patrol_importance": [],
        "patrol_n": 4,
        "add_freq": True,
        "add_location": True,
        "replace_measure_tool": False,
        "precision_tool_text": "精测专用检具",
        "field_tool_text": "现场尺寸",
        "precision_categories": ["三坐标", "轮廓仪", "投影仪", "粗糙度仪", "粗糙仪"],
        "add_guide_fixed_columns": True,
        "fixed_columns": {},
        "conditional_rules": [
            {"match_df_col": "测量器具", "match_type": "为空", "match_value": "", "target_col": 6, "fill_value": "直接测量"}
        ],
        "column_mapping": {}
    },
    "过程检验指导书": {
        "translation_type": "ship",
        "add_translations": True,
        "dedup": False,
        "thread_merge": False,
        "thread_parents": [],
        "thread_allowed": [],
        "special_keywords": [],
        "patrol": True,
        "patrol_importance": ["▲SPC", "▲", "★"],
        "patrol_n": 4,
        "add_freq": True,
        "add_location": True,
        "replace_measure_tool": False,
        "precision_tool_text": "精测专用检具",
        "field_tool_text": "现场尺寸",
        "precision_categories": ["三坐标", "轮廓仪", "投影仪", "粗糙度仪", "粗糙仪"],
        "add_guide_fixed_columns": True,
        "fixed_columns": {},
        "conditional_rules": [
            {"match_df_col": "测量器具", "match_type": "为空", "match_value": "", "target_col": 6, "fill_value": "直接测量"}
        ],
        "column_mapping": {}
    },
    "首件检验报表": {
        "translation_type": "ship",
        "add_translations": True,
        "dedup": False,
        "thread_merge": False,
        "thread_parents": [],
        "thread_allowed": [],
        "special_keywords": [],
        "patrol": False,
        "patrol_importance": [],
        "patrol_n": 4,
        "add_freq": True,
        "add_location": True,
        "replace_measure_tool": False,
        "precision_tool_text": "精测专用检具",
        "field_tool_text": "现场尺寸",
        "precision_categories": ["三坐标", "轮廓仪", "投影仪", "粗糙度仪", "粗糙仪"],
        "fixed_columns": {},
        "conditional_rules": [],
        "column_mapping": {}
    }
}

# ======================== 数据处理引擎 ========================
class DataProcessor:
    def __init__(self, df_source, freq_df, item_trans, tool_ship, tool_proc):
        # Source data is treated as read-only; retaining it avoids a full DataFrame copy.
        self.df = df_source
        self.freq = freq_df
        self.item_trans = item_trans
        self.tool_ship = tool_ship
        self.tool_proc = tool_proc

    @staticmethod
    def text(value):
        return "" if value is None or pd.isna(value) else str(value).strip()

    def location(self, tool, rules):
        return "精测" if tool in rules.get("precision_categories", []) else "现场"

    def frequency(self, importance, location):
        if not importance:
            return {"样件频次": "首中末检", "样件n": 5,
                    "量产检验频次": "首中末检", "量产n": 5}
        required = {"特性符号", "分类", "样件检验频次", "样件n", "量产检验频次", "量产n"}
        if not required.issubset(self.freq.columns):
            return {"样件频次": "未定义", "样件n": 0,
                    "量产检验频次": "未定义", "量产n": 0}
        matches = self.freq[
            (self.freq["特性符号"].astype(str).str.strip() == importance) &
            (self.freq["分类"].astype(str).str.strip() == location)
        ]
        if matches.empty:
            return {"样件频次": "未定义", "样件n": 0,
                    "量产检验频次": "未定义", "量产n": 0}
        match = matches.iloc[0]

        def count(value):
            try:
                return int(float(value))
            except (TypeError, ValueError):
                return 0

        return {
            "样件频次": self.text(match["样件检验频次"]),
            "样件n": count(match["样件n"]),
            "量产检验频次": self.text(match["量产检验频次"]),
            "量产n": count(match["量产n"]),
        }

    def row_data(self, source, rules, process=False):
        get = lambda name: self.text(source.get(name, ""))
        tool = get("测量器具")
        location = self.location(tool, rules)
        output = {name: get(name) for name in (
            "产品", "图纸", "序号", "检验项目", "内控要求", "检验要求",
            "测量器具", "重要度", "备注", "现场定制量具"
        )}
        output["GY序号"] = get("GY序号")
        if rules.get("replace_measure_tool"):
            output["测量器具"] = (
                rules.get("precision_tool_text", "精测专用检具")
                if location == "精测" else rules.get("field_tool_text", "现场尺寸")
            )
        if rules.get("add_translations"):
            dictionary = self.tool_ship if rules.get("translation_type") == "ship" else self.tool_proc
            output["检验项目翻译"] = self.item_trans.get(get("检验项目"), get("检验项目"))
            output["测量器具翻译"] = dictionary.get(tool, tool)
        if rules.get("add_location"):
            output["检测场地"] = location
        if process and rules.get("add_freq"):
            output.update(self.frequency(get("重要度"), location))
        return output

    @staticmethod
    def parent_seq(value):
        try:
            return int(float(value))
        except (TypeError, ValueError):
            return str(value)

    def validate_drawings(self, rules):
        available = set(self.df["图纸"].map(self.text)) if "图纸" in self.df else set()
        selected = {str(value).strip() for value in rules.get("source_drawings", []) if str(value).strip()}
        if selected - available:
            raise ValueError("来源图纸不存在：" + "、".join(sorted(selected - available)))
        if len(available) > 1 and not selected:
            raise ValueError("数据包含多张工序图纸，请在报表规则中选择来源图纸，并为不同工序新增报表、分别设置目标 Sheet")

    def build(self, report_type, rules):
        report_kind = rules.get("base_type", report_type)
        columns = list(self.df.columns)
        source_rows = (
            dict(zip(columns, values))
            for values in self.df.itertuples(index=False, name=None)
        )
        # 每个报表规则可限制来源图纸；未配置时保持兼容，使用全部图纸。
        drawing_filter = {str(value).strip() for value in rules.get("source_drawings", []) if str(value).strip()}
        if drawing_filter:
            source_rows = [row for row in source_rows
                           if str(row.get("图纸", "")).strip() in drawing_filter]
        if report_kind == "出货检验表":
            selected = []
            seen = set()
            thread_parents = {
                self.parent_seq(value) for value in rules.get("thread_parents", [])
            }
            allowed = set(rules.get("thread_allowed", []))
            keywords = [str(value).lower() for value in rules.get("special_keywords", []) if value]
            for source in source_rows:
                parent = self.parent_seq(source.get("序号", ""))
                item = self.text(source.get("检验项目", ""))
                if rules.get("thread_merge") and parent in thread_parents:
                    if item not in allowed:
                        continue
                special_text = (
                    self.text(source.get("检验要求", "")) + " " +
                    self.text(source.get("内控要求", ""))
                ).lower()
                special = any(word in special_text for word in keywords)
                drawing = self.text(source.get("图纸", ""))
                if rules.get("dedup") and (drawing, parent, item) in seen and not special:
                    continue
                seen.add((drawing, parent, item))
                selected.append(source)
            source_rows = selected

        process = report_kind in ("过程检验表", "过程检验指导书")
        rows = []
        for source in source_rows:
            row = self.row_data(source, rules, process=process)
            rows.append(row)
            location = self.location(self.text(source.get("测量器具", "")), rules)
            if (process and rules.get("patrol") and location == "现场"
                    and row["重要度"] in rules.get("patrol_importance", [])):
                patrol = row.copy()
                patrol["检测场地"] = "巡检"
                patrol["样件频次"] = rules.get("patrol_freq", "首中末检")
                patrol["样件n"] = rules.get("patrol_n", 4)
                patrol["量产检验频次"] = rules.get("patrol_mass_freq", "首中末检")
                patrol["量产n"] = rules.get("patrol_mass_n", 5)
                if report_kind == "过程检验指导书":
                    patrol["备注"] = rules.get("patrol_remark", "巡检测量")
                rows.append(patrol)

        result = pd.DataFrame(rows)
        if report_kind in ("出货检验指导书", "过程检验指导书"):
            result["方案"] = "(0，1)"
            result["频次"] = "L"
            result["n"] = 5
            for column in ("首检", "判定_1", "1", "2", "3", "4", "5", "判定_2", "末检", "判定_3"):
                result[column] = ""
        return result


def clean_frame(frame):
    return frame.fillna("").astype(str).apply(lambda column: column.str.strip())



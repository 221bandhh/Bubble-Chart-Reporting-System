"""Validate header cell addresses and read a small worksheet neighborhood."""
import re

from core import excel_com
from core.excel_com import coordinate_to_tuple, get_column_letter


def cell_address(value):
    address = str(value).strip().replace("$", "").upper()
    if not re.fullmatch(r"[A-Z]{1,3}[1-9][0-9]{0,6}", address):
        raise ValueError("单元格地址应为 A1、B3 等单个位置")
    row, column = coordinate_to_tuple(address)
    if row > 1048576 or column > 16384:
        raise ValueError("单元格地址超出 Excel 范围")
    return address


def parse_header_cells(text, allowed):
    result = {}
    for entry in text.replace("，", ",").split(","):
        if not entry.strip():
            continue
        if "=" not in entry:
            raise ValueError("格式应为 产品名=B2，版本=F2")
        field, address = (part.strip() for part in entry.split("=", 1))
        if field not in allowed:
            raise ValueError(f"未知产品信息字段：{field}")
        result[field] = cell_address(address)
    return result


def preview_header_cells(path, sheet_name, mappings):
    workbook = excel_com.load_workbook(path, data_only=False)
    try:
        sheet = workbook[sheet_name]
        result = []
        for field, raw in mappings.items():
            address = cell_address(raw)
            anchor = sheet.raw.Range(address).MergeArea.Cells(1, 1).Address(False, False)
            row, column = coordinate_to_tuple(address)
            start_row, end_row = max(1, row - 2), min(1048576, row + 2)
            start_col, end_col = max(1, column - 2), min(16384, column + 2)
            result.append({"field": field, "address": address, "anchor": anchor,
                "value": sheet[anchor].value, "row": row, "column": column,
                "columns": [get_column_letter(i) for i in range(start_col, end_col + 1)],
                "rows": [(i, [sheet.cell(i, j).value for j in range(start_col, end_col + 1)])
                         for i in range(start_row, end_row + 1)]})
        return result
    finally:
        workbook.close()

"""Write a fixed-size revision block without changing inspection rows."""

from core.excel_com import coordinate_to_tuple

from core.product_info import REPORT_HEADER_FIELDS, latest_revisions


def history_origin(address):
    try:
        row, column = coordinate_to_tuple(address.strip().upper().replace("$", ""))
        if row < 1 or row + 3 > 1048576 or column < 1 or column + 7 > 16384:
            raise ValueError
        return row, column
    except (ValueError, TypeError, AttributeError, KeyError) as exc:
        raise ValueError("修改记录起始单元格无效，例如 A1 或 K2") from exc


def write_history_block(sheet, address, records, data_header=None, data_count=0):
    row, column = history_origin(address)
    if data_header and row <= data_header + data_count and row + 3 >= data_header:
        raise ValueError("修改记录区域与尺寸数据行重叠，请选择其他位置或独立工作表")
    latest = latest_revisions(records)
    for offset in range(4):
        for index, field in enumerate(REPORT_HEADER_FIELDS):
            value = field if offset == 0 else (latest[offset - 1].get(field, "") if offset <= len(latest) else "")
            sheet.Cells(row + offset, column + index).Value = value

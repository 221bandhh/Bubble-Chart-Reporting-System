"""Reusable single-report presets, including ready-to-use standard workbooks."""
import copy

from core import excel_com
from core.excel_com import Font, PatternFill

from report_system.core.engine import DEFAULT_RULES, REPORT_TYPES


def ensure_builtin_presets(library):
    items = library.list_items()
    missing = [name for name in REPORT_TYPES
               if not any(item.get("builtin_report_type") == name for item in items)]
    if not missing:
        return
    folder = library.root / "standard_reports"
    folder.mkdir(parents=True, exist_ok=True)
    template = folder / "标准报表模板.xlsx"
    columns = ["图纸", "序号", "检验项目", "检验要求", "测量器具", "重要度", "检测场地", "备注",
               "内控要求", "现场定制量具", "检验项目英文", "测量器具英文", "检验频次", "巡检频次",
               "样件n", "量产n", "频次", "首件", "末件", "1", "2", "3", "4", "5", "n"]
    if not template.exists():
        workbook = excel_com.Workbook()
        workbook.remove(workbook.active)
        for name in REPORT_TYPES:
            sheet = workbook.create_sheet(name)
            sheet.merge_cells("A1:H1")
            sheet["A1"] = name
            sheet["A1"].font = Font(size=18, bold=True)
            sheet["A2"] = "产品：{{产品名}}    产品版本：{{版本}}    图版本：{{图版本}}"
            sheet["A3"] = "报表版本：{{报表版本}}    修订日期：{{报表修订日期}}"
            for index, column in enumerate(columns, 1):
                cell = sheet.cell(6, index, column)
                cell.font = Font(bold=True, color="FFFFFF")
                cell.fill = PatternFill("solid", fgColor="305496")
                sheet.column_dimensions[cell.column_letter].width = 20
            sheet["A14"] = "检验：________    审核：________"
            sheet.freeze_panes = "A7"
        workbook.save(template)
        workbook.close()
    for name in missing:
        rule = copy.deepcopy(DEFAULT_RULES[name])
        rule.update(base_type=name, source_drawings=[], conditional_rules=[],
                    column_mapping={column: index for index, column in enumerate(columns, 1)})
        # Thread parent numbers depend on each product's drawing.
        rule.update(thread_merge=False, thread_parents=[])
        settings = {name: {"sheet_name": name, "header": 6, "footer": 14,
                           "history_sheet": "报表修订记录", "history_start": "A1"}}
        library.add({"name": f"报表类型模板-{name}", "kind": "report_type", "builtin_report_type": name,
                     "requirement": "标准规则、列映射、Excel模板及表头表尾已配置",
                     "config": {"rules": {name: rule}, "sheet_config": settings,
                                "templates": {"path": str(template)},
                                "template_profiles": {"标准模板": {"path": str(template), "sheet_config": settings}},
                                "active_template_profile": "标准模板"}})


def instantiate_preset(config, source_report, new_name, drawings):
    """Copy a report without carrying another product's scope or revision identity."""
    profile = config.get("template_profiles", {}).get(config.get("active_template_profile"), {})
    path = profile.get("path") or config.get("templates", {}).get("path", "")
    settings = profile.get("sheet_config", config.get("sheet_config", {})).get(source_report)
    if not path or not settings or int(settings.get("header", 0)) <= 0:
        raise ValueError("此类型模板缺少 Excel 模板或表头定位，请先配置后保存")
    rule = copy.deepcopy(config["rules"][source_report])
    rule["source_drawings"] = list(drawings)
    for key in ("report_version", "report_date", "report_author", "report_reason"):
        rule[key] = ""
    return {"name": new_name, "rule": rule, "path": path, "settings": copy.deepcopy(settings)}

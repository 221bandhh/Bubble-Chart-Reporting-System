"""Small atomic JSON store for report profiles."""

from __future__ import annotations

import json
import os
from pathlib import Path


class ConfigStore:
    def __init__(self, path):
        self.path = Path(path).resolve()

    def load(self):
        if not self.path.is_file():
            return None
        with open(self.path, encoding="utf-8") as stream:
            value = json.load(stream)
        if not isinstance(value, dict):
            raise ValueError("配置文件格式错误")
        return value

    def save(self, value):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        with open(temporary, "w", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2)
        os.replace(temporary, self.path)


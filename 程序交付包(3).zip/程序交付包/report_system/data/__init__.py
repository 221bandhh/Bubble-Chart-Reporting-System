"""Report configuration persistence."""


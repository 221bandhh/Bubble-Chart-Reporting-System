"""Standalone configurable report generation subsystem."""


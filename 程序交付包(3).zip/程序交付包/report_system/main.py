"""Standalone report system entry point."""

import os
import sys

if __package__ in (None, ""):
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from report_system.ui.app import run


if __name__ == "__main__":
    source = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 and os.path.isfile(sys.argv[1]) else None
    run(source)


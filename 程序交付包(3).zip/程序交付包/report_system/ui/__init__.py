"""Report system user interface."""


# 报表工具架构

## 启动入口

- `baobiao.py`：统一程序入口，左侧产品列表，右侧气泡标注和检验报表两个页面。
- `baobiaosys.py`：多 Sheet 报表生成工具，也继续导出旧版可调用的核心 API。

## 模块边界

- `core/bubble_engine.py`：气泡 CRUD、序号校验、命中测试和最多 100 步撤销。
- `report_system/core/engine.py`：报表规则、DataFrame 转换、频次和翻译处理。
- `data/product_repository.py`：产品目录、配置持久化、图纸复制和旧项目迁移。
- `data/excel_contract.py`：`bubble_export.xlsx` 数据契约。
- `ui/bubble_app.py`：原生 `tkinter.Canvas` 气泡界面。
- `report_system/ui/app.py`：报表配置和生成界面。
- `report_system/data/config_store.py`：模板方案与报表配置的原子保存。
- `report_system/main.py`：独立报表入口，可直接运行或通过 `python -m report_system.main` 启动。

统一程序首次进入报表页才加载报表模块。预览或生成时，自动保存当前产品气泡并刷新 `bubble_export.xlsx` 数据源。
切换产品前保存报表配置，随后销毁报表页并释放源数据，按新产品目录加载其模板和规则。
`report_system/` 是内部模块目录，日常使用不需要另开窗口。

## 产品目录

```text
products/
  index.json
  <产品名称>/
    product.json
    bubble_export.xlsx
    report_generator_config.json
    drawings/
      <drawing-id>.jpg
```

启动气泡工具时，如果产品索引为空且根目录存在旧 `project.json`，数据会自动迁移到“历史项目”。旧文件保留，不执行删除。

## Excel 契约

标准工作表名为 `气泡数据`，字段为：

`产品、图纸、序号、检验项目、检验要求、测量器具、内控要求、重要度、现场定制量具、备注、X、Y`

报表工具优先读取该工作表；`.xlsx/.xlsm/.xls` 均通过 pywin32 调用 Excel/WPS COM 读取；运行时不依赖 openpyxl。

产品保留内部 ID 用于数据关联，目录按产品名称命名，重名目录增加序号。已有 ID 目录自动迁移。
“产品及修改信息”独立保存产品名、产品规格、产品料号、版本、图版本、修改日期、修改人、修改原因。
导出的 Excel 和最终报表包含独立的“报表表头”页。
模板各 Sheet 的表头行之前可放置 `{{产品名}}`、`{{产品规格}}`、`{{产品料号}}`、`{{版本}}`、`{{图版本}}`、`{{修改日期}}`、`{{修改人}}`、`{{修改原因}}`，生成时自动替换。

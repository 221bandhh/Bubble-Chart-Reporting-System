"""Persistence and interchange adapters."""


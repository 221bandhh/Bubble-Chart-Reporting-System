"""Canvas-based product and bubble editor."""

from __future__ import annotations

import base64
import os
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk

import cv2
import numpy as np

from core.bubble_engine import BUBBLE_FIELDS, BubbleEngine, BubbleError, sequence_label
from core.bubble_filters import cell_text, matches, value_counts
from core.product_info import REPORT_HEADER_FIELDS, append_revision, report_header, revision_history
from data.excel_contract import export_product
from data.product_repository import ProductRepository


COLUMN_NAMES = {
    "seq": "序号", "item": "检验项目", "req": "检验要求", "tool": "测量器具",
    "internal": "内控要求", "importance": "重要度", "measure_method": "现场定制量具",
    "remark": "备注", "x": "X", "y": "Y",
}


class BubbleApp:
    def __init__(self, root, workspace):
        self.root = root
        self.workspace = Path(workspace).resolve()
        self.repository = ProductRepository(self.workspace)
        self.product = None
        self.drawing = None
        self.engines = {}
        self.photo = None
        self.image_size = (1, 1)
        self.display = (0, 0, 1, 1, 1.0)
        self.resize_job = None
        self.selected_seq = None
        self.column_filters = {}
        self.active_column = "#2"
        self.drag_start = None
        self.drag_position = None
        self.report_app = None
        root.title("产品气泡标注与检验报表系统")
        root.geometry("1500x900")
        self._build_ui()
        self._refresh_products()
        root.bind("<Control-z>", self.undo)
        root.protocol("WM_DELETE_WINDOW", self.on_close)

    @property
    def engine(self):
        if self.drawing is None:
            return None
        drawing_id = self.drawing["id"]
        if drawing_id not in self.engines:
            self.engines[drawing_id] = BubbleEngine(self.drawing.get("bubbles", []), history_limit=100)
        return self.engines[drawing_id]

    def _build_ui(self):
        outer = ttk.PanedWindow(self.root, orient=tk.HORIZONTAL)
        outer.pack(fill=tk.BOTH, expand=True)
        products = ttk.Frame(outer, width=220)
        workspace = ttk.Frame(outer)
        outer.add(products, weight=0)
        outer.add(workspace, weight=1)
        self.main_tabs = ttk.Notebook(workspace)
        self.main_tabs.pack(fill=tk.BOTH, expand=True)
        self.bubble_page = ttk.Frame(self.main_tabs)
        self.report_page = ttk.Frame(self.main_tabs)
        self.main_tabs.add(self.bubble_page, text="气泡标注")
        self.main_tabs.add(self.report_page, text="检验报表")
        self.main_tabs.bind("<<NotebookTabChanged>>", self._on_main_tab)
        workspace = self.bubble_page

        ttk.Label(products, text="产品").pack(anchor=tk.W, padx=8, pady=(10, 4))
        self.product_list = tk.Listbox(products, exportselection=False, width=25)
        self.product_list.pack(fill=tk.BOTH, expand=True, padx=8)
        self.product_list.bind("<<ListboxSelect>>", self._on_product_select)
        product_actions = ttk.Frame(products)
        product_actions.pack(fill=tk.X, padx=8, pady=8)
        ttk.Button(product_actions, text="新建", command=self.new_product).pack(side=tk.LEFT, expand=True, fill=tk.X)
        ttk.Button(product_actions, text="删除", command=self.delete_product).pack(side=tk.LEFT, expand=True, fill=tk.X, padx=(4, 0))
        ttk.Button(products, text="产品及修改信息", command=self.edit_product_header).pack(fill=tk.X, padx=8, pady=4)
        ttk.Button(products, text="修改产品名称", command=self.rename_product).pack(fill=tk.X, padx=8, pady=4)
        ttk.Button(products, text="JSON → 新建产品", command=self.import_product).pack(fill=tk.X, padx=8, pady=4)
        ttk.Button(products, text="JSON → 当前产品新工序", command=lambda: self.import_product(True)).pack(fill=tk.X, padx=8, pady=4)

        drawing_bar = ttk.Frame(workspace)
        drawing_bar.pack(fill=tk.X, padx=6, pady=6)
        ttk.Label(drawing_bar, text="图纸").pack(side=tk.LEFT)
        self.drawing_selector = ttk.Combobox(drawing_bar, state="readonly", width=32)
        self.drawing_selector.pack(side=tk.LEFT, padx=5)
        self.drawing_selector.bind("<<ComboboxSelected>>", self._on_drawing_select)
        ttk.Button(drawing_bar, text="添加图纸", command=self.add_drawings).pack(side=tk.LEFT, padx=2)
        ttk.Button(drawing_bar, text="移除图纸", command=self.remove_drawing).pack(side=tk.LEFT, padx=2)
        ttk.Button(drawing_bar, text="工序改名", command=self.rename_drawing).pack(side=tk.LEFT, padx=2)
        ttk.Button(drawing_bar, text="撤销", command=self.undo).pack(side=tk.LEFT, padx=(12, 2))
        ttk.Button(drawing_bar, text="添加子序号", command=self.add_child).pack(side=tk.LEFT, padx=2)
        ttk.Button(drawing_bar, text="复制上一行", command=self.copy_previous_row).pack(side=tk.LEFT, padx=2)
        ttk.Button(drawing_bar, text="导出数据", command=self.export_contract).pack(side=tk.RIGHT, padx=2)
        ttk.Button(drawing_bar, text="生成检验报表", command=self.open_report_tool).pack(side=tk.RIGHT, padx=2)

        pane = ttk.PanedWindow(workspace, orient=tk.HORIZONTAL)
        pane.pack(fill=tk.BOTH, expand=True)
        canvas_frame = ttk.Frame(pane)
        table_frame = ttk.Frame(pane, width=620)
        pane.add(canvas_frame, weight=3)
        pane.add(table_frame, weight=2)
        self.canvas = tk.Canvas(canvas_frame, background="#202124", highlightthickness=0, cursor="crosshair")
        self.canvas.pack(fill=tk.BOTH, expand=True)
        self.canvas.bind("<Configure>", self._on_canvas_resize)
        self.canvas.bind("<Button-1>", self._on_canvas_click)
        self.canvas.bind("<B1-Motion>", self._on_canvas_drag)
        self.canvas.bind("<ButtonRelease-1>", self._on_canvas_release)
        self.canvas.bind("<Button-3>", self._on_canvas_right_click)

        self.tree = ttk.Treeview(table_frame, columns=BUBBLE_FIELDS, show="headings", selectmode="browse")
        widths = (55, 110, 130, 100, 130, 70, 100, 110, 55, 55)
        for key, width in zip(BUBBLE_FIELDS, widths):
            self.tree.heading(key, text=COLUMN_NAMES[key], command=lambda k=key: self._filter_column(k))
            self.tree.column(key, width=width, anchor=tk.CENTER, stretch=False)
        ybar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.tree.yview)
        xbar = ttk.Scrollbar(table_frame, orient=tk.HORIZONTAL, command=self.tree.xview)
        self.tree.configure(yscrollcommand=ybar.set, xscrollcommand=xbar.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        ybar.grid(row=0, column=1, sticky="ns")
        xbar.grid(row=1, column=0, sticky="ew")
        table_frame.grid_rowconfigure(0, weight=1)
        table_frame.grid_columnconfigure(0, weight=1)
        self.tree.bind("<<TreeviewSelect>>", self._on_tree_select)
        self.tree.bind("<Double-1>", self._edit_cell)
        self.tree.bind("<Button-1>", self._remember_cell)
        self.tree.bind("<space>", self._edit_cell_keyboard)
        self.tree.bind("<F2>", self._edit_cell_keyboard)
        for direction in ("Up", "Down", "Left", "Right"):
            self.tree.bind(f"<{direction}>", self._navigate_cell)
        ttk.Button(table_frame, text="清除列筛选（表头筛选统计；方向键切换单元格；空格编辑）",
                   command=self._clear_filters).grid(row=2, column=0, sticky="ew")
        self.status = tk.StringVar(value="就绪")
        ttk.Label(workspace, textvariable=self.status).pack(anchor=tk.W, padx=8, pady=4)

    def rename_product(self):
        if self.product is None:
            return
        name = simpledialog.askstring("修改产品名称", "产品列表名称：", initialvalue=self.product["name"], parent=self.root)
        if name and name.strip():
            self.product["name"] = name.strip()
            self._save_product()
            for index, item in enumerate(self.product_items):
                if item["id"] == self.product["id"]:
                    item["name"] = name.strip()
                    self.product_list.delete(index)
                    self.product_list.insert(index, name.strip())
                    self.product_list.selection_set(index)

    def rename_drawing(self):
        if self.drawing is None:
            return
        name = simpledialog.askstring("工序改名", "图纸 / 工序名称：", initialvalue=self.drawing["name"], parent=self.root)
        if name and name.strip():
            self.drawing["name"] = name.strip()
            self._save_product()
            index = self.drawing_selector.current()
            self.drawing_selector["values"] = [d["name"] for d in self.product["drawings"]]
            self.drawing_selector.current(index)

    def import_product(self, into_current=False):
        if into_current and self.product is None:
            messagebox.showwarning("提示", "请先选择要添加工序的产品", parent=self.root)
            return
        path = filedialog.askopenfilename(parent=self.root, title="导入旧版或新版产品 JSON",
                                         filetypes=[("产品配置", "*.json")])
        if not path:
            return
        name = simpledialog.askstring("导入工序" if into_current else "导入新产品",
            "新工序名称（多图纸自动添加后缀）：" if into_current else "新产品名称：",
            initialvalue=Path(path).stem, parent=self.root)
        if not name or not name.strip():
            return
        if not self._save_report_context():
            return
        self._save_product()
        self._release_report_context()
        options = {"target_product": self.product, "drawing_name": name.strip()} if into_current else {"name": name.strip()}
        try:
            try:
                product = self.repository.import_product(path, **options)
            except FileNotFoundError as exc:
                if not messagebox.askyesno("图纸未找到", f"{exc}\n是否手动选择单图纸文件？", parent=self.root):
                    return
                image = filedialog.askopenfilename(parent=self.root, title="选择此产品对应的图纸",
                    filetypes=[("图纸图片", "*.png *.jpg *.jpeg *.bmp *.tif *.tiff"), ("所有文件", "*.*")])
                if not image:
                    return
                product = self.repository.import_product(path, image_path=image, **options)
            self._refresh_products(product["id"])
            messagebox.showinfo("导入完成", "产品及图纸已复制到当前程序，气泡数据已保留，原文件未修改。", parent=self.root)
        except (OSError, ValueError, TypeError, KeyError) as exc:
            messagebox.showerror("导入失败", str(exc), parent=self.root)

    def _refresh_products(self, selected_id=None):
        products = self.repository.list_products()
        missing = [item for item in products
                   if not (self.repository.product_dir(item) / "product.json").is_file()]
        products = [item for item in products if item not in missing]
        if missing:
            messagebox.showwarning(
                "产品配置缺失",
                "以下产品的 product.json 不存在，已暂时跳过（未删除索引或数据）：\n"
                + "\n".join(str(self.repository.product_dir(item) / "product.json") for item in missing)
                + "\n请从备份恢复对应产品目录后重新启动。")
        self.product_items = products
        self.product_list.delete(0, tk.END)
        for item in products:
            self.product_list.insert(tk.END, item["name"])
        if not products:
            self._clear_product()
            return
        index = next((i for i, item in enumerate(products) if item["id"] == selected_id), 0)
        self.product_list.selection_set(index)
        self.product_list.activate(index)
        self._load_product(products[index]["id"])

    def _on_product_select(self, _event=None):
        selection = self.product_list.curselection()
        if selection:
            product_id = self.product_items[selection[0]]["id"]
            if self.product is None or self.product["id"] != product_id:
                self._load_product(product_id)

    def _sync_current(self):
        if self.drawing is not None and self.engine is not None:
            self.drawing["bubbles"] = self.engine.bubbles

    def _save_product(self):
        if self.product is not None:
            self._sync_current()
            self.repository.save(self.product)

    def _load_product(self, product_id):
        try:
            product = self.repository.load(product_id)
        except (OSError, ValueError) as exc:
            messagebox.showerror("无法打开产品", str(exc))
            for index, item in enumerate(self.product_items):
                if self.product and item["id"] == self.product["id"]:
                    self.product_list.selection_clear(0, tk.END)
                    self.product_list.selection_set(index)
            return
        if not self._save_report_context():
            for index, item in enumerate(self.product_items):
                if self.product and item["id"] == self.product["id"]:
                    self.product_list.selection_clear(0, tk.END)
                    self.product_list.selection_set(index)
            return
        self._release_report_context()
        self._save_product()
        self._release_image()
        self.product = product
        self.engines = {}
        drawings = self.product.get("drawings", [])
        self.drawing_selector["values"] = [item["name"] for item in drawings]
        if drawings:
            index = min(int(self.product.get("active_drawing", 0)), len(drawings) - 1)
            self.drawing_selector.current(index)
            self._activate_drawing(index)
        else:
            self.drawing = None
            self.drawing_selector.set("")
            self._redraw()
        self.status.set(f"当前产品：{self.product['name']}")
        if self.main_tabs.select() == str(self.report_page):
            self._ensure_report_context()

    def _clear_product(self):
        self._release_report_context()
        self.product = None
        self.drawing = None
        self.engines = {}
        self.drawing_selector["values"] = []
        self.drawing_selector.set("")
        self._release_image()
        self._refresh_table()

    def new_product(self):
        name = simpledialog.askstring("新建产品", "产品名称：", parent=self.root)
        if name and name.strip():
            product = self.repository.create(name.strip())
            self._refresh_products(product["id"])

    def edit_product_header(self):
        if self.product is None:
            return
        dialog = tk.Toplevel(self.root)
        dialog.title("产品报表表头")
        dialog.transient(self.root)
        dialog.grab_set()
        values = report_header(self.product)
        variables = {}
        for row, field in enumerate(REPORT_HEADER_FIELDS):
            ttk.Label(dialog, text=field).grid(row=row, column=0, padx=10, pady=6, sticky=tk.W)
            variable = tk.StringVar(value=values[field])
            variables[field] = variable
            ttk.Entry(dialog, textvariable=variable, width=48).grid(row=row, column=1, padx=10, pady=6)
        history = ttk.Treeview(dialog, columns=REPORT_HEADER_FIELDS, show="headings", height=6)
        history.grid(row=len(variables) + 1, column=0, columnspan=2, padx=10, pady=8, sticky="ew")
        for field in REPORT_HEADER_FIELDS:
            history.heading(field, text=field)
            history.column(field, width=100, stretch=True)
        for record in reversed(revision_history(self.product)):
            history.insert("", tk.END, values=[record.get(field, "") for field in REPORT_HEADER_FIELDS])

        def save():
            append_revision(self.product, {field: variable.get().strip() for field, variable in variables.items()})
            self._save_product()
            dialog.destroy()

        ttk.Button(dialog, text="保存为修改记录", command=save).grid(row=len(variables), column=0, columnspan=2, pady=10)
        dialog.wait_window()

    def delete_product(self):
        if self.product is None:
            return
        if not messagebox.askyesno("删除产品", f"删除产品“{self.product['name']}”及其独立文件夹？"):
            return
        product_id = self.product["id"]
        self._clear_product()
        self.repository.delete(product_id)
        self._refresh_products()

    def add_drawings(self):
        if self.product is None:
            messagebox.showwarning("提示", "请先新建产品")
            return
        paths = filedialog.askopenfilenames(title="选择图纸", filetypes=[("图片", "*.jpg *.jpeg *.png *.bmp *.tif *.tiff")])
        first = None
        for path in paths:
            try:
                drawing = self.repository.add_drawing(self.product, path)
                first = first or drawing
            except (OSError, ValueError) as exc:
                messagebox.showerror("添加图纸失败", str(exc))
        if first is not None:
            self.drawing_selector["values"] = [item["name"] for item in self.product["drawings"]]
            index = self.product["drawings"].index(first)
            self.drawing_selector.current(index)
            self._activate_drawing(index)

    def remove_drawing(self):
        if self.drawing is None or not messagebox.askyesno("移除图纸", f"从产品中移除“{self.drawing['name']}”？"):
            return
        self._sync_current()
        path = self.repository.drawing_path(self.product, self.drawing)
        thumbnail = self.repository.thumbnail_path(self.product, self.drawing)
        self.engines.pop(self.drawing["id"], None)
        self.product["drawings"].remove(self.drawing)
        try:
            path.unlink(missing_ok=True)
            thumbnail.unlink(missing_ok=True)
        except OSError:
            pass
        self.repository.save(self.product)
        values = [item["name"] for item in self.product["drawings"]]
        self.drawing_selector["values"] = values
        if values:
            self.drawing_selector.current(0)
            self._activate_drawing(0)
        else:
            self.drawing = None
            self.drawing_selector.set("")
            self._release_image()
            self._redraw()

    def _on_drawing_select(self, _event=None):
        index = self.drawing_selector.current()
        if index >= 0:
            self._sync_current()
            self._activate_drawing(index)

    def _activate_drawing(self, index):
        self.product["active_drawing"] = index
        self.drawing = self.product["drawings"][index]
        self.selected_seq = None
        self._load_thumbnail()
        self._refresh_table()
        self.repository.save(self.product)

    def _release_image(self):
        self.photo = None
        self.canvas.delete("all")

    def _on_canvas_resize(self, _event=None):
        if self.resize_job is not None:
            self.root.after_cancel(self.resize_job)
        self.resize_job = self.root.after(120, self._load_thumbnail)

    def _load_thumbnail(self):
        self.resize_job = None
        if self.drawing is None:
            self._redraw()
            return
        path = self.repository.drawing_path(self.product, self.drawing)
        thumbnail = self.repository.thumbnail_path(self.product, self.drawing)
        try:
            cache_valid = (
                thumbnail.is_file() and self.drawing.get("width") and self.drawing.get("height")
                and thumbnail.stat().st_mtime >= path.stat().st_mtime
            )
            image_path = thumbnail if cache_valid else path
            image = cv2.imdecode(np.fromfile(image_path, dtype=np.uint8), cv2.IMREAD_COLOR)
        except (OSError, ValueError, cv2.error):
            image = None
        if image is None:
            messagebox.showerror("图纸错误", f"无法读取图纸：\n{path}")
            return
        if cache_valid:
            original_w, original_h = int(self.drawing["width"]), int(self.drawing["height"])
        else:
            original_h, original_w = image.shape[:2]
            cache_scale = min(1800 / original_w, 1400 / original_h, 1.0)
            cached = image if cache_scale == 1.0 else cv2.resize(
                image, (max(1, int(original_w * cache_scale)), max(1, int(original_h * cache_scale))),
                interpolation=cv2.INTER_AREA,
            )
            thumbnail.parent.mkdir(parents=True, exist_ok=True)
            encoded_ok, cache_buffer = cv2.imencode(".png", cached)
            if encoded_ok:
                cache_buffer.tofile(thumbnail)
            if cached is not image:
                del cached
            self.drawing["width"], self.drawing["height"] = original_w, original_h
            self.repository.save(self.product)
        canvas_w = max(100, self.canvas.winfo_width())
        canvas_h = max(100, self.canvas.winfo_height())
        scale = min(canvas_w / original_w, canvas_h / original_h, 1.0)
        display_w, display_h = max(1, int(original_w * scale)), max(1, int(original_h * scale))
        if (display_w, display_h) != (image.shape[1], image.shape[0]):
            image = cv2.resize(image, (display_w, display_h), interpolation=cv2.INTER_AREA)
        ok, encoded = cv2.imencode(".png", image)
        del image
        if not ok:
            messagebox.showerror("图纸错误", "缩略图生成失败")
            return
        self.photo = tk.PhotoImage(data=base64.b64encode(encoded.tobytes()).decode("ascii"))
        self.image_size = (original_w, original_h)
        self.display = (max(0, (canvas_w - display_w) // 2), max(0, (canvas_h - display_h) // 2),
                        display_w, display_h, scale)
        self._redraw()

    def _redraw(self):
        self.canvas.delete("all")
        if self.photo is None or self.engine is None:
            self.canvas.create_text(self.canvas.winfo_width() // 2, self.canvas.winfo_height() // 2,
                                    text="请选择产品并添加图纸", fill="#d0d0d0", font=("Microsoft YaHei", 14))
            self._refresh_table()
            return
        offset_x, offset_y, _, _, scale = self.display
        self.canvas.create_image(offset_x, offset_y, image=self.photo, anchor=tk.NW)
        radius = max(9, int(self.product.get("bubble_radius", 18) * scale))
        for bubble in self.engine.sorted():
            x, y = offset_x + bubble["x"] * scale, offset_y + bubble["y"] * scale
            selected = sequence_label(bubble["seq"]) == self.selected_seq
            color = "#d32f2f" if selected else ("#1976d2" if self._complete(bubble) else "#6b7280")
            self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius,
                                    fill=color, outline="white", width=2, stipple="gray50")
            self.canvas.create_text(x, y, text=sequence_label(bubble["seq"]), fill="white",
                                    font=("Microsoft YaHei", max(8, int(self.product.get("font_size", 14) * scale)), "bold"))

    @staticmethod
    def _complete(bubble):
        return all(str(bubble.get(key, "")).strip() for key in ("item", "req", "tool"))

    def _image_coordinates(self, event):
        offset_x, offset_y, display_w, display_h, scale = self.display
        if not (offset_x <= event.x < offset_x + display_w and offset_y <= event.y < offset_y + display_h):
            return None
        return int((event.x - offset_x) / scale), int((event.y - offset_y) / scale)

    def _on_canvas_click(self, event):
        if self.engine is None:
            return
        point = self._image_coordinates(event)
        if point is None:
            return
        hit = self.engine.hit_test(*point, self.product.get("bubble_radius", 18))
        try:
            bubble = hit or self.engine.add(*point)
            self.selected_seq = sequence_label(bubble["seq"])
            self.drag_start = (self.selected_seq, point, (bubble["x"], bubble["y"])) if hit else None
            self.drag_position = None
            self._changed()
        except BubbleError as exc:
            messagebox.showerror("气泡错误", str(exc))

    def _on_canvas_drag(self, event):
        point = self._image_coordinates(event)
        if self.drag_start and point:
            seq, start, original = self.drag_start
            x = max(0, min(self.image_size[0] - 1, original[0] + point[0] - start[0]))
            y = max(0, min(self.image_size[1] - 1, original[1] + point[1] - start[1]))
            self.drag_position = (x, y)
            self._redraw()
            ox, oy, _, _, scale = self.display
            self.canvas.create_oval(ox+x*scale-12, oy+y*scale-12, ox+x*scale+12, oy+y*scale+12,
                                    outline="#ffeb3b", width=3)

    def _on_canvas_release(self, event):
        if self.drag_start:
            seq, _, _ = self.drag_start
            position = self.drag_position
            self.drag_start = self.drag_position = None
            if position and self.engine is not None:
                self.engine.update(seq, dict(zip(("x", "y"), position)))
                self._changed()

    def _filter_column(self, key):
        if self.engine is None:
            return
        dialog = tk.Toplevel(self.root)
        dialog.title(f"{COLUMN_NAMES[key]}：筛选与统计")
        dialog.geometry("850x650")
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.columnconfigure(0, weight=1)
        dialog.rowconfigure(4, weight=1)
        rule = self.column_filters.get(key, {})
        query = tk.StringVar(value=rule.get("query", ""))
        mode = tk.StringVar(value="全部关键词" if rule.get("mode") == "all" else "任一关键词")
        ttk.Label(dialog, text="多个包含关键词用逗号、分号分隔；关键词与选中值同时生效。数量基于其他列筛选后的数据。").grid(row=0, column=0, sticky="w", padx=10, pady=6)
        bar = ttk.Frame(dialog)
        bar.grid(row=1, column=0, sticky="ew", padx=10)
        ttk.Entry(bar, textvariable=query, width=50).pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Combobox(bar, textvariable=mode, state="readonly", values=("任一关键词", "全部关键词"), width=14).pack(side=tk.LEFT, padx=6)
        ttk.Label(dialog, text="按住 Ctrl / Shift 多选具体值；不选值表示只按关键词筛选。空白值显示为（空白）。").grid(row=2, column=0, sticky="w", padx=10, pady=6)
        values_frame = ttk.Frame(dialog)
        values_frame.grid(row=3, column=0, sticky="ew", padx=10)
        choices = tk.Listbox(values_frame, selectmode=tk.EXTENDED, exportselection=False, height=9)
        choices.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scroll = ttk.Scrollbar(values_frame, command=choices.yview)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)
        choices.configure(yscrollcommand=scroll.set)
        rows = self.engine.sorted()
        counts = value_counts(rows, key, self.column_filters)
        values = sorted(counts, key=lambda value: (-counts[value], value.casefold()))
        for index, value in enumerate(values):
            choices.insert(tk.END, f"{value or '（空白）'}    —— {counts[value]} 个")
            if rule.get("values") is not None and value in rule["values"]:
                choices.selection_set(index)
        preview = tk.Text(dialog, wrap="none", height=10, state="disabled")
        preview.grid(row=4, column=0, sticky="nsew", padx=10, pady=8)
        summary = tk.StringVar()
        ttk.Label(dialog, textvariable=summary).grid(row=5, column=0, sticky="w", padx=10)

        def current_rule():
            selected = [values[index] for index in choices.curselection()]
            return {"query": query.get(), "mode": "all" if mode.get() == "全部关键词" else "any",
                    "values": selected if selected else None}

        def update_preview(*_args):
            filters = dict(self.column_filters)
            filters[key] = current_rule()
            result = [row for row in rows if matches(row, filters)]
            summary.set(f"匹配 {len(result)} / {len(rows)} 行；本列 {len(counts)} 种值；重复值 {sum(n > 1 for n in counts.values())} 种；预览前 100 行")
            preview.configure(state="normal")
            preview.delete("1.0", tk.END)
            preview.insert(tk.END, "序号 | 检验项目 | 检验要求 | 当前列值\n")
            for row in result[:100]:
                preview.insert(tk.END, " | ".join(cell_text(row, column) for column in ("seq", "item", "req", key)) + "\n")
            preview.configure(state="disabled")

        def apply(clear=False):
            candidate = current_rule()
            if clear or (not candidate["query"].strip() and candidate["values"] is None):
                self.column_filters.pop(key, None)
            else:
                self.column_filters[key] = candidate
            self.tree.heading(key, text=COLUMN_NAMES[key] + (" [筛选]" if key in self.column_filters else ""))
            self._refresh_table()
            dialog.destroy()

        buttons = ttk.Frame(dialog)
        buttons.grid(row=6, column=0, sticky="ew", padx=10, pady=10)
        ttk.Button(buttons, text="全选值", command=lambda: (choices.selection_set(0, tk.END), update_preview())).pack(side=tk.LEFT)
        ttk.Button(buttons, text="取消值选择", command=lambda: (choices.selection_clear(0, tk.END), update_preview())).pack(side=tk.LEFT, padx=5)
        ttk.Button(buttons, text="清除此列筛选", command=lambda: apply(True)).pack(side=tk.LEFT)
        ttk.Button(buttons, text="应用", command=apply).pack(side=tk.RIGHT)
        ttk.Button(buttons, text="取消", command=dialog.destroy).pack(side=tk.RIGHT, padx=5)
        query.trace_add("write", update_preview)
        mode.trace_add("write", update_preview)
        choices.bind("<<ListboxSelect>>", update_preview)
        update_preview()

    def _navigate_cell(self, event):
        rows = self.tree.get_children()
        if not rows:
            return "break"
        selected = self.tree.selection()
        row = rows.index(selected[0]) if selected and selected[0] in rows else 0
        column = int(self.active_column[1:]) - 1
        row = max(0, min(len(rows) - 1, row + {"Up": -1, "Down": 1}.get(event.keysym, 0)))
        column = max(0, min(len(BUBBLE_FIELDS) - 1, column + {"Left": -1, "Right": 1}.get(event.keysym, 0)))
        self.active_column = f"#{column + 1}"
        self._mark_active_column()
        self.tree.selection_set(rows[row])
        self.tree.focus(rows[row])
        self.tree.see(rows[row])
        widths = [int(self.tree.column(key, "width")) for key in BUBBLE_FIELDS]
        left = sum(widths[:column])
        total = sum(widths)
        start, end = self.tree.xview()
        if left < start * total:
            self.tree.xview_moveto(left / total)
        elif left + widths[column] > end * total:
            self.tree.xview_moveto(max(0, (left + widths[column] - (end - start) * total) / total))
        self.selected_seq = rows[row]
        self.status.set(f"当前单元格：序号 {rows[row]} / {COLUMN_NAMES[BUBBLE_FIELDS[column]]}，按空格编辑")
        self._redraw()
        return "break"

    def _clear_filters(self):
        self.column_filters.clear()
        for key in BUBBLE_FIELDS:
            self.tree.heading(key, text=COLUMN_NAMES[key])
        self._refresh_table()

    def _remember_cell(self, event):
        column = self.tree.identify_column(event.x)
        if column and column != "#0":
            self.active_column = column
            self._mark_active_column()

    def _mark_active_column(self):
        for index, key in enumerate(BUBBLE_FIELDS, 1):
            self.tree.heading(key, text=("▶ " if self.active_column == f"#{index}" else "")
                              + COLUMN_NAMES[key] + (" [筛选]" if key in self.column_filters else ""))

    def _edit_cell_keyboard(self, event=None):
        selection = self.tree.selection()
        if selection:
            self._open_cell_editor(selection[0], self.active_column)
        return "break"

    def _on_canvas_right_click(self, event):
        if self.engine is None:
            return
        point = self._image_coordinates(event)
        hit = self.engine.hit_test(*point, self.product.get("bubble_radius", 18)) if point else None
        if hit and messagebox.askyesno("删除气泡", f"删除序号 {sequence_label(hit['seq'])}？"):
            self.engine.delete(hit["seq"])
            self.selected_seq = None
            self._changed()

    def _refresh_table(self):
        self.tree.delete(*self.tree.get_children())
        if self.engine is None:
            return
        for bubble in self.engine.sorted():
            label = sequence_label(bubble["seq"])
            if not matches(bubble, self.column_filters):
                continue
            self.tree.insert("", tk.END, iid=label,
                             values=[label if key == "seq" else bubble.get(key, "") for key in BUBBLE_FIELDS])
        if self.selected_seq and self.tree.exists(self.selected_seq):
            self.tree.selection_set(self.selected_seq)
            self.tree.focus(self.selected_seq)
            self.tree.see(self.selected_seq)

    def _on_tree_select(self, _event=None):
        selection = self.tree.selection()
        if selection:
            self.selected_seq = selection[0]
            self._redraw()

    def _edit_cell(self, event):
        if self.tree.identify("region", event.x, event.y) != "cell":
            return
        item, column = self.tree.identify_row(event.y), self.tree.identify_column(event.x)
        if not item or not column:
            return
        self.active_column = column
        self._open_cell_editor(item, column)

    def _open_cell_editor(self, item, column):
        key = BUBBLE_FIELDS[int(column[1:]) - 1]
        box, old = self.tree.bbox(item, column), self.tree.set(item, column)
        if not box:
            return
        editor = ttk.Combobox(self.tree, values=("/", "☆", "★", "▲", "▲SPC")) if key == "importance" else ttk.Entry(self.tree)
        editor.place(x=box[0], y=box[1], width=box[2], height=box[3])
        editor.insert(0, old)
        editor.select_range(0, tk.END)
        editor.focus_set()
        done = False

        def finish(save):
            nonlocal done
            if done:
                return
            done = True
            value = editor.get().strip()
            editor.destroy()
            self.tree.focus_set()
            if not save or value == old:
                return
            try:
                changes = {key: value}
                if key in ("x", "y") and not 0 <= int(value) < self.image_size[0 if key == "x" else 1]:
                    raise BubbleError("坐标必须位于图纸范围内")
                if key == "req" and not self.engine.get(item).get("internal"):
                    changes["internal"] = value
                updated = self.engine.update(item, changes)
                self.selected_seq = sequence_label(updated["seq"])
                self._changed()
            except (BubbleError, ValueError) as exc:
                messagebox.showerror("修改失败", str(exc))
                self._refresh_table()

        editor.bind("<Return>", lambda _event: finish(True))
        editor.bind("<Escape>", lambda _event: finish(False))
        editor.bind("<FocusOut>", lambda _event: finish(True))

    def _flash_bubble(self):
        token = object()
        self._flash_token = token
        drawing, selected = self.drawing, self.selected_seq

        def tick(step=0):
            if self._flash_token is not token or self.drawing is not drawing or self.selected_seq != selected:
                return
            self._redraw()
            if step < 8:
                if step % 2 == 0 and self.engine is not None:
                    bubble = self.engine.get(selected)
                    if bubble is not None:
                        ox, oy, _, _, scale = self.display
                        x, y = ox + bubble["x"] * scale, oy + bubble["y"] * scale
                        radius = max(18, self.product.get("bubble_radius", 18) * scale + 10)
                        self.canvas.create_oval(x-radius, y-radius, x+radius, y+radius,
                                                outline="#ffeb3b", width=5)
                self.root.after(180, lambda: tick(step + 1))
        tick()

    def copy_previous_row(self):
        selection = self.tree.selection()
        if not selection or self.engine is None:
            messagebox.showwarning("提示", "请选择要填入内容的行")
            return
        rows = self.engine.sorted()
        index = next(i for i, row in enumerate(rows) if sequence_label(row["seq"]) == selection[0])
        if index == 0:
            messagebox.showwarning("提示", "第一行没有上一行")
            return
        self.engine.update(selection[0], {key: rows[index - 1][key]
                                        for key in BUBBLE_FIELDS if key not in ("seq", "x", "y")})
        self.selected_seq = selection[0]
        self._changed()

    def add_child(self):
        selection = self.tree.selection()
        if not selection or self.engine is None:
            messagebox.showwarning("提示", "请先选择父序号")
            return
        try:
            width, height = self.image_size
            parent = self.engine.get(selection[0])
            bubble = self.engine.add_child(
                selection[0], min(width - 1, parent["x"] + 30), min(height - 1, parent["y"] + 30)
            )
            self.selected_seq = sequence_label(bubble["seq"])
            self._changed()
        except BubbleError as exc:
            messagebox.showerror("添加失败", str(exc))

    def undo(self, _event=None):
        if self.engine is not None and self.engine.undo():
            self.selected_seq = None
            self._changed()

    def _changed(self):
        self._sync_current()
        self.repository.save(self.product)
        self._refresh_table()
        self._redraw()
        self.status.set(f"气泡 {len(self.engine.bubbles)} 个，撤销记录 {self.engine.history_size}/100")

    def export_contract(self, notify=True):
        if self.product is None:
            messagebox.showwarning("提示", "请先选择产品")
            return None
        self._save_product()
        path = export_product(self.product, self.repository.export_path(self.product))
        self.status.set(f"已导出：{path.name}")
        if notify:
            messagebox.showinfo("导出完成", f"标准数据已导出到：\n{path}")
        return path

    def open_report_tool(self):
        if self.product is None:
            messagebox.showwarning("提示", "请先选择产品")
            return
        self.main_tabs.select(self.report_page)
        self._ensure_report_context()

    def _on_main_tab(self, _event=None):
        if self.main_tabs.select() == str(self.report_page):
            self._ensure_report_context()

    def _ensure_report_context(self):
        if self.product is None or self.report_app is not None:
            return
        try:
            from report_system.ui.app import ReportGeneratorApp
            path = self.export_contract(notify=False)
            self.report_app = ReportGeneratorApp(
                self.report_page, initial_source=str(path), embedded=True,
                source_provider=lambda: self.export_contract(notify=False),
            )
        except Exception as exc:
            self._release_report_context()
            messagebox.showerror("报表加载失败", str(exc))

    def _save_report_context(self):
        if self.report_app is None:
            return True
        if self.report_app.save_config(silent=True):
            return True
        return messagebox.askyesno("配置未保存", "当前产品的报表配置保存失败，放弃本次配置修改？")

    def _release_report_context(self):
        if self.report_app is not None:
            self.report_app.df_source = None
            self.report_app = None
        for child in self.report_page.winfo_children():
            child.destroy()

    def on_close(self):
        if not self._save_report_context():
            return
        self._save_product()
        self._release_report_context()
        self._release_image()
        self.root.destroy()


def run(workspace=None):
    root = tk.Tk()
    BubbleApp(root, workspace or os.getcwd())
    root.mainloop()


"""Generate portable example packs and register them in the shared library."""
import copy
import json
import shutil
import sys
from pathlib import Path

import openpyxl
import pandas as pd
from openpyxl.styles import Alignment, Font, PatternFill

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from data.excel_contract import export_product
from report_system.core.engine import DEFAULT_RULES, DataProcessor, read_source_excel, save_workbook_from_template
from report_system.data.config_store import ConfigStore
from report_system.data.template_library import TemplateLibrary


SCENARIOS = [
    ("车削首件", "45钢", ["首件检验报表", "全尺寸检验表"], [
        ("外径", "Φ25±0.02", "千分尺"), ("长度", "80±0.1", "卡尺"),
        ("槽宽", "3±0.05", "卡尺"), ("粗糙度", "Ra1.6", "粗糙度仪")]),
    ("铣削过程", "6061铝合金", ["过程检验表", "过程检验指导书"], [
        ("长度", "120±0.1", "卡尺"), ("宽度", "60±0.05", "卡尺"),
        ("平面度", "0.03", "三坐标"), ("孔距", "40±0.02", "三坐标")]),
    ("磨削出货", "40Cr", ["出货检验表", "出货检验指导书"], [
        ("外径", "Φ20±0.005", "千分尺"), ("圆度", "0.003", "三坐标"),
        ("粗糙度", "Ra0.4", "粗糙度仪"), ("长度", "100±0.02", "卡尺")]),
    ("螺纹与孔位综合", "304不锈钢", ["全尺寸检验表", "过程检验表", "出货检验表"], [
        ("孔径", "Φ8 H7", "塞规"), ("孔距", "32±0.02", "三坐标"),
        ("位置度", "Φ0.05", "三坐标"), ("螺纹", "M10×1.5-6H", "螺纹塞规"),
        ("螺纹中径", "M10×1.5-6H", "螺纹塞规")]),
]


def main(root=ROOT):
    root = Path(root)
    cases = root / "模板案例库_新增四套"
    cases.mkdir(exist_ok=True)
    base = ROOT / "测试案例_四套" / "案例01-单工序基础"
    defaults = ConfigStore(base / "可导入模板配置.json").load()
    drawing_source = next((base / "drawings").glob("*.png"))
    library = TemplateLibrary(root)
    manifest = []
    for number, (title, material, types, dimensions) in enumerate(SCENARIOS, 1):
        code = f"template-example-20261023-{number}"
        if any(item.get("example_code") == code for item in library.list_items()):
            continue
        folder = cases / title
        (folder / "drawings").mkdir(parents=True, exist_ok=True)
        shutil.copy2(drawing_source, folder / "drawings" / "example.png")
        drawing_name = f"OP10-{title}"
        bubbles = []
        for index, (item, requirement, tool) in enumerate(dimensions, 1):
            bubbles.append({"seq": index, "item": item, "req": requirement, "internal": requirement,
                "tool": tool, "importance": ["▲", "★", "☆", "/"][(index - 1) % 4],
                "measure_method": "", "remark": "演示数据", "x": 180 + (index - 1) * 160, "y": 200})
        if number == 4:
            bubbles[-1]["seq"] = 4.1
        product = {"version": 1, "id": code, "name": f"模板示例-{title}", "active_drawing": 0,
            "bubble_radius": 18, "font_size": 14, "report_header": {"产品名": title, "版本": "A", "图版本": "A"},
            "drawings": [{"id": code + "-drawing", "name": drawing_name,
                          "path": "drawings/example.png", "bubbles": bubbles}]}
        ConfigStore(folder / "product.json").save(product)
        export_product(product, folder / "bubble_export.xlsx")
        config = {key: copy.deepcopy(defaults[key]) for key in ("freq", "item_trans", "tool_ship", "tool_proc")}
        rules, settings = {}, {}
        columns = ["图纸", "序号", "检验项目", "检验要求", "测量器具", "重要度", "检测场地", "备注"]
        workbook = openpyxl.Workbook()
        workbook.remove(workbook.active)
        for index, report in enumerate(types):
            rule = copy.deepcopy(DEFAULT_RULES[report])
            rule.update(base_type=report, source_drawings=[drawing_name], report_version="A.1",
                report_date="2026-10-23", report_author="示例", report_reason="初版模板案例",
                column_mapping={name: col for col, name in enumerate(columns, 1)},
                conditional_rules=[], fixed_columns={"9": material})
            rules[report] = rule
            header = 6 + index
            settings[report] = {"sheet_name": report, "header": header, "footer": header + 7,
                "history_sheet": f"修订记录{index + 1}", "history_start": "A1", "header_cells": {"报表版本": "K2"}}
            sheet = workbook.create_sheet(report)
            sheet.merge_cells("A1:I1")
            sheet["A1"] = f"{title} — {report}"
            sheet["A1"].font = Font(size=18, bold=True)
            sheet["A2"] = "产品：{{产品名}}    产品版本：{{版本}}    图版本：{{图版本}}"
            sheet["A3"] = "报表版本：{{报表版本}}    修订日期：{{报表修订日期}}"
            for col, name in enumerate(columns + ["材料"], 1):
                cell = sheet.cell(header, col, name)
                cell.font = Font(bold=True, color="FFFFFF")
                cell.fill = PatternFill("solid", fgColor=["305496", "548235", "7030A0", "C65911"][number - 1])
                cell.alignment = Alignment(horizontal="center")
                sheet.column_dimensions[cell.column_letter].width = 22
            sheet.cell(header + 7, 1, "检验：________    审核：________")
            sheet.freeze_panes = f"A{header + 1}"
        workbook.save(folder / "template.xlsx")
        workbook.close()
        config.update(rules=rules, sheet_config=settings, templates={"path": "template.xlsx"},
            template_profiles={"标准模板": {"path": "template.xlsx", "sheet_config": copy.deepcopy(settings)}},
            active_template_profile="标准模板", template_catalog=[])
        ConfigStore(folder / "可导入模板配置.json").save(config)
        ConfigStore(folder / "report_generator_config.json").save(config)
        processor = DataProcessor(read_source_excel(folder / "bubble_export.xlsx"), pd.DataFrame(config["freq"]),
                                  config["item_trans"], config["tool_ship"], config["tool_proc"])
        frames = {}
        for report, rule in rules.items():
            processor.validate_drawings(rule)
            frames[report] = processor.build(report, rule)
            if frames[report].empty:
                raise ValueError(f"示例报表没有数据：{title}/{report}")
        save_workbook_from_template(str(folder / "template.xlsx"), str(folder / "生成结果示例.xlsx"), frames,
            {name: (s["sheet_name"], s["header"], s["footer"]) for name, s in settings.items()},
            {name: r["column_mapping"] for name, r in rules.items()},
            {name: r["fixed_columns"] for name, r in rules.items()}, {}, report_header=product["report_header"])
        output = openpyxl.load_workbook(folder / "生成结果示例.xlsx", read_only=True)
        try:
            for report, frame in frames.items():
                sheet = output[report]
                start = settings[report]["header"] + 1
                actual = [sheet.cell(start + i, 1).value for i in range(len(frame))]
                if actual != frame["图纸"].tolist():
                    raise ValueError(f"生成结果与来源不符：{title}/{report}")
        finally:
            output.close()
        expected = {name: len(frame) for name, frame in frames.items()}
        ConfigStore(folder / "预期结果.json").save(expected)
        library.add({"name": f"案例-{title}", "process": title, "material": material,
            "requirement": "、".join(types), "example_code": code, "config": config}, folder)
        (folder / "使用说明.txt").write_text(
            f"{title}\n材料：{material}\n报表：{'、'.join(types)}\n\n"
            "1. 重启主程序，在检验报表 → 模板设置 → 模板档案库中选择对应案例并使用。\n"
            "2. 对照体验：先导入本目录 product.json 新建示例产品，再应用该案例。\n"
            "3. 用于自己的产品时，在报表规则中将每份报表的来源图纸改选为自己的工序图纸。\n"
            "4. 可导入模板配置.json 与 template.xlsx 放在一起即可再次导入档案库。\n"
            "5. bubble_export.xlsx 为示例数据源；生成结果示例.xlsx 为已实际生成并验证的报表。\n"
            "图像复用原演示图，尺寸与材料为功能演示数据，不作为制造依据。\n", encoding="utf-8-sig")
        manifest.append({"name": title, "reports": expected, "export_verified": True})
    if manifest:
        ConfigStore(cases / "新增案例验证结果.json").save(manifest)
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

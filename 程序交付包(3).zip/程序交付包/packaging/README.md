# Windows 打包

采用 PyInstaller 文件夹模式，入口为统一窗口 `baobiao.py`。发布包不包含产品、图片、缓存和测试数据。

在带有可用 Tcl/Tk 的 Windows Python 环境中执行：

```powershell
.\build.ps1 -Python 'C:\Path\To\python.exe' -InstallDependencies
```

已安装依赖时可省略 `-InstallDependencies`。请使用与目标架构一致的 Python。

输出为 `dist/BubbleInspection/BubbleInspection.exe` 和 `dist/BubbleInspection-win64.zip`。
必须分发整个文件夹或 ZIP，不能只复制 EXE。建议解压到普通用户目录。

数据默认保存在 `%LOCALAPPDATA%/BubbleInspection`。程序升级不覆盖用户数据。
现有数据需把工作区的 `products` 文件夹复制到上述目录；也可以启动时传入原工作区路径。

构建脚本先验证 Tcl/Tk，再运行测试。目标机器无需 Python，但模板生成仍需 Excel/WPS。
本工作区尚未生成 EXE：缺少 PyInstaller，且下载被网络权限限制；本机 Tcl/Tk 初始化也尚未通过。

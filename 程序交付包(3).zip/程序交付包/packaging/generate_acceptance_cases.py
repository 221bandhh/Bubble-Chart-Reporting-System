﻿"""Create four complete, reproducible report acceptance fixtures."""
import copy
import json
import shutil
import sys
from io import StringIO
from pathlib import Path

import openpyxl
import pandas as pd
from openpyxl.styles import Font, PatternFill, Alignment

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from data.excel_contract import export_product
from report_system.core.engine import (DEFAULT_RULES, REPORT_TYPES, DataProcessor,
    BUILT_IN_FREQ, BUILT_IN_ITEM_TRANS, BUILT_IN_TOOL_TRANS, clean_frame, read_source_excel)
from report_system.data.config_store import ConfigStore


def write_json(path, value):
    ConfigStore(path).save(value)


def make_template(path, settings, extra=False):
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    for name, config in settings.items():
        ws = wb.create_sheet(config['sheet_name'])
        ws['A1'] = name
        ws['A2'] = '产品 {{产品名}} / 产品版本 {{版本}} / 图版本 {{图版本}}'
        ws['A3'] = '报表版本 {{报表版本}} / 日期 {{报表修订日期}}'
        ws['A4'] = '修订人 {{报表修订人}} / 原因 {{报表修订原因}}'
        header = config['header']
        for col, text in enumerate(('图纸','序号','检验项目','检验要求','测量器具','重要度','检测场地','备注'), 1):
            cell = ws.cell(header, col, text)
            cell.font = Font(bold=True, color='FFFFFF')
            cell.fill = PatternFill('solid', fgColor='305496')
            ws.column_dimensions[cell.column_letter].width = 22
        ws.cell(config['footer'], 1, '审核：________    批准：________')
        ws.freeze_panes = f'A{header+1}'
        ws['K2'] = '报表版本写入位置'
        if extra:
            ws['BH45'] = '横向预览边界'
            ws['A120'] = '纵向预览第120行'
    notes = wb.create_sheet('说明页_不填数据')
    notes['A1'] = '此页用于验证可选择任意 Sheet 预览，不设置表头行则不参与生成。'
    wb.save(path)
    wb.close()


def main():
    cases = ROOT / '测试案例_四套'
    cases.mkdir(exist_ok=True)
    freq = clean_frame(pd.read_csv(StringIO(BUILT_IN_FREQ), sep='\t', dtype=str))
    items = clean_frame(pd.read_csv(StringIO(BUILT_IN_ITEM_TRANS), sep='\t', dtype=str))
    tools = clean_frame(pd.read_csv(StringIO(BUILT_IN_TOOL_TRANS), sep='\t', dtype=str))
    dictionaries = {'item_trans': dict(zip(items.iloc[:,0], items.iloc[:,1])),
                    'tool_ship': dict(zip(tools.iloc[:,0], tools.iloc[:,1])),
                    'tool_proc': dict(zip(tools.iloc[:,0], tools.iloc[:,2]))}
    index_path = ROOT / 'products/index.json'
    index = ConfigStore(index_path).load()
    summary = []
    demo = json.loads((ROOT / 'products/演示-阶梯轴/product.json').read_text(encoding='utf-8'))
    for number, title, process_names, base_types in (
        (1, '单工序基础', ['精车'], [REPORT_TYPES[0]]),
        (2, '双工序隔离', ['车削', '磨削'], ['过程检验表']*2),
        (3, '六类报表复用', ['粗车', '精车', '钻孔'], REPORT_TYPES),
        (4, '边界与异常', ['前道', '后道'], ['出货检验表', '过程检验指导书']),
    ):
        name = f'案例{number:02d}-{title}'
        folder = cases / name
        folder.mkdir(exist_ok=True)
        product_name = f'验收-{name}'
        product_dir = ROOT / 'products' / product_name
        (product_dir / 'drawings').mkdir(parents=True, exist_ok=True)
        product = {'version':1, 'id':f'acceptance-case-{number}', 'name':product_name,
                   'folder':product_name, 'active_drawing':0, 'bubble_radius':18, 'font_size':14,
                   'drawings':[], 'report_header':{'产品名':product_name, '产品规格':'Φ20×120',
                   '产品料号':f'TEST-{number:03}', '版本':'P2', '图版本':'D3',
                   '修改日期':'2026-10-19', '修改人':'产品测试员', '修改原因':'四项功能验收'}}
        for d, process in enumerate(process_names):
            drawing_name = f'OP{(d+1)*10:02d}-{process}'
            original = demo['drawings'][d % len(demo['drawings'])]
            image_source = ROOT / 'products/演示-阶梯轴' / original['path']
            relative = f'drawings/case-{number}-{d}.png'
            shutil.copy2(image_source, product_dir / relative)
            bubbles = []
            count = 40 if number == 4 and d == 0 else 4
            for row in range(count):
                item, tool = [('外径','卡尺'),('孔径','三坐标'),('粗糙度','粗糙度仪'),('螺纹','螺纹塞规')][row % 4]
                bubbles.append({'seq':row+1, 'item':item, 'req':f'C{number}-OP{d+1}-R{row+1}: '+('GN ' if row % 7 == 0 else '')+'20±0.02',
                    'tool':tool, 'internal':f'OP{d+1}内控', 'importance':['▲','★','☆','/'][row%4],
                    'measure_method':'专用量具' if row%2 else '', 'remark':f'仅允许进入{drawing_name}绑定的报表',
                    'x':150+(row%4)*240, 'y':150+(row//4)*35})
            product['drawings'].append({'id':f'case-{number}-{d}', 'name':drawing_name,
                                        'path':relative, 'bubbles':bubbles})
        write_json(product_dir / 'product.json', product)
        fixture_product = copy.deepcopy(product)
        (folder / 'drawings').mkdir(exist_ok=True)
        for drawing in product['drawings']:
            shutil.copy2(product_dir / drawing['path'], folder / drawing['path'])
        write_json(folder / 'product.json', fixture_product)
        export_product(product, folder / 'bubble_export.xlsx')
        export_product(product, product_dir / 'bubble_export.xlsx')
        rules, settings = {}, {}
        for r, base in enumerate(base_types):
            drawing = product['drawings'][r % len(process_names)]['name']
            report_name = f'{drawing}-{base}'
            rule = copy.deepcopy(DEFAULT_RULES[base])
            rule.update(base_type=base, source_drawings=[drawing], report_version=f'R{r+1}.{number}',
                        report_date='2026-10-19', report_author=f'报表测试员{r+1}', report_reason=f'{title}独立版本验证')
            rule['column_mapping'] = {key:i for i,key in enumerate(
                ['图纸','序号','检验项目','检验要求','测量器具','重要度','检测场地','备注'],1)}
            # Keep the fixture columns predictable; inherited rules target different template columns.
            rule['conditional_rules'] = []
            rule['fixed_columns'] = {'9':'验收固定值'}
            rules[report_name] = rule
            settings[report_name] = {'sheet_name':f'OP{(r%len(process_names)+1)*10:02d}_报表{r+1}',
                'header':6+r%3, 'footer':15+r%3, 'history_sheet':f'修订记录{r+1}',
                'history_start':'A1', 'header_cells':{'报表版本':'K2'}}
        template = folder / 'template.xlsx'
        make_template(template, settings, number == 4)
        config = {'rules':rules, 'sheet_config':settings, 'templates':{'path':str(template)},
            'template_profiles':{'标准模板':{'path':str(template), 'sheet_config':copy.deepcopy(settings)}},
            'active_template_profile':'标准模板', 'template_catalog':[],
            'freq':freq.to_dict('records'), **dictionaries}
        if number == 3:
            alternate = copy.deepcopy(settings)
            for value in alternate.values():
                value['header'] += 2
                value['footer'] += 2
            make_template(folder/'template_alternate.xlsx', alternate)
            config['template_profiles']['替代表头位置'] = {'path':str(folder/'template_alternate.xlsx'), 'sheet_config':alternate}
        write_json(folder / 'report_generator_config.json', config)
        write_json(product_dir / 'report_generator_config.json', config)
        portable = copy.deepcopy(config)
        portable['templates']['path'] = 'template.xlsx'
        portable['template_profiles']['标准模板']['path'] = 'template.xlsx'
        if number == 3:
            portable['template_profiles']['替代表头位置']['path'] = 'template_alternate.xlsx'
        write_json(folder / '可导入模板配置.json', portable)
        processor = DataProcessor(read_source_excel(folder/'bubble_export.xlsx'), freq, **dict(
            item_trans=dictionaries['item_trans'],tool_ship=dictionaries['tool_ship'],tool_proc=dictionaries['tool_proc']))
        expected, preview = {}, openpyxl.Workbook()
        preview.remove(preview.active)
        for report_name, rule in rules.items():
            processor.validate_drawings(rule)
            frame = processor.build(report_name, rule)
            assert set(frame['图纸']) == set(rule['source_drawings'])
            ws = preview.create_sheet(settings[report_name]['sheet_name'])
            ws.append(list(frame.columns))
            for values in frame.itertuples(index=False, name=None):
                ws.append(list(values))
            expected[report_name] = {'source_drawings':rule['source_drawings'], 'sheet':settings[report_name]['sheet_name'],
                                    'rows':len(frame), 'version':rule['report_version']}
        preview.save(folder/'预期数据_非实际导出.xlsx')
        preview.close()
        write_json(folder/'预期结果.json', expected)
        if number == 4:
            for filename, mutate in (
                ('异常1_未指定图纸.json', lambda c: c['rules'][next(iter(c['rules']))].update(source_drawings=[])),
                ('异常2_图纸不存在.json', lambda c: c['rules'][next(iter(c['rules']))].update(source_drawings=['已删除工序图'])),
                ('异常3_多个报表同Sheet.json', lambda c: [v.update(sheet_name='重复目标') for v in c['template_profiles']['标准模板']['sheet_config'].values()]),
            ):
                bad = copy.deepcopy(config)
                mutate(bad)
                write_json(folder/filename,bad)
        instructions = f'''{name}

一、在统一程序中直接选择产品“{product_name}”；或运行本目录“打开案例.bat”。
二、检查数据源：{len(process_names)} 张工序图纸，序号在各图纸中重复，检验要求带不同 OP 标记。
三、报表规则：每份报表已绑定来源图纸，并设置不同报表版本；点击预览核对“预期结果.json”。
四、模板设置：选择各报表，检查实际 Sheet、不同表头行；预览切换“说明页_不填数据”，再切回目标 Sheet，选表头/表尾。
五、档案库：导入“可导入模板配置.json”，使用选中模板，核对规则、列映射、固定值、频次和 Sheet 定位均被复用。
六、生成全部报表，保存为本目录“实际生成.xlsx”。逐表核对来源图纸和数据行数，检查 K2 和表头报表版本。
七、检查“报表版本信息”页：各报告的版本不同，产品版本 P2、图版本 D3 独立保留。
八、检查独立修订记录工作表，以及各模板的固定值第9列。

预期数据_非实际导出.xlsx 仅为数据处理结果，用于人工对照，不是 Office 导出结果。
样例图像复用现有演示图，仅作气泡界面载体；本案例气泡要求用于功能测试，不作为制造图纸。
'''
        if number == 3:
            instructions += '\n额外：切换“替代表头位置”方案，表头/表尾应整体后移2行；六类报表均能单独预览和生成。\n'
        if number == 4:
            instructions += '\n额外：逐个加载异常配置。未指定图纸和不存在图纸应阻止预览/生成；重复 Sheet 应阻止生成。恢复正常配置后再导出。前道40行用于验证自动扩展行，模板 A120、BH45 用于滚动预览验证。\n'
        (folder/'操作与验收说明.txt').write_text(instructions, encoding='utf-8-sig')
        (folder/'打开案例.bat').write_text('@echo off\ncd /d "%~dp0\\..\\.."\npython -m report_system.main "%~dp0bubble_export.xlsx"\nif errorlevel 1 pause\n',encoding='ascii')
        if not any(item['id']==product['id'] for item in index['products']):
            index['products'].append({'id':product['id'],'name':product_name,'folder':product_name})
        summary.append({'case':name, 'product':product_name, 'drawings':len(process_names),
                        'reports':len(rules), 'source_rows':sum(len(d['bubbles']) for d in product['drawings']),
                        'expected':expected, 'data_checks':'passed', 'office_export':'not_run'})
    write_json(index_path,index)
    write_json(cases/'案例清单与验证结果.json',summary)
    (cases/'先看这里.txt').write_text('四套完整案例已加入主程序产品列表，名称均以“验收-案例”开头。\n每套覆盖来源图纸、模板配置导入、Sheet预览和独立报表版本。\n案例01：单工序基础；案例02：双工序隔离；案例03：六类报表与双模板；案例04：大数据、预览边界与三种异常。\n每套包含产品JSON、复用演示图、数据源Excel、模板Excel、正常配置、可导入配置、预期数据和操作说明。\n本次已验证数据筛选与预期行数；实际窗口与Office导出需按各目录说明验收。\n',encoding='utf-8-sig')
    print(json.dumps([{'case':v['case'],'drawings':v['drawings'],'reports':v['reports'],'rows':v['source_rows']} for v in summary],ensure_ascii=False,indent=2))

if __name__ == '__main__':
    main()

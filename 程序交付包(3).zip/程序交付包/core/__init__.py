"""Core business logic for the inspection report tools."""


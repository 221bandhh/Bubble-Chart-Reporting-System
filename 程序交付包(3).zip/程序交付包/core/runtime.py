"""Resolve writable user data paths independently from bundled code."""

import os
import sys
from pathlib import Path


def working_directory(argument=None):
    if argument:
        return Path(argument).expanduser().resolve()
    if getattr(sys, "frozen", False):
        base = Path(os.environ.get("LOCALAPPDATA", str(Path.home())))
        return base / "BubbleInspection"
    return Path(__file__).resolve().parents[1]

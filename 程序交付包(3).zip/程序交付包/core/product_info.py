"""Product report metadata independent from dimensional inspection rows."""

from datetime import datetime

REPORT_HEADER_FIELDS = ("产品名", "产品规格", "产品料号", "版本", "图版本", "修改日期", "修改人", "修改原因")


def report_header(product):
    stored = product.get("report_header", {})
    return {field: str(stored.get(field, product.get("name", "") if field == "产品名" else ""))
            for field in REPORT_HEADER_FIELDS}


def revision_history(product):
    records = list(product.get("report_history", []))
    if not records and product.get("report_header"):
        records.append({**report_header(product), "记录时间": "历史数据"})
    return records


def append_revision(product, values):
    normalized = {field: str(values.get(field, "")).strip() for field in REPORT_HEADER_FIELDS}
    history = revision_history(product)
    if not history or any(history[-1].get(field, "") != normalized[field] for field in REPORT_HEADER_FIELDS):
        history.append({**normalized, "记录时间": datetime.now().isoformat(timespec="microseconds")})
    product["report_header"] = normalized
    product["report_history"] = history
    return history


def latest_revisions(records):
    """Most recently saved first, independent from user-entered revision dates."""
    return list(reversed(records[-3:]))

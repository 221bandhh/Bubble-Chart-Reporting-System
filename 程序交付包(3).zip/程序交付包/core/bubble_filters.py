"""Column filters shared by the table and its preview."""

import re
from collections import Counter

from core.bubble_engine import sequence_label


def cell_text(bubble, key):
    return sequence_label(bubble["seq"]) if key == "seq" else str(bubble.get(key, ""))


def keywords(text):
    return [word.strip().casefold() for word in re.split(r"[,，;；\n]+", text) if word.strip()]


def matches(bubble, filters):
    for key, rule in filters.items():
        value = cell_text(bubble, key)
        terms = keywords(rule.get("query", ""))
        if terms:
            hits = [term in value.casefold() for term in terms]
            if not (all(hits) if rule.get("mode") == "all" else any(hits)):
                return False
        selected = rule.get("values")
        if selected is not None and value not in selected:
            return False
    return True


def value_counts(rows, key, filters):
    other = {column: rule for column, rule in filters.items() if column != key}
    return Counter(cell_text(row, key) for row in rows if matches(row, other))
